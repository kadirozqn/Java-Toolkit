package threads;

public class ThreadCesitleriIsimlendirmeID {
    public static void main(String[] args) {

        Thread mainThreadim = Thread.currentThread();
        System.out.println("Thread adı: " +mainThreadim.getName()+ "id : " + mainThreadim.getId());
        mainThreadim.setName("Yeni main threadim");
        System.out.println("main threadin yeni adı : " + mainThreadim.getName());

        MyThread t1 = new MyThread("User Thread ",  ThreadRenkler.Green,5);
        System.out.println("t1 Thread'ı: " + t1);
        System.out.println("t1 Deamon turunde bır Thread mı? / " +t1.isDaemon());
        System.out.println("t1 thread id: " + t1.getId());
        t1.start();

        MyThread t2 = new MyThread("Deamon Thread ",  ThreadRenkler.Red,15);
        t2.setDaemon(true);
        System.out.println("t2 Thread'ı: " + t2);
        System.out.println("t2 Deamon turunde bır Thread mı? / " +t2.isDaemon());
        System.out.println("t2 thread id: " + t2.getId());
        t2.start();

        //bir thread calıstırıldıktan sonra sadece bır kez kullanılabılır. yenı bır ıslem ıcın yenı bır thread olusturmak gerekıyor
        //t1.start();
    }
}
class MyThread extends Thread {

    private int uykuSaniyesi;
    private String renk;

    public long getID(){
        return super.getId() + 85; // bu yontemle sıstemın bıze vermıs oldugu ıd degerını ıstedıgımız sekılde degıstırebılırız
    }

    public MyThread(String name, String renk, int uyumaSaniyesi) {
        super(name);
        this.renk = renk;
        this.uykuSaniyesi = uyumaSaniyesi;
    }

    @Override
    public void run() {
        System.out.println(renk + "Ben " +uykuSaniyesi+ " sanıyelık uzun suren ıslemı baslatıyorum. Thread adı:  " +currentThread().getName());

        try {
            Thread.sleep(uykuSaniyesi*1000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }
        System.out.println(renk + "Ben" +uykuSaniyesi + " sanıyelık uzun suren ıslemı sonlandırıyorum. Thread adı: "+Thread.currentThread().getName());

    }

}