package threads;

public class SynchronizaAnlatim {
    public static void main(String[] args) {
        Yazici yazici = new Yazici(10);
        Thread ayse = new Ayse(yazici);
        Thread fatma = new Fatma(yazici);

        ayse.start();
        fatma.start();
    }
}
class Yazici{
    private int dokumanSayisi;
    private int i =0;

    public Yazici(int dokumanSayisi) {
        this.dokumanSayisi = dokumanSayisi;

    }
    public /*synchronized*/ void yazdir(){

        //aynı anda sadece tek bır thread ıslem yapsın
        synchronized (this){
            for (i = dokumanSayisi; i > 0; i--){
                if (Thread.currentThread().getName().equals("Thread-0")){
                    System.out.println(ThreadRenkler.Red + " Dokuman no: " +i+ " Thread adı: " + Thread.currentThread().getName());
                }else System.out.println(ThreadRenkler.Green + " Dokuman no: "+ i + " Thrad adı: " + Thread.currentThread().getName());
            }
        }
    }
}
class Ayse extends Thread{
    private Yazici yazici;

    public Ayse (Yazici yazici){
        this.yazici = yazici;
    }

    @Override
    public void run() {
        yazici.yazdir();
    }
}
class Fatma extends Thread{
    private  Yazici yazici;

    public Fatma (Yazici yazici){
        this.yazici = yazici;
    }

    @Override
    public void run() {
        yazici.yazdir();
    }
}


