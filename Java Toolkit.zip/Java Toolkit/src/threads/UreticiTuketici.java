package threads;

public class UreticiTuketici {
    public static void main(String[] args) {
        OrtakAlan ortakAlan = new OrtakAlan();
        Uretici ureticiThread = new Uretici(ortakAlan);
        Tuketici tuketiciThread = new Tuketici(ortakAlan);


        ureticiThread.start();
        tuketiciThread.start();
    }
}
class OrtakAlan{
    private int veri = -900;
    private boolean veriVarMi = false;


    public synchronized int veriAl(){
        while(veriVarMi == false){

            try {
                wait();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }


        }
        veriVarMi = false;
        notifyAll();
        return veri;

    }
    public synchronized void veriYaz(int v){
        while (veriVarMi == true){
            try {
                wait();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

        }

        this.veri = v;
        veriVarMi = true;
        notifyAll();
    }
}
class Uretici extends Thread{

    private OrtakAlan ortakAlan;
    public Uretici (OrtakAlan o){
        this.ortakAlan = o;
    }
    @Override
    public void run() {
        for (int i=1; i<=10; i++){
            ortakAlan.veriYaz(i);
            System.out.println(ThreadRenkler.Magenta + "Üretici thread konulan veri: "+i);
            try {
                sleep((int)(Math.random()*3000));
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
class Tuketici extends Thread{
    private OrtakAlan ortakAlan;
    public Tuketici (OrtakAlan o){
        this.ortakAlan = o;
    }
    @Override
    public void run() {
        int okunanDeger = 0;
        for (int i=1; i<=10; i++){
            okunanDeger = ortakAlan.veriAl();
            ortakAlan.veriYaz(i);
            System.out.println(ThreadRenkler.Blue + "Tuketici thread konulan veri: "+okunanDeger);
            try {
                sleep((int)(Math.random()*3000));
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}