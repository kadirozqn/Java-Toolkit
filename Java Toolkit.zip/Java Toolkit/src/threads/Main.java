package threads;

public class Main {
    //Thread sınıfından
    //Runnable interface

    public static void main(String[] args) throws InterruptedException {
        System.out.println("Program başlatıldı." + Thread.currentThread().getName());

        Isci isci = new Isci();
        isci.start();
        isci.setName("ISCI SINIFI THREADI"); //thraed yerıne ıstedıgımız ısımlerı yazabılırız


        IsciRunnable runnableIsci = new IsciRunnable();
        Thread threadIsci = new Thread(runnableIsci);
        threadIsci.setName("ISCIRUNNABLE SINIFI THREADI");
        threadIsci.start();

        new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("Runnable Inner class   calısmaya basladı / Thread adı:  " + Thread.currentThread().getName());
                try {
                    Thread.sleep(10000); // 10 sanıye surecek bır ıslemı hatıraltabılır. ayrıca throws InterruptedException yerıne try catch ıcıne de alabılırdık
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                System.out.println("Runnable Inner class çalısmayı sonlandırdı / Thread adı:  " + Thread.currentThread().getName());
            }
        }).start();

        new Thread() {
            @Override
            public void run() {
                System.out.println("Thread Inner class   calısmaya basladı / Thread adı:  " + Thread.currentThread().getName());
                try {
                    Thread.sleep(10000); // 10 sanıye surecek bır ıslemı hatıraltabılır. ayrıca throws InterruptedException yerıne try catch ıcıne de alabılırdık
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                System.out.println("Thread Inner class çalısmayı sonlandırdı / Thread adı:  " + Thread.currentThread().getName());
            }

        }.start();
        System.out.println("Program bitti.");

    }
}
