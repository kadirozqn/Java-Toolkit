package threads;

public class ThreadRenkler {
    public static final String Black   = "\u001b[30m ";
    public static final String Red     = "\u001b[31m ";
    public static final String Green   = "\u001b[32m ";
    public static final String Yellow  = "\u001b[33m ";
    public static final String Blue    = "\u001b[34m ";
    public static final String Magenta = "\u001b[35m ";
    public static final String Cyan    = "\u001b[36m ";
    public static final String White   = " \u001b[37m";
    public static final String Reset   = "\u001b[0m  ";

    class myThread extends Thread {

        @Override
        public void run() {
            System.out.println(ThreadRenkler.Green + "Ben 10 sanıyelık uzun suren ıslemı baslatıyorum.");

            try {
                Thread.sleep(10000);
                
            }catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(ThreadRenkler.Green + "Ben 10 sanıyelık uzun suren ıslemı snlandırıyorum.");
        }
           
    }
}
