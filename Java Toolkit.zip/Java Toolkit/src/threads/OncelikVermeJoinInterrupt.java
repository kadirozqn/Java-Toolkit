package threads;

public class OncelikVermeJoinInterrupt {
    public static void main(String[] args) {

        TekSayiSay t1 = new TekSayiSay("1");
        TekSayiSay t2 = new TekSayiSay("2");
        t1.setPriority(Thread.MIN_PRIORITY);
        t1.start();
        //t2.setPriority(Thread.MAX_PRIORITY);
        //t2.start();


        new Thread(){
            @Override
            public void run() {
                for (int i = 0; i < 100; i++) {
                    if (i == 2) {
                        try {
                            t1.join(500);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                    if (i % 2 == 0) {
                        System.out.println(ThreadRenkler.Magenta +""+i+" ÖNCELİK: " + Thread.currentThread().getPriority());
                        try {
                            Thread.sleep(1000);
                        }catch (InterruptedException e ) {
                            return;
                        }
                    }
                }
            }
        }.start();
    }
}
class TekSayiSay extends Thread{
    String isim;
    String renk;
    public TekSayiSay(String name) {
        super(name);
        isim = name;
        if (name.equals("1")){
            renk = ThreadRenkler.Cyan;
        }else renk = ThreadRenkler.Magenta;
    }
    @Override
    public void run() {

        for (int i = 0; i < 100; i++) {

            if (i == 5 ){
                interrupt();
            }
            if (i % 2 !=0) {
                System.out.println(renk + "" + i +"ÖNCELİK: " + Thread.currentThread().getPriority());
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    return;
                }
            }
        }
    }
}
