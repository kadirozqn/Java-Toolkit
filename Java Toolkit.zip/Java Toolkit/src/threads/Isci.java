package threads;

public class Isci extends Thread{
    @Override
    public void run() {
        System.out.println("Isçi sınıfı calısmaya basladı / Thread adı:  " + Thread.currentThread().getName());
        try {
            Thread.sleep(10000); // 10 sanıye surecek bır ıslemı hatıraltabılır. ayrıca throws InterruptedException yerıne try catch ıcıne de alabılırdık
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        System.out.println("Isci sınıfı çalısmayı sonlandırdı / Thread adı:  " + Thread.currentThread().getName());


    }
}
