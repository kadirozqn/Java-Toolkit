package oopSorular;

public class Soru3 {
    public static void main(String[] args) {
        System.out.println("Toplam: "+HesapMakinesi.topla(25,12,3));
        System.out.println("Fark  : "+HesapMakinesi.cıkar(20,2,10));
        System.out.println("Çarpım: " + HesapMakinesi.carp(2,3,4));
        if(HesapMakinesi.bol(40,0,2)!=-1){
            System.out.println("Bolum : "+ HesapMakinesi.bol(40,0,2));
        }else{
            System.out.println("Bolme ıslemı basarısız!");
        }

    }
}

class HesapMakinesi{
    public static double topla(double... parametreler){
        double toplam =0;
        for( double parametre : parametreler){
            toplam = toplam +parametre;
        }
        return  toplam;
    }
    public static double cıkar(double... parametreler){
        double fark = parametreler[0];
        for (int i =1; i<parametreler.length;i++){
            fark = fark - parametreler[i];
        }
        return fark;
    }
    public static double carp(double... parametreler){
       double carpim =1;
       for(int i = 0; i<parametreler.length;i++){
           carpim = carpim * parametreler[i];
       }
       return carpim;
    }
    /*public static double carp(double... parametreler){
        double carpim =1;
        for(double parametre : parametreler){
            carpim = carpim +parametre;
        }
        return carpim;
    }*/

    public static double bol(double ... parametreler){
        double bolum = parametreler[0];
        for(int i = 1; i<parametreler.length;i++){
            if (parametreler[i] !=  0){
                bolum = bolum / parametreler[i];
            }
            else{
                System.out.println("Parametrelerden birisi 0 degeri oldugu ıcın bolme ıslemı yapılamıyor.");
                return -1;
            }
        }
        return bolum;
    }
}
