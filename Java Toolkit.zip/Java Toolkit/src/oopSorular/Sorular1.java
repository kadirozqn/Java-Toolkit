package oopSorular;

public class Sorular1 {
    public static void main(String[] args) {
        CemberDaire cd1 = new CemberDaire(5);
        System.out.printf("Yarıçapı 5 olan çemberin çevresi : %2f ",cd1.cevreBul());
        System.out.println();
        System.out.printf("Yarıçapı 5 olan dairenin alanı : %2f",+cd1.alanBul()); //printf formatlı sekılde yazmak ıcın kullanılır ve
                //+ ıle degıl , ıle ayrılır.
    }
}

class CemberDaire{
    private int yariCap;
    public final static double PI = 3.14;

    public CemberDaire(int r){
        this.yariCap = r;
    }
    public double cevreBul() {
        return 2* PI* yariCap;
    }
    public double alanBul(){
        return PI*Math.pow(yariCap,2);
    }



}
