package oopSorular;

public class Soru4 {
    public static void main(String[] args) {
        BankaHesap kadir = new BankaHesap(1,1000);
        BankaHesap ayse = new BankaHesap(2,1200);
        BankaHesap fatma = new BankaHesap(3,2000);
        BankaHesap ali = new BankaHesap(4,3000);
        BankaHesap abdulselam = new BankaHesap(5,1000);
        kadir.paraCek(999) ;
        ali.paraYatir(1000);
        ayse.paraCek(500);
        fatma.paraCek(350);
        abdulselam.paraCek(750);

        System.out.println("Kadir hesap no: "+kadir.getHesapNo());//kadir.hesapNoGoster();
        System.out.println("Ayse hesap no: "+ayse.getHesapNo());
        System.out.println("Fatma hesap no: "+fatma.getHesapNo());
        System.out.println("Ali hesap no: "+ali.getHesapNo());
        System.out.println("Abdulselam hesap no: "+abdulselam.getHesapNo());

        BankaHesap.hesapOzeti();
        ayse.kiyasla(kadir);
    }
}

class BankaHesap{
    private int hesapNo;
    private int hesapBakiye;
    private static int tumBankaBakiyesi=0;
    private static int tumHesapSayisi=0;
    private static int operasyonSayisi=0;

    public BankaHesap(int hesapNo, int hesapBakiye) {
        this.hesapNo = hesapNo;
        this.hesapBakiye = hesapBakiye;
        tumBankaBakiyesi += hesapBakiye;
        tumHesapSayisi++;
    }

    public int getHesapNo() {
        return hesapNo;
    }

    public void setHesapNo(int hesapNo) {
        this.hesapNo = hesapNo;
    }

    public int getHesapBakiye() {
        return hesapBakiye;
    }

    public void setHesapBakiye(int hesapBakiye) {
        this.hesapBakiye = hesapBakiye;
    }
    public void paraYatir(int paraMiktari){
        this.hesapBakiye +=paraMiktari;
        operasyonSayisi++;
    }
    public void paraCek(int paraMiktari){
        if (this.hesapBakiye >= paraMiktari) {
            this.hesapBakiye = paraMiktari;
            operasyonSayisi++;
            tumBankaBakiyesi-=paraMiktari;
        }else{
            System.out.println("Yetersiz bakiye. ");
        }

    }
    public void kiyasla(BankaHesap kiyaslanacakHesap){
        if(this.getHesapBakiye()<kiyaslanacakHesap.getHesapBakiye()) {
            System.out.println(this.getHesapNo() + " nolu kişinin bakiyesi " + kiyaslanacakHesap.getHesapNo() + " nolu kısıden azdir. ");
        }
    else if (this.getHesapBakiye()>kiyaslanacakHesap.getHesapBakiye()) {
        System.out.println(this.getHesapNo() + " nolu kişinin bakiyesi " + kiyaslanacakHesap.getHesapNo() + " nolu kısıden fazladir. ");
    }
    else {
            System.out.println(this.getHesapNo()+" nolu kişinin bakiyesi "+kiyaslanacakHesap.getHesapNo()+" nolu kısıyle eşittir. ");
        }
    }
    public static void hesapOzeti(){
        System.out.println("Bakiye: "+tumBankaBakiyesi);
        System.out.println("Hesap sayisi: "+tumHesapSayisi);
        System.out.println("Hareketler:  "+operasyonSayisi);
    }
    public void hesapNoGoster(){
        System.out.println("Hesap No: "+hesapNo);
    }

}