package kontrolYapilari;

public class IfElseKullanimi {
    public static void main(String[] args) {
        int sayi1 = 10, sayi2 = 5;
        System.out.println("Sayi1 sayi2den büyüktür");
        if(sayi1>sayi2){
            System.out.println("Sayi1 sayi2den küçüktür");
        }else if(sayi1 < sayi2){
            System.out.println("Sayi1 sayi2ye eşittir.");
        }else {
        }
        //klasik kullanim
        int a=10, b=6,c=0;
        if (a > b){
            c = a - b;
        }
        else{
            c = a + b;
        }
        System.out.println("C degıskenının degeri:"+ c);
        //İf-else yapısının kısa kullanımı asagıdakı gıbıdır.
        System.out.println("----------------------------------------------------------------------------------------");
        c =(a > b) ? (a-b) : (a+b);
        System.out.println("C degıskenının kısa kullanım ıle degerı:" + c);
    }
}
