package kontrolYapilari;

public class Switch_CaseYapisi {
    public static void main(String[] args) {
        //switch case yapısı
        int haftaici = 2; // swıtch case yapısında kullanılacak olan degısken turu double veya float olamaz. menude duzgun secım yapılamayacagı ıcın
        int haftasonu = 2;
        switch (haftaici){ // degıskenlerın hangı aralıtka oldugu kontrol edılemez
            case 1: System.out.println("Pazartesi");break; //break kullanmak zorunludur
            case 2: System.out.println("Salı");break;
            case 3: System.out.println("Carşamba");break;
            case 4: System.out.println("Perşembe");break;
            case 5: System.out.println("Cuma");break;
            default: System.out.println("Yanlış bir değer girdiniz!"); //yanlıs deger gırıldıgınde default calısır
        }
        switch (haftasonu){
            case 1: System.out.println("Cumartesi");break;
            case 2: System.out.println("Pazar");break;
            default: System.out.println("Yanlış bir değer girdiniz!");
        }
    }
}
