package kontrolYapilari;

import javax.imageio.ImageTranscoder;

public class MathSinifiKullanimi {
    public static void main(String[] args) {
        System.out.println("Pi sayısının degeri: " + Math.PI); // Math.PI seklınde matematık kutuphanesını kullanabılırsın.
        System.out.println("Euler sayisinin degeri: " + Math.E);

        System.out.println("-5 sayisinin mutlak degeri: " + Math.abs(-5));
        System.out.println("4.6 sayisinin yuvarlanmıs degeri: " + Math.ceil(4.6));
        System.out.println("4.3 sayisinin yuvarlanmıs degeri: " + Math.ceil(3.4));
        System.out.println("-4.6 sayisinin yuvarlanmıs degeri: " + Math.ceil(-4.6));
        System.out.println("2nin küp degeri: "+ Math.pow(2, 3));
        System.out.println("3ün karesi degeri: "+ Math.pow(3,2));
        System.out.println("16 sayısının karekoku: "+ Math.sqrt(16));
        System.out.println("Hangısı daha buyuk 2 mı 3 mu? : "+ Math.max(2,3));
        System.out.println("Hangısı daha kucuk 2 mı 3 mu? : "+ Math.max(2,3));

        //random metodu:
        int onaKadarRastgeleSayi = (int)(Math.random()*11);  //0-10 arası rastgele sayi uretıldı. eger +1 yapsaydık 1-10 arası rastgele sayı uretecektı
        System.out.println("Rastgele üretilen sayi: " +onaKadarRastgeleSayi);

        int ıkıyeKadarRastgeleSayi = (int) (Math.random()*2 +1); // bu kullanımda sonuc ya 2 ya da 1 cıkar.
        System.out.println("Ikıye kadar uretılecek sayi: "+ıkıyeKadarRastgeleSayi);

        //kısacası;
        //eğer uretılecek sayının 0-10 aralıgını kapsamasını ıstıyorsanız
        //(int) (Math.random()*11);
        //eger uretılecek sayının aralıgında 0 olsun ıstemıyorsanız
        //(int) (Math.random()*2 +1);
    }
}