package kontrolYapilari;

public class WhileDongusu {
    public static void main(String[] args) {

        int sayi = 10;
        while(sayi<20){ // bu ifade true oldugu surece calısır
            System.out.println("Merhaba sayi:" +sayi);
            sayi++;
        }
        for(int i=10; i<20;i++){
            System.out.println("For döngüsü ile merhaba i degeri: "+i);
        }
        int s1 =0;
        do{
            System.out.println("Hello s1: "+s1);
            s1++;
        }while(s1<6);
    }
}
