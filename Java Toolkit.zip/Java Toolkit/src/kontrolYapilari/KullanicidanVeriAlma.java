package kontrolYapilari;

import java.util.Scanner;

public class KullanicidanVeriAlma {
    public static void main(String[] args) {
    Scanner tara = new Scanner(System.in);
       /* System.out.print("Lütfen bir sayi giriniz: ");
        int kullanicininGirdigiSayi = tara.nextInt();
        System.out.println("Girmiş olduğunuz sayi: " +kullanicininGirdigiSayi);
        System.out.print("lütfen bir double sayi giriniz: ");
        double kullaniciDouble = tara.nextDouble();
        System.out.println("Girmiş olduğunuz double sayi: "+kullaniciDouble);
*/
        System.out.print("Lütfen bir isim giriniz: ");
        String isim = tara.next(); // bu ıfade sadece bosluga kadar olan kısmı alacaktır.
        System.out.println("Girmiş oldugunuz ısım degeri: "+isim);

        tara.nextLine();

        System.out.print("Lutfen bır ısım ve soyısım gırınız: ");
        String isim2 =tara.nextLine(); // bu ıfade ıstyedıgımız kadar bosluk ıceren strıng degerı gırmemızı saglar.
        System.out.println("Girmiş oldugunuz ısım ve soyısım degeri: "+isim2);

        System.out.print("Lutfen bır string ıfade gırınız: ");
        char karakter = tara.next().charAt(2); // gırmıs oldugumuz ındısı getırır. sonuc d harfını vereceketır.
        System.out.println("Gırmıs oldugunuz strıng ıfadede 0. ındısın sonucu: "+karakter);
    }
}
