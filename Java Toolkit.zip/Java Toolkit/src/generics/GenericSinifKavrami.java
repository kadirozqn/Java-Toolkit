package generics;

import java.util.ArrayList;

public class GenericSinifKavrami {
    public static void main(String[] args) {
        //bu ozellık java 7le beraber geldı.
        String [] isimler = {"Kadir", "Emel", "Fatma"};
        Integer [] sayilar = {5,2,3}; // generıc sınıf kullandıgımız ıcın ınteger tanımlamalarını ınt seklınde degıl Integer seklınde yapmalıyız.
        Character[] karakterler = {'a','b','c'};

        /*System.out.println("İsimler;");
        StringDiziYazdir.yazdir(isimler);
        System.out.println("Sayilar;");
        IntegerDiziYazdir.IntegerYazdir(sayilar);
        System.out.println("Karakterler;");
        CharDiziYazdir.CharYazdir(karakterler);*/

        //int->Integer, double->Double, float->Float, char->Character
        System.out.println("Generic sınıflar ile yazdrma ıslemı:\nStringler için generic sınıf yazdırma metotu;");
        GenericDiziYazdir<String>stringGenericDiziYazdir = new GenericDiziYazdir<String>();
        stringGenericDiziYazdir.yazdir(isimler);
        System.out.println("Integer ıcın generıc sınıf yazdırma metotu;");
        GenericDiziYazdir<Integer>integerGenericDiziYazdir = new GenericDiziYazdir<Integer>();
        integerGenericDiziYazdir.yazdir(sayilar);
        System.out.println("Char ıcın generıc sınıf yazdırma metotu; ");
        GenericDiziYazdir<Character>characterGenericDiziYazdir = new GenericDiziYazdir<Character>();
        characterGenericDiziYazdir.yazdir(karakterler);


        //ArrayList listem = new ArrayList(); bu sekılde kullanırsak arraylıst ıcerısıne hangı verı tıpını yazarsak yazalım hata almayız.
        ArrayList <String> listem = new ArrayList(); // bu sekılde ıcerısıne sadece strıng verı tıpınde verıler saklayabılır.
        listem.add("Van");
        listem.add("İstanbul");
        listem.add("Bursa");
        //listem.add(true);
        //listem.add(1);
        //listem.add('a');
        listem.add("Hakkari");
        listem.add("İzmir");

        for(Object gecici : listem ){
            System.out.println(((String) gecici).length());
        }
    }
}
