package generics;

public class GenericMetotKavrami {
    public static void main(String[] args) {
        String [] isimler = {"Kadir", "Emel", "Fatma"};
        Integer [] sayilar = {7,5,8,5,2,3}; // generıc sınıf kullandıgımız ıcın ınteger tanımlamalarını ınt seklınde degıl Integer seklınde yapmalıyız.
        Character[] karakterler = {'a','b','c'};

        System.out.println("İsimler;");
        stringDiziYazdir(isimler);
        System.out.println("Sayilar;");
        intDiziYazdir(sayilar);
        System.out.println("Karakterler;");
        charDiziYazdir(karakterler);

        System.out.println("Polymorphism metot kullanımı ile isimler;");
        diziYazdir(isimler);
        //System.out.println("Polymorphism metot kullanımı ıle sayilar;");
        //diziYazdir(sayilar);
        //System.out.println("Polymorphism kavramı ıle karakterler;");
        //diziYazdir(karakterler);

        //System.out.println("Generic metot kullanımı ile isimler;"); generic metotumuzu
        //genericYazdir(isimler);
        System.out.println("Generic integer metot kullanımı ile sayilar;");
        genericNumaraYazdir(sayilar);
        //System.out.println("Generic metot kullanımı ile karakterler;");
        //genericYazdir(karakterler);
        System.out.println("Generic string metotumuz ıle isimler");
        genericMetinYazdir(isimler);
        //genericMetinYazdir(karakterler); character turunden verı tıpınde bunu kullanamıyoruz
    }
    public static  <Genel > void genericNumaraYazdir(Genel[] dizi){ //generıc metotumuz
        for (Genel gecici : dizi){
            System.out.println(gecici);
        }
    }
    public static  <Genel extends Number> void genericNumaraYazdir(Genel[] dizi){ // bıraz kısıtlanmıs generıc metotumuz
        for (Genel gecici : dizi){
            System.out.println(gecici.intValue());
        }
    }
    public static  <Genel extends CharSequence> void genericMetinYazdir(Genel[] dizi){
        for (Genel gecici : dizi){
            System.out.println(gecici.length());
        }
    }
    public static void diziYazdir(Object[] dizi){ //asagıda her bır verı turu ıcın ayrı ayrı yaptıgımız metotları polymorphsım kavramı ıle tek bır metotta kullanabılırız.
        for (Object gecici : dizi){
            System.out.println(((String)gecici).length()); //bunun ıcın cast ıslemı yapmamız gerekıyor
        }

    }
    public static void stringDiziYazdir(String []dizi){
        for(String gecici : dizi){
            System.out.println(gecici);
        }
    }
    public static void intDiziYazdir(Integer [] dizi){
        for (int gecici : dizi){
            System.out.println(gecici);
        }
    }
    public static void charDiziYazdir(Character [] dizi){
        for (char gecici : dizi ){
            System.out.println(gecici);
        }
    }

}

