package generics;

public class StringDiziYazdir {
    public static void yazdir (String[] dizi){
        for(String gecici : dizi){
            System.out.println(gecici);
        }
    }
}