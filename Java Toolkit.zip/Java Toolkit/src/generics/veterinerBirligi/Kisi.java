package generics.veterinerBirligi;

abstract public class Kisi{
    private String isim;
    private int tcKimlik;

    public Kisi(String isim, int tcKimlik) {
        this.isim = isim;
        this.tcKimlik = tcKimlik;
    }

    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public int getTcKimlik() {
        return tcKimlik;
    }

    public void setTcKimlik(int tcKimlik) {
        this.tcKimlik = tcKimlik;
    }
    abstract void kendiniTanit();

    @Override
    public String toString() {
        return "Kisi{" +
                "isim='" + isim + '\'' +
                ", tcKimlik=" + tcKimlik +
                '}';
    }
}
