package generics.veterinerBirligi;

import java.util.ArrayList;

public class SehirVeterinerlikleri {
    private String sehir;
    private ArrayList<Veteriner> sehirdekiVeterinerler;
    private int toplamVeterinerSayisi;

    public SehirVeterinerlikleri(String sehir) {
        this.sehir = sehir;
        sehirdekiVeterinerler = new ArrayList<>();
        toplamVeterinerSayisi =0;
    }
    public void sehireVeterinerEkle(Veteriner veteriner){
        toplamVeterinerSayisi++;
        sehirdekiVeterinerler.add(veteriner);
    }
    public void sehirdekiToplamVeterinerSayisiniBul(){
        System.out.println("Toplam veteriner sayisi: "+ sehirdekiVeterinerler.size());
    }
}
