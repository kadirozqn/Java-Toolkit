package generics.veterinerBirligi;

public class Main {
    public static void main(String[] args) {

        Kedi k1 = new Kedi("12/02/2010",true, "Van Kedisi");
        Kedi k2 = new Kedi("21/04/2015",false, "Siyam");
        Kedi k3 = new Kedi("06/06/2008",true, "Tekir");

        Kopek kp1 = new Kopek("11/08/2012", true,3,"Golden");
        Kopek kp2 = new Kopek("01/01/2009", true,6,"Pitbull");
        Kopek kp3 = new Kopek("05/08/2015", true,9,"Kurt Köpeği");

        Musteri m1 = new Musteri("Kadir", 56156165,"Esenyurt/ İstanbul");
        Musteri m2 = new Musteri("Ayşe", 51515414,"Avcılar/ İstanbul");
        Musteri m3 = new Musteri("Fatma", 15161256,"Beylikdüzü/ İstanbul");
        Musteri m4 = new Musteri("Cihan", 51615413, "Esenyurt/İstanbul");
        m4.musteriyeHayvanEkle(k1);


        Veteriner v1 = new Veteriner("Abdulselam",36545236,"Boğaziçi", 2);
        Veteriner v2 = new Veteriner("Ali",87849651,"Çanakkale Üniversitesi", 2);
        Veteriner v3 = new Veteriner("Emel",45648289,"Sakarya Üniversitesi", 2);

        System.out.println("Veteriner 1 bilgileri; ");
        v1.kendiniTanit();
        v1.musteriEkle(m1);
        v1.musteriEkle(m3);
        v1.musterileriListele();
        System.out.println(v1);
        System.out.println("Veteriner 1 bilgileri; ");
        v2.kendiniTanit();
        v2.musteriEkle(m1);
        v2.musteriEkle(m2);
        System.out.println(v2);
        System.out.println("Veteriner 1 bilgileri; ");
        v2.kendiniTanit();
        v2.musteriEkle(m3);
        System.out.println(v2);

        SehirVeterinerlikleri ankara = new SehirVeterinerlikleri("Ankara");
        ankara.sehireVeterinerEkle(v1);
        ankara.sehireVeterinerEkle(v2);

        SehirVeterinerlikleri istanbul = new SehirVeterinerlikleri("İstanbul");
        istanbul.sehireVeterinerEkle(v3);

        ankara.sehirdekiToplamVeterinerSayisiniBul();
        istanbul.sehirdekiToplamVeterinerSayisiniBul();
        System.out.println("-----------------------------------------------------------------------");

        System .out.println("Müşteri 1 bilgileri;");
        m1.kendiniTanit();
        System.out.println(m1);
        System .out.println("Müşteri 2 bilgileri;");
        m2.kendiniTanit();
        System.out.println(m2);
        System .out.println("Müşteri 3 bilgileri;");
        m3.kendiniTanit();
        System.out.println(m3);
        System.out.println("Müşteri 4 bilgileri; ");
        m4.kendiniTanit();
        System.out.println(m4);
        m4.musteriyeHayvanEkle(k1);
        m4.musteriyeHayvanEkle(kp1);

        System.out.println("-------------------------------------------------------------------");

        System.out.println("Köpek 1 bilgileri;");
        kp1.bilgileriGoster();
        System.out.println(kp1);
        System.out.println("Köpek 2 bilgileri;");
        kp2.bilgileriGoster();
        System.out.println(kp2);
        System.out.println("Köpek 3 bilgileri;");
        kp3.bilgileriGoster();
        System.out.println(kp3);

        System.out.println("--------------------------------------------------------------------------------");

        System.out.println("Kedi 1 bilgileri;");
        k1.bilgileriGoster();
        System.out.println(k1); // too strıng metodunu kullandık
        System.out.println("Kedi 2 bilgileri;");
        k2.bilgileriGoster();
        System.out.println(k2);
        System.out.println("Kedi 3 bilgileri;");
        k3.bilgileriGoster();
        System.out.println(k3);

        YonetımPaneli<Hayvan> hayvanYonetimPaneli = new YonetımPaneli<>();
        System.out.println();


        YonetımPaneli<Hayvan> hayvanYonetımPaneli = new YonetımPaneli<>();
        hayvanYonetimPaneli.bilgileriGoster(k1); // hayvan sınıfından bır nesne gondermemız gerekıyor
        hayvanYonetimPaneli.bilgileriGoster(kp1);

        YonetımPaneli<Musteri> musteriYonetımPaneli = new YonetımPaneli<>();
        musteriYonetımPaneli.bilgileriGoster(m1);

        musteriYonetımPaneli.sahipOlduguHayvanlariGoster(m2);
    }


}
