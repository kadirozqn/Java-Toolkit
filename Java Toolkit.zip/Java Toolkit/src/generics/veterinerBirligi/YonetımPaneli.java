package generics.veterinerBirligi;

public class YonetımPaneli <T>{
    public void bilgileriGoster(T nesne){
        System.out.println("\nYönetim paneli başlatılıyor...");
        System.out.println(nesne);
    }
    public <T extends  Musteri> void sahipOlduguHayvanlariGoster(T musteri){
       musteri.musteriHayvanlariniListele();
    }
    public void veterinerinMusterileriniListele(T veteriner){
        ((Veteriner)veteriner).musterileriListele();
    }
}
