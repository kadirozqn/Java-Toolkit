package generics;

public class IntegerDiziYazdir {
    public static void IntegerYazdir(int [] dizi){
        for(int gecici : dizi){
            System.out.println(gecici);
        }

    }
}
