package generics;

public class CharDiziYazdir {
    public static void CharYazdir(char [] dizi){
        for(char gecici : dizi){
            System.out.println(gecici);
        }

    }
}
