package generics.rasyonel_sayi_test;

public class Test {
    public static void main(String[] args) {
        
    }
}
