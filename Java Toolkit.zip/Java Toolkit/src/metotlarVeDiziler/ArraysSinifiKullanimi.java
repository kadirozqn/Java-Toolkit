package metotlarVeDiziler;

import java.util.Arrays;

public class ArraysSinifiKullanimi {
    public static void main(String[] args) {
        int sayilar[]={12,5,-8,36,98,25,3,4};
        int sayilar2[]={12,5,-8,36,98,25,3,4};
        System.out.println("\nSıralama öncesi dizi ");
        diziYazdir(sayilar);

        //Arrays.sort(sayilar);
        //Arrays.sort(sayilar,2,5); //belırlı bır ındextekı degerlerı sıralar
        Arrays.parallelSort(sayilar); //daha hızlı calısır
        Arrays.parallelSort(sayilar2);
        System.out.println("\nSıralama sonrası dizi ");
        diziYazdir(sayilar);

        int sonuc = Arrays.binarySearch(sayilar,25);
        System.out.println("\nAradıgınız deger "+sonuc+". elemanda bulunuyor. ");
        System.out.println("sayilar ve sayilar2 dizileri eşit mi? : "+Arrays.equals(sayilar,sayilar2));

        int yeniDizi[] = new int [30];
        Arrays.fill(yeniDizi,45);
        //Arrays.fill(yeniDizi,0,5,45); 0 ve 5ıncı ındıslerıne 45 atarken dıgerlerıne varsayılan olarak 0 degerını atayacaktır.
        System.out.println("\nYeni dizi:");
        diziYazdir(yeniDizi);
    }
    public static void diziYazdir(int [] dizi){
        for(int i : dizi  ){
            System.out.print(i+ ",");
        }
    }
}
