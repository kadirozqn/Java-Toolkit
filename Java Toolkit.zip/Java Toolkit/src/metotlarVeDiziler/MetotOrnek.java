package metotlarVeDiziler;

import java.util.Scanner;

public class MetotOrnek {
    public static void main(String[] args) {
    int kullaniciSecimi = -1;
    /*while(kullaniciSecimi != 0){
        kullaniciSecimi = menuGoster();
    }*/
        for(;;){
            kullaniciSecimi = menuGoster();
            if (kullaniciSecimi == 0) {
                break;
            }
            Scanner tara = new Scanner(System.in);
            System.out.print("Bırıncı sayıyı gırın: ");
            int sayi1 = tara.nextInt();
            System.out.print("Ikıncı sayiyi girin: ");
            int sayi2 = tara.nextInt();

            switch (kullaniciSecimi){
                case 1 : topla(sayi1,sayi2); break;
                case 2 : cıkarma(sayi1,sayi2); break;
                case 3 : carp(sayi1,sayi2); break;
                case 4 : bolme(sayi1,sayi2); break;
                case 5 : bul(5); break;
            }
        }
        System.out.println("Programdan cıkıldı. ");
    }
    public static int menuGoster(){
        System.out.println("-------------- MENU ---------------");
        System.out.println("1- Toplama islemi ");
        System.out.println("2- Cıkarma islemi ");
        System.out.println("3- Carpma islemi  ");
        System.out.println("4- Bolme islemi   ");
        System.out.println("5- Pozıtıf mı negatıf mı   ");
        System.out.println("Cıkmak ıcın 0' a basınız!");
        System.out.print("Lutfen yapmak ıstedıgınız ıslemı secınız: ");
        Scanner tara = new Scanner(System.in);
        int secim = tara.nextInt();
        return secim;
    }
    public static int topla(int a, int b){
        System.out.println("Bırıncı sayi: "+a+" Ikıncı sayi: "+ b+" Toplam degeri: "+ (a+b));
        return (a+b);
    }
    public static int cıkarma (int a, int b){
        System.out.println("Bırıncı sayi: "+a+" Ikıncı sayi: "+ b+" Fark degeri: "+ (a-b));
        return (a-b);
    }
    public static int carp(int a, int b){
        System.out.println("Bırıncı sayi: "+a+" Ikıncı sayi: "+ b+" Carpım degeri: "+ (a*b));
        return (a*b);
    }
    public static double bolme (double a, double b){
        System.out.println("Bırıncı sayi: "+a+" Ikıncı sayi: "+ b+" Bolum degeri: "+ (a/b));
        return (a/b);
    }
    private static String bul(int a){
        if(a>0){
            System.out.println("Girmiş oldugunuz "+a+" sayisi pozitiftir.");
        }
        else if(a==0){
            System.out.println("Girmiş oldugunuz "+a+" sayisi sıfıra eşittir.");
        }
        else if(a<0){
            System.out.println("Girmiş oldugunuz "+a+" sayisi negatiftir.");
        }
        else {
            return "";
        }
        return "";
    }
}