package metotlarVeDiziler;

public class MetotlarGiris {
        public static void main(String[] args) {
            menuGoster();
            topla(15,5);
            int sayi = 5;
            degistir(sayi);
            System.out.println("Sayi degıskenının degeri: "+sayi ); //sayının degerı metottan cıkıldıgı zaman her zaman aynı kalır.
            System.out.println("Fark metodu: "+farklariniAl(10,6));
            //int donulenDeger = farklariniAl(10,6);
            //System.out.println("Fark: "+donulenDeger);
            int rastgeleSayi = (int) (Math.random()*10+1); // parametre almayan ve gerıye deger donduren fonksıyon.
            System.out.println("Rastgele uretılen sayi: "+rastgeleSayi);
        }
        //gerıye deger donduren parametrelı metod.
        public static int farklariniAl(int a,int b){
            //System.out.println("İki sayinin farkını bulan metot: "+(a-b));
            return (a-b);
        }
        public static void degistir(int x){
            x +=20;
            System.out.println("Gırılen sayının 10 fazlası: "+x);
        }
        //parametre alan fonksıyon
        public static void topla(int a, int b){
            System.out.println("Girilen a değeri:  "+ a +" \nGirilen b değeri: "+ b + "\nSonuç: "+ (a+b));
        }
        public static void menuGoster(){
            //parametre almayan fonksıyon.
            System.out.println("---------Menu----------");
            System.out.println("1-İki sayinin toplamini bul: ");
            System.out.println("2-İki sayinin farkini bul: ");
            System.out.println("2-İki sayinin carpimini bul: ");
            System.out.println("2-İki sayinin bolumunu bul: ");
        }
    }



