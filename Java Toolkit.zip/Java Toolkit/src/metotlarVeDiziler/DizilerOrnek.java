package metotlarVeDiziler;

import java.util.Scanner;

public class DizilerOrnek {
    public static void main(String[] args) {
        //Çözüm 1
        int sayilar[] = new int[10];
        for(int i=0; i<sayilar.length; i++){
            //sayilar[i]=i*i;
            sayilar[i]= (int)Math.pow(i,2);
            System.out.println("Degerler: " +sayilar[i]); //ekran cıktısını ayrı bır dongude de yapabılırdık.
        }
        System.out.println("-----------------------------------------------------------------------------------------");
        for (int i = 0; i < sayilar.length; i++) {
            System.out.println("Degerler: " + sayilar[i]);
        }
        //Çözüm 2
        String aylar[] ={"Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","eYLÜL","Ekim","Kasım","Aralık"};
        Scanner tara = new Scanner(System.in);
        System.out.println("Lütfen ay degerını rakamla belırtınız: ");
        int ay = tara.nextInt();
        System.out.println("Secmıs oldugunuz ay: "+aylar[ay -1]);

        //Çözüm 3
        System.out.print("Kaç adet sayinin ortalamasını bulmak ıstıyorsunuz? \nLütfen rakamla belirtiniz: ");
        int sayi = tara.nextInt();

        int kullaniciSayilari []= new int[sayi];

        double ortalama = 0;
        for(int i=0; i<sayi; i++) {
            System.out.print( "Lütfen "+(i+1)+". sayiyi giriniz: ");
            kullaniciSayilari[i] = tara.nextInt();
            ortalama = ortalama + kullaniciSayilari[i];
        }
        System.out.println("Girmiş oldugunuz sayıların ortalaması: "+(ortalama/kullaniciSayilari.length));
    }
}
