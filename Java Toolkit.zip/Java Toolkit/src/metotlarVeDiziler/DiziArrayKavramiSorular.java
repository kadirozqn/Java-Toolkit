package metotlarVeDiziler;

import java.util.Scanner;

public class DiziArrayKavramiSorular
{
    public static void main(String[] args)
    {
        //çözüm 1
        int sayilar[] = new int[10];
        System.out.println("Dizi boyutu: " + sayilar.length);
        for (int index = 0; index < sayilar.length; index++)
            {
                //sayilar [index] = index * index;
                sayilar[index] = (int) Math.pow(index, 2);
                System.out.println(index + "." + " Deger: " + sayilar[index]);
            }

        System.out.println("---------------------------------------------------- ");
        //çözüm 2
        //String [] aylar = new String[12];
        String[] aylar = {"Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz","Ağustos", "Eylül", "Ekim","Kasım", "Aralık"};
        Scanner tara = new Scanner(System.in);
        System.out.println("Ay degerini lütfen rakamla yazınız:");
        int ay = tara.nextInt();

        System.out.println("Sectiginiz ay:"+aylar[ay-1] );

        System.out.println("---------------------------------------------------- ");

        //çözüm 3
        System.out.println("Kaç adet sayının ortalamasını bulmak istiyorsunuz? :");
        int adet = tara.nextInt();

        int kullaniciSayisi [] = new int[adet];

        double ortalama = 0;
        double sonuc = 0;
        for (int i = 0; i<adet;i++)
        {

            System.out.println("Sayi giriniz: \n");
            kullaniciSayisi [i] = tara.nextInt();
            ortalama = ortalama + kullaniciSayisi[i];
            sonuc = ortalama / adet;

        }
        for (int index =0; index<kullaniciSayisi.length; index ++)
        {
            System.out.println(index + ". girmiş oldugunuz deger: " + kullaniciSayisi[index]);
        }
        System.out.println("Ortalama degeri: " + sonuc);
    }




    }
