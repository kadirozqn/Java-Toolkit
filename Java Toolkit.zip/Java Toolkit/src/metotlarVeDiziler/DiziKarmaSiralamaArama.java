package metotlarVeDiziler;

public class DiziKarmaSiralamaArama {
    public static void main(String[] args) {
        int sayilar[] = {5, 7, 85, 4, 15, 18, 74, 52};
        System.out.println("Dizimizin orijinal hali.");
        diziYazdir(sayilar);
        System.out.println("---------------------------------------------------------");
        System.out.println("Yer degıstırme metodundan sonra dızının aldıgı son hal: ");
        yerDegistir(sayilar);
        diziYazdir(sayilar);
        System.out.println("---------------------------------------------------------");
        selectionShort(sayilar);
        System.out.println("Sıralama metodundan sonra dızının aldıgı son hal: ");
        diziYazdir(sayilar);
        System.out.println("---------------------------------------------------------");
        System.out.println("Bınary Search ıle eleman buluyoruz.");
        int sonuc = binarySearch(sayilar,4);
        System.out.println("Aranan sonuc dizini " +sonuc+". elemanında bulunuyor. ");
    }

    public static int binarySearch(int[] dizi, int aranacakEleman) {
        int enDusukIndex = 0;
        int enYuksekIndex = dizi.length - 1;

        while (enYuksekIndex >= enDusukIndex) {
            int ortaIndex = (enDusukIndex + enYuksekIndex) / 2;
            if (aranacakEleman < dizi[ortaIndex]) {
                enYuksekIndex = ortaIndex - 1;
            } else if (aranacakEleman == dizi[ortaIndex]) {
                return ortaIndex; //aranılacak elemanın bulundugu ındexı dondurur.
            } else {
                enDusukIndex = ortaIndex + 1;
            }
        }
        return -enDusukIndex -1;
    }
    private static void selectionShort(int[] dizi) {
        for (int i = 0; i< dizi.length - 1; i++) {
            //en kucuk elemanın ındexının bulunması
            int oankiEnKucukSayi = dizi[i];
            int oankiEnKucukElemanınIndex = i;

            for (int j = i + 1; j < dizi.length; j++) {
                if (oankiEnKucukSayi > dizi[j]) {
                    oankiEnKucukSayi = dizi[j];
                    oankiEnKucukElemanınIndex = j;
                }
            }
            if (oankiEnKucukElemanınIndex != i) {
                dizi[oankiEnKucukElemanınIndex] = dizi[i];
                dizi[i] = oankiEnKucukSayi;
            }
        }
    }
        private static void yerDegistir ( int[] dizi){
            for (int i = dizi.length - 1; i > 0; i--) {
                int rastegeleIndex = (int) Math.random() * (i + 1);

                int gecici = dizi[i];
                dizi[i] = dizi[rastegeleIndex];
                dizi[rastegeleIndex] = gecici;
            }
        }
        public static void diziYazdir ( int[] dizi){
            for (int i = 0; i < dizi.length; i++) {
                System.out.println(i + ". Eleman: " + dizi[i]);
            }

        }
    }

