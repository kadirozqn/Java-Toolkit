package metotlarVeDiziler;

public class GelismisForDongusu {
    public static void main(String[] args) {

        int sayilar[]= {1,-12,45,23,6,45,-14};
        for (int i =0; i<sayilar.length; i++){
            System.out.println("Klasık for dongusu ıle elemanlar: " +sayilar[i]);
        }
        System.out.println("-------------------------------------------------------------\nForeach dongusu:");
        //Foreach(Gelısmıs for dongusu) ıle ekrana yazdırma
        for (int yeniSayi : sayilar){
            System.out.println("Foreach ıle elemeanlar: " + yeniSayi);
        }
        System.out.println("--------------------------------------------------------------");
        String elemanlar[]={"Kadir", "Ayşenur","Ali","Abdulselam","Fatma","Özan"};
        /*for(String goster : elemanlar){
            System.out.println("Strıng turunden elemanlar: "+ goster);*/
        diziYazdir(elemanlar);
            System.out.println("-----------------------------------------------------------");
    }
    public static void diziYazdir(String dizi[]){
        for(String s : dizi )
            System.out.println("Fonksıyon yardımıyla gosterım : "+ s);

    }
}
