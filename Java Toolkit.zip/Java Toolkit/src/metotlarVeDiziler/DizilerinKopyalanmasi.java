package metotlarVeDiziler;

public class DizilerinKopyalanmasi {
    public static void main(String[] args) {

        int anaDizi[] = {1, 7, 9, 10};
        int kopyaDizi[] = new int[anaDizi.length];
        //manuel yontem
        for (int i = 0; i < anaDizi.length; i++) {
            kopyaDizi[i] = anaDizi[i];
        }
        for (int kopya : kopyaDizi) {
            System.out.println("Degerler: " + kopya);
        }
        //arraycopy
        int kopyaDizi2[] = new int[anaDizi.length];
        System.arraycopy(anaDizi, 0, kopyaDizi2, 0, anaDizi.length);
        //degerleriYazdir(kopyaDizi2);

        int denemeDizisi[] = new int[anaDizi.length];

        denemeDizisi  = anaDizi;

        kopyaDegerleriYazdir(denemeDizisi);
        System.out.println("-------------------------------------------");
        degerleriYazdir(anaDizi);

        anaDizi[0] = 100;
        System.out.println("Ana dizideki ilk eleman degıstırıldı. ");
        degerleriYazdir(anaDizi);
        System.out.println("-------------------------------------------");
        System.out.println("Deneme dizisi yazdırılıyor. ");
        kopyaDegerleriYazdir(denemeDizisi);

        int [] tersiOlusturulmusDizi = tersiniOlustur(anaDizi);
        System.out.println("100,7,9,70 degerlerinin tersi yazdırıldı.");
        degerleriYazdir(tersiOlusturulmusDizi);
    }
    public  static int[] tersiniOlustur (int[] dizi){
        int [] olusanDizi = new int [dizi.length];

        for(int i=0, j=dizi.length-1 ; i<dizi.length; i++,j--){
            olusanDizi[j]=dizi[i];
        }
        return olusanDizi;
    }

    private static void degerleriYazdir(int[] yazdirilacakDizi) {
        for (int deger : yazdirilacakDizi) {
            System.out.println("Ana dızının degerlerı: " + deger);
        }
    }

    private static void kopyaDegerleriYazdir(int[] yazdirilacakDizi) {
        for (int deger : yazdirilacakDizi) {
            System.out.println("Yenı Kopyalanan dızının degerleri: " + deger);
        }
    }
}

