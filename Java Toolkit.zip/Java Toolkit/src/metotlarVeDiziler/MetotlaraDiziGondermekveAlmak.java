package metotlarVeDiziler;

public class MetotlaraDiziGondermekveAlmak {
    public static void main(String[] args) {
        int sayilar [] = {1,2,3};
        //diziGoster(sayilar);

        System.out.println("Metottan oncekı deger: "+sayilar[0]);
        degeriBirArttir(sayilar);
        System.out.println("Metottan sonrakı deger: "+sayilar[0]);

        degeriBirAzalt(sayilar);

        System.out.println("Dizi degerlerı arttırmadan once");
        diziGoster(sayilar);
        degerArttir(sayilar);
        System.out.println("Dizi degerlerını arttırdıktan sonra ");
        diziGoster(sayilar);

        toplaminiBul(8,6,3,4,8,5,6,5,8);//metotların overloadıng olmasına guzel bır ornek

    }
    /*private static void toplaminiBul(int i, int j){
        System.out.println("2 parametreli fonksıyon cagırıldı. ");
        int toplam = 0;
        toplam = i+j;
        System.out.println("İlk parametere: "+i);
        System.out.println("İkinci parametre: "+j);
        System.out.println("Gonderılen degerlerın toplamı : "+toplam);
    }
    private static void toplaminiBul(int i, int j, int k){
        System.out.println("3 parametreli fonksıyon cagırıldı. ");
        int toplam = 0;
        toplam = i+j+k;
        System.out.println("İlk parametere: "+i);
        System.out.println("İkinci parametre: "+j);
        System.out.println("Ucuncu parametre: "+k);
        System.out.println("Gonderılen degerlerın toplamı : "+toplam);
    }*/
    private static void toplaminiBul(int... parametreListesi){ //overloadıng ıslemının kısa yontemı!
        int toplam = 0;
        for(int oankiSayi : parametreListesi){
            //toplam =toplam+oankiSayi;
            toplam+=oankiSayi;
            System.out.println("Degerler: "+oankiSayi);
        }
        System.out.println("Parametre Listesinin ılk elemanı: "+parametreListesi[0]);
        System.out.println("Parametre Listesinin ıkıncı elemanı: "+parametreListesi[1]);
        System.out.println("Parametre Listesinin ucuncu elemanı: "+parametreListesi[2]);
        System.out.println("Parametre Listesinin dorduncu elemanı: "+parametreListesi[3]);

        System.out.println("Gonderılen degerlerın toplamı : "+toplam);
    }

  public static void diziGoster(int[]dizi){
        for(int i:dizi){
            System.out.println("eleman: "+i);
        }
  }
  private static void degerArttir(int[] sayilar){
        sayilar[0]++;
        sayilar[1]++;
        sayilar[2]++;
    }
    private static void degeriBirArttir(int dizi[]){
       dizi[0]++;
    }
    private static void degeriBirAzalt(int dizi[]){
        dizi[0]--;
    }
}
