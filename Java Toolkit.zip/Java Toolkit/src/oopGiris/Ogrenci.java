package oopGiris;

public class Ogrenci {
    private int ogrenciNo;
    private byte sinif;
    private String isim;
    private boolean aktif;

    public void setOgrenciNo(int yeniOgrenciNo){
        this.ogrenciNo = yeniOgrenciNo;
    }
    public void setSinif(byte yeniSinif){
        this.sinif = yeniSinif;
    }
    public void setIsim(String yeniİsim){
        this.isim = yeniİsim;
    }
    public boolean isAktif(){
        return aktif;
    }
    public byte getSinif(){
        return this.getSinif();
    }
    public int getOgrenciNo(){
        return this.ogrenciNo;
    }
    public String getIsim(){
        return this.isim;
    }
    public boolean getAktif(){
        return this.aktif;
    }

public Ogrenci(){
    System.out.println("Parametresiz constuctor çalıştı. ");
}
public Ogrenci(int ogrenciNo){
    this.ogrenciNo = ogrenciNo;
    System.out.println("Bir parametre alan constructor çalıştı. ");
}
public Ogrenci(int ogrenciNo, String isim){

    //this.ogrenciNo = ogrenciNo;
        this(ogrenciNo);
        this.isim= isim;
        System.out.println("İki parametre alan constructor çalıştı. ");
}
public Ogrenci(int ogrenciNo, String isim,byte sinif){
        /*this.ogrenciNo = ogrenciNo;
        this.isim= isim;*/
        this(ogrenciNo,isim);
        this.sinif = sinif;
        System.out.println("Üç parametre alan constructor çalıştı. ");

}
public Ogrenci(int ogrenciNo, String isim,byte sinif,boolean aktif){

        /*this.ogrenciNo = ogrenciNo;
        this.isim= isim;
        this.sinif = sinif;*/
        this(ogrenciNo,isim,sinif);
        this.aktif = aktif;
        System.out.println("Dört parametre alan constructor çalıştı. ");
}
public void ogrenciBilgileriniYazdir() {
    if(aktif){
        System.out.println("Adım : "+isim+ " Numaram: "+ogrenciNo+" sinifim: "+sinif+" Durum : aktif" );
    }
    else{
        System.out.println("Öğrenci durumu aktif değil. ");
    }
}
}

