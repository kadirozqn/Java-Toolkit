package oopGiris;

public class Encapsulation {
    public static void main(String[] args) {
        /*Ogrenci ogr1 = new Ogrenci(2221200,"Kadir",(byte) 10,true);
        ogr1.ogrenciBilgileriniYazdir();
        ogr1.setOgrenciNo(1015);
        ogr1.ogrenciBilgileriniYazdir();
        System.out.println("Ogrencının yenı numarası: "+ ogr1.getOgrenciNo());
        ogr1.setIsim("Fatma");
        ogr1.ogrenciBilgileriniYazdir();
    */

        Televizyon tv1 = new Televizyon();
        tv1.ac();
        tv1.setSesSeviyesi(95);
        tv1.setKanal(600);
        tv1.goster();
    }

}
