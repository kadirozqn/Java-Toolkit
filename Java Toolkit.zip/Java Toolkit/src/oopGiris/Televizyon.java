package oopGiris;

public class Televizyon {
    private int kanal;
    private int sesSeviyesi;
    private boolean acKapa;

    public int getKanal() {
        return kanal;
    }
    public void setKanal(int yeniKanal){
    if (acKapa && yeniKanal >0 && yeniKanal < 500){
        kanal = yeniKanal;
    }
    else {
        System.out.println("Tv kapalı veya yanlış bir kanal tercıhı yaptınız. (kanal degeri 0 ve 500 arasında olmalı. ) ");
        kanal = 1;
    }
}

    public int getSesSeviyesi() {
        return sesSeviyesi;
    }

    public void setSesSeviyesi(int sesSeviyesi) {
        if ( acKapa && sesSeviyesi>0 && sesSeviyesi <20){
            this.sesSeviyesi = sesSeviyesi;
        }
        else sesSeviyesi = 1;
    }

    public void ac() {
        if (acKapa == false) {
            System.out.println("Televizyon açılıyor...");
            acKapa = true;
        }
        else{
            System.out.println("Televizyon zaten açık!");
        }
    }
    public void kapat() {
        if (acKapa == true){
            System.out.println("Televizyon kapatılıyor...");
            acKapa = false;
        }
        else {
            System.out.println("Televizyon zaten kapalı!");
        }
    }
    public void goster(){
        System.out.println("Tv açık     : "+ acKapa);
        System.out.println("Kanal       : "+kanal);
        System.out.println("Ses seviyesi: " +sesSeviyesi);
    }
}
