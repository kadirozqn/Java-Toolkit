package oopGiris;

public class ImmutableVeMetotaNesneGonderme {
    public static void main(String[] args) {
        String[] ureticiMarkalari = {"HP", "ASUS", "DELL"};
        Bilgisayar b1 = new Bilgisayar(4, 16, new String[]{"HP", "ASUS", "DELL"});
        bilgisayarYazdir(b1);

        String[] ureticiler = b1.getUreticiMarka();
        ureticiler[0] = "Apple";
        bilgisayarYazdir(b1); // referans turdekı verı tıplerınde ımmutable turler ıse yaramaz.

    }
    public static void bilgisayarYazdir(Bilgisayar yazdirilacakPC){
        System.out.println("Çekirdek sayisi: "+yazdirilacakPC.getCekirdekSayisi()+ " Ram mıktari: "+ yazdirilacakPC.getRampKapasitesi()
        +" Üretici firmalar: "+ yazdirilacakPC.getUreticiMarka()[0]);
    }
}
class Bilgisayar{

    private int cekirdekSayisi;
    private int rampKapasitesi;
    private String [] ureticiMarka;

    public Bilgisayar(int cSayisi, int rampKapasitesi1,  String[]ureticiMarkaAdlari){
        this.cekirdekSayisi =cSayisi;
        this.rampKapasitesi = rampKapasitesi1;
        this.ureticiMarka = ureticiMarkaAdlari;
    }

    public String[] getUreticiMarka() {
        String [] kopyaDegerler = new String[ureticiMarka.length];

        for (int i=0; i<kopyaDegerler.length;i++){
            kopyaDegerler[i] = ureticiMarka[i];
        }
        return kopyaDegerler;
    }

    public int getCekirdekSayisi() {
        return cekirdekSayisi;
    }

    public int getRampKapasitesi() {
        return rampKapasitesi;
    }

}
