package oopGiris;

public class oopGirisKavramlar {
    public static void main(String[] args) {
        Ogrenci [] tumOgrenciler = new Ogrenci[500];
        int sayi =1;

        /*Ogrenci kadir = new Ogrenci();
        kadir.isim = "Kadir Özan";
        kadir.sinif = 12;
        kadir.ogrenciNo =6518;
        kadir.aktif = true;

        kadir.ogrenciBilgileriniYazdir();

        Ogrenci ali = new Ogrenci();
        ali.isim= "Ali Özan";
        ali.ogrenciNo = 1265;
        ali.sinif =11;

        ali.ogrenciBilgileriniYazdir();

        Ogrenci bos = new Ogrenci();

        bos.ogrenciBilgileriniYazdir();

        Ogrenci ahmet = new Ogrenci(500,"Ahmet Aslan",(byte)11,true);
        ahmet.ogrenciBilgileriniYazdir();

        kadir = ahmet; //Referans turunde degıskenler oldugu ıcın kadır artık ahmetın bellek adresını tutacak ve ahmetın bılgılerını saklayacak.
        System.out.println("KADİR'İN BİLGİLERİ YAZDIRILACAK:");
        kadir.ogrenciBilgileriniYazdir();
        System.out.println("AHMET'IN BİLGİLERİ YAZDIRILACAK:");
        ahmet.ogrenciBilgileriniYazdir();

        Ogrenci ogr1 = new Ogrenci();
        Ogrenci ogr2 = new Ogrenci(22221200);
        Ogrenci ogr3 = new Ogrenci(22221200, "Kadir");
        Ogrenci ogr4 = new Ogrenci(22221200, "Kadir ", (byte)12);
        Ogrenci ogr5 = new Ogrenci(22221200, "Kadir ", (byte)12, true);

        tumOgrenciler[0] = ogr1;
        tumOgrenciler[1] = ogr2;
        tumOgrenciler[2] = ogr3;
        tumOgrenciler[3] = ogr4;
        tumOgrenciler[4] = ogr5;
        tumOgrenciler[5] = new Ogrenci(6512,"Selahattin",(byte)9,true);
        tumOgrenciler[5].ogrenciBilgileriniYazdir();

        tumOgrenciler[2].aktif = true;
        tumOgrenciler[2].sinif=11;
        tumOgrenciler[2].ogrenciBilgileriniYazdir();
    */
    }
}
