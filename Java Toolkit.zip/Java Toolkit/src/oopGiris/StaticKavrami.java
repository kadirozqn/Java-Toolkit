package oopGiris;

public class StaticKavrami {
    public static void main(String[] args) {
        Memur m1 =  new Memur();
        m1.setIsim("Kadir");
        System.out.println("İsim: "+m1.getIsim());
        m1.setMaas(60000);
        System.out.println("Maas: "+m1.getMaas());

        Memur m2 =  new Memur();
        m2.setIsim("Fatma");
        System.out.println("İsim: "+m2.getIsim());
        m2.setMaas(45000);
        System.out.println("Maas: "+m2.getMaas());

        Memur m3 =  new Memur();
        m3.setIsim("Ali");
        System.out.println("İsim: "+m3.getIsim());
        m3.setMaas(75000);
        System.out.println("Maas: "+m3.getMaas());

        System.out.println("m1 için nesne sayisi: "+ m1.nesneSayisi);
        System.out.println("m2 için nesne sayisi: "+ m2.nesneSayisi);
        System.out.println("m3 için nesne sayisi: "+ m3.nesneSayisi);
        System.out.println("Sınıf için nesne sayisi: "+ Memur.nesneSayisi);
        Memur.kanunuSoyle();
        m1.kanunuSoyle();
        m2.kanunuSoyle();
        m3.kanunuSoyle();
    }

}

class Memur {
    private String isim;
    private int maas;
    //private static int olusturlanMemurNesnesi;
    public static  int nesneSayisi; // static anahtar kelıemesı ıle bu degıskene veya metoda hem sınıftan hem nesneden ulasabılıriz.

    public Memur(){
        nesneSayisi++;
        System.out.println("Ana constuctor calıstı.");
        System.out.println("Olusturulan memur nesnesı sayısı : "+nesneSayisi);
    }
    public int getMaas() {
        return maas;
    }

    public void setMaas(int maas) {
        if(maas<0){
            maas = 0;
        }
        else{
            this.maas = maas;
        }
    }

    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }
    public static void kanunuSoyle(){ // hem sınıftan hem nesneden erişilebilir. static anahtar sozcugu ıle.
        System.out.println("657 nolu kanun.");
    }

    public void bilgileriYazdir(){
        System.out.println("Olusturulan Memur nesnesi sayısı: "+nesneSayisi);
    }
}