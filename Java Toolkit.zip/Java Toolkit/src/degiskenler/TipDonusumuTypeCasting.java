package degiskenler;

public class TipDonusumuTypeCasting {
    public static void main (String[] args){
        int sayi = 12;
        double degistirilmek_istenen_deger=225.45652F;
        /*sayi1 = sayi;
        System.out.println("Noktalı sayinin degeri: "+sayi1);*/
        sayi=(int)degistirilmek_istenen_deger;
        System.out.println("Sayi degeri: "+ sayi);

        double sayi3 =3.5;
        int degistirilmekistenen_deger2 = 14;
        sayi3=(int)degistirilmekistenen_deger2;
        System.out.println("Sayi degeri : " + degistirilmekistenen_deger2);


        byte sayi2= 5;
        sayi2= (byte) degistirilmek_istenen_deger;
        System.out.println("Sayi2 degeri: "+sayi2); // hatalı ıslem byte olarak degıl ınteger veya short kullanmamız gerekırdı.*/
    }
}
