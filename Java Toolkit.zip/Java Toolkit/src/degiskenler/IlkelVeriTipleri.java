package degiskenler;

public class IlkelVeriTipleri {
    public static void main(String[]args){
    int IntegerDeger= 15;
    double DoubleDeger = 45;
        System.out.println(" Tam sayi veri turlerı için");
        //Asagıdakı ifadeler tam sayı verı turlerının ozellıklerını yazdırır.
        System.out.println("Byte'ın en kucuk degerı: "+Byte.MIN_VALUE + ", Byten'ın en buyuk degeri: "+ Byte.MAX_VALUE+ ", Bıt degeri: "+ Byte.SIZE);
        System.out.println("Short'un en kucuk degerı: "+Short.MIN_VALUE + ", Short'un en buyuk degeri: "+ Short.MAX_VALUE+ ", Bıt degeri: "+ Short.SIZE);
        System.out.println("Integer'ın kucuk degerı: "+Integer.MIN_VALUE + ", Integer'ın en buyuk degeri: "+ Integer.MAX_VALUE+ ", Bıt degeri: "+ Integer.SIZE);
        System.out.println("Long'un en kucuk degerı: "+Long.MIN_VALUE + ", Long'un en buyuk degeri: "+ Long.MAX_VALUE+ ", Bıt degeri: "+ Long.SIZE);
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------\n Ondalıklı veri türleri için;");

        //Asagıdakı ifadeler ondalıklı sayı verı turlerı ozellıklerını yazdırır.
        System.out.println("Float'ın en kucuk degerı: "+Float.MIN_VALUE + ", Float'ın en buyuk degeri: "+ Float.MAX_VALUE+ ", Bıt degeri: "+ Float.SIZE);
        System.out.println("Double'ın en kucuk degerı: "+Double.MIN_VALUE + ", Double'ın en buyuk degeri: "+ Double.MAX_VALUE+ ", Bıt degeri: "+ Double.SIZE);

        System.out.println("----------------------------------------------------------------------------------------------------------------------------------");
        //char
        char harf = 'a';
        System.out.println("Harf degerı: " + harf);

        int harf1= 'a';
        System.out.println("Integer harf degerı: "+ harf1);

        //boolean
        boolean deger = true;
        System.out.println("Boolean deger: "+deger);
        boolean deger1 = false;
        System.out.println("Booelan deger: "+deger1);

    }

}
