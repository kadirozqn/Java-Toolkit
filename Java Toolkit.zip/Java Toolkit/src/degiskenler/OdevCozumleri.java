package degiskenler;

import java.sql.SQLOutput;

public class OdevCozumleri {
    public static void main(String[]args){
        //odev1 cozumu 1
        String stringDegisken = "150";
        int IntegerDegisken =Integer.parseInt(stringDegisken);
        int IntegerDegisken1 = Integer.valueOf(stringDegisken);

        System.out.println("Integer degısken 1 degeri  : "+IntegerDegisken);
        System.out.println("Intyeger degisken 2 degeri : "+IntegerDegisken1);

        stringDegisken = String.valueOf(IntegerDegisken);
        System.out.println("String deg,skeninin son degeri: "+stringDegisken);

        System.out.println("-----------------------------------------------------------------------------------------");
        //odev cozumu 2
        int sayi1 = 5 / 3;
        float sayi2 = 5f / 3f; //float 7 karakter saklamıs(vırgulden sonra)
        double sayi3= 5d / 3d;
        System.out.println("sayi1 degiskenin degeri:  "+sayi1);
        System.out.println("sayi2 degiskeninin degeri: "+sayi2);
        System.out.println("sayi3 degiskeninin degeri: "+sayi3);

        System.out.println("-----------------------------------------------------------------------------------------");
        //odev cozumu 3
        System.out.println(1.0 - 0.1 - 0.1 - 0.1 - 0.1 - 0.1); //0.5 degerını gormeyı beklıyoruz.
        System.out.println(1.0 - 0.9); //0.1 degerını gormeyı beklıyoruz. 0.100000000000000000 gibi

        System.out.println("-----------------------------------------------------------------------------------------");

        //odev cozumu 4
        int s1 = 25;
        int s2 = 6;

        double ortalama =(s1+s2)/2;
        System.out.println("Ortalama degeri: " +ortalama); //yanlıs kullanım
        double ortalama2 = (s1+s2) /2.0;
        System.out.println("Ortalama2 degeri: "+ortalama2); //dogru kullanım
        double ortalama3 = (double)(s1+s2)/2;
        System.out.println("Ortalama 3 degeri:"+ ortalama3); //dogru kullanım



    }
}
