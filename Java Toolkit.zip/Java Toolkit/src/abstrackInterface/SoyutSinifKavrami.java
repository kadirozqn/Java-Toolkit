package abstrackInterface;

public class SoyutSinifKavrami {
    public static void main(String[] args) {
        System.out.println("Kare:");
        GeometrikSekil kare = new Kare(15);
        kare.alanHesapla();
        kare.cevreHesaapla();
        ((Kare) kare).kareGoster(); //kareGoster metodu sadece Kare sınıfına ozgu oldugu ıcın normal cagırımda hata verır. cast ıslemı yaparız.

        System.out.println("Diktörtgen:");
        Diktortgen d1 = new Diktortgen(4,2);
        d1.alanHesapla();
        d1.cevreHesaapla();
        d1.diktortgenGoster();// dırekt olarak dıktortgen sınıfından nesne olusturdugumuz ıcın cast ıslemıne gerek yok.
        // GeometrıkSekıl sınıfından uretseydık cast ıslemı yapmamız gerekecektı. yukarıda oldugu gıbı.

        System.out.println("Daire:");
        GeometrikSekil daire = new Daire(12);
        daire.alanHesapla();
        daire.cevreHesaapla();
        ((Daire)daire).daireGoster(); // cast ıslemını gerceklestırdık

        alanlariKarsilastir(kare,daire);
        cevreKarsilastir(kare,daire);

    }
    public static void alanVeCevreyiGoster(GeometrikSekil gs1){
        gs1.cevreHesaapla();
        gs1.alanHesapla();
    }
    public static void cevreKarsilastir(GeometrikSekil gs1, GeometrikSekil gs2){
        if(gs1.getHesaplananCevre()<gs2.getHesaplananCevre()){
            System.out.println("Birinci parametrede hesaplanan çevre ikinci parametrede hesaplanann çevreden küçüktür.");
        }
        else if(gs1.getHesaplananCevre()>gs2.getHesaplananCevre()){
            System.out.println("Birinci parametrede hesaplanan çevre değeri ikinci parametrede hesaplanan çevreden büyüktür.");
        }
        else{
            System.out.println("İki parametrede de hesaplanan çevre değerleri birbirine eşittir.");
        }
    }
    public static void alanlariKarsilastir(GeometrikSekil gs1, GeometrikSekil gs2){
        if(gs1.getHesaplananAlan()<gs2.getHesaplananAlan()){
            System.out.println("Birinci parametredeki hesaplanan alan ikinci parametrede hesaplanan alandan küçüktür.");
        } else if (gs1.getHesaplananAlan()>gs2.getHesaplananAlan()) {
            System.out.println("Birinci parametredek hesaplanan alan ikinci parametrede hesaplanan alandan büyüktür");
        }
        else {
            System.out.println("İki parametrede de hesaplanan alanlar birbirine eşittir.");
        }
    }
}
abstract class GeometrikSekil{
    private int birinciKenar;
    private int hesaplananAlan;
    private int hesaplananCevre;

    public int getHesaplananCevre() {
        return hesaplananCevre;
    }

    public void setHesaplananCevre(int hesaplananCevre) {
        this.hesaplananCevre = hesaplananCevre;
    }

    public int getHesaplananAlan() {
        return hesaplananAlan;
    }

    public void setHesaplananAlan(int hesaplananAlan) {
        this.hesaplananAlan = hesaplananAlan;
    }

    abstract public void cevreHesaapla();

    abstract public void alanHesapla();

    public int getBirinciKenar() {
        return birinciKenar;
    }

    public void setBirinciKenar(int birinciKenar) {
        this.birinciKenar = birinciKenar;
    }
}

class Kare extends GeometrikSekil{

    public Kare(int kenar) {
        this.setBirinciKenar(kenar);
    }

    @Override
    public void cevreHesaapla() {
        setHesaplananCevre(getBirinciKenar()*4);
        System.out.println("Kaerenin çevresi: "+getHesaplananCevre());
    }

    @Override
    public void alanHesapla() {
        setHesaplananAlan(getBirinciKenar() * getBirinciKenar());
        System.out.println("Karenin alanı: " + getHesaplananAlan());
    }
    public void kareGoster(){
        System.out.println("Ben bir kare sınıfı metoduyum.");
    }
}
class Diktortgen extends GeometrikSekil{
    public Diktortgen(int birinciKenar, int ikinciKenar) {
        setBirinciKenar(birinciKenar);
        this.ikinciKenar = ikinciKenar;
    }

    private int ikinciKenar;

    public int getIkinciKenar() {
        return ikinciKenar;
    }

    public void setIkinciKenar(int ikinciKenar) {
        this.ikinciKenar = ikinciKenar;
    }

    @Override
    public void cevreHesaapla() {
        setHesaplananCevre(2*(getBirinciKenar()+getIkinciKenar()+ikinciKenar));
        System.out.println("Diktörtgenin çevbresi: "+getHesaplananCevre());
    }

    @Override
    public void alanHesapla() {
        setHesaplananAlan(getBirinciKenar()*ikinciKenar);
        System.out.println("Diktörtgenin alanı: "+getHesaplananAlan());
    }
    public void diktortgenGoster(){
        System.out.println("Ben bir dıktortgen sınıfı metoduyum.");
    }
}
class Daire extends GeometrikSekil{
    private double pi =3.14;
    public Daire(int r) {
        setBirinciKenar(r);
    }

    public double getPi() {
        return pi;
    }

    public void setPi(double pi) {
        this.pi = pi;
    }

    @Override
    public void cevreHesaapla() {
        setHesaplananCevre((int)(2*getPi()*getBirinciKenar()));
        System.out.println("Dairenin çevresi: "+getHesaplananCevre());
    }

    @Override
    public void alanHesapla() {
        setHesaplananAlan((int)(getPi()*Math.pow(getBirinciKenar(),2)));
        System.out.println("Dairenin alan: "+ getHesaplananAlan());
    }
    public void daireGoster(){
        System.out.println("Ben bir daire sınıfı metoduyum. ");
    }
}
