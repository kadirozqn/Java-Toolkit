package abstrackInterface;

import java.util.ArrayList;

public class InterfaceKavrami {
    public static void main(String[] args) {

        Elma e = new Elma();
        Yenilenebilir y1 = new Elma();
        Yenilenebilir y2 = new Inek();

        ArrayList<Yenilenebilir> yeniBirSeyler = new ArrayList<>();
    }
}
interface Yenilenebilir{
    void yenmeSekli();
}
class Elma implements Yenilenebilir{

    @Override
    public void yenmeSekli() {

    }
}
class Inek implements Yenilenebilir{

    @Override
    public void yenmeSekli() {

    }
}