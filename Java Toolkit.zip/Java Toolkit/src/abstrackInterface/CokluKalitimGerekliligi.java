package abstrackInterface;

import java.util.ArrayList;

public class CokluKalitimGerekliligi {
    public static void main(String[] args) {
        PopSarkiciOzellikleri p1 = new Tarkan();
        PopSarkiciOzellikleri p2 = new Hadise();
        PopSarkiciOzellikleri dizi [] = new PopSarkiciOzellikleri[5];

        dizi [0] = p1;
        dizi [1] = p2;

        ArrayList<PopSarkiciOzellikleri> sarkicilar = new ArrayList<>();
        sarkicilar.add(p1);
        sarkicilar.add(p2);

        ArabeskSarkici a1 = new ArabeskSarkici();
        System.out.println("Arabesk sarkıcı ıcın: ");
        a1.yemekYe();
        a1.sarkiSoyle();
        a1.sporYap();
        a1.tuvaleteGit();
        System.out.println("Pop sarkıcı ıcın: ");
        p1.adiniSoyle();
        p1.adiniSoyle();
        p1.danset();
        p1.duetYap();
        p1.sporYap();
    }
}
abstract class Sarkici implements Kisi{ // soyut sınıfa ımplement edılen ınterface soyut sınıfta kullanılmak zorunda degıldır
    // ancak alt sınıflarında mutlaka kullanılmak zorundadır.
    abstract void sarkiSoyle();
}
interface Kisi {
    void yemekYe();
    void sporYap();
    void tuvaleteGit();
    default void adiniSoyle(){  // Bu ınterfacei ımplements ettıgımız sınıflarda dıger metotları ımplmenets etmemız
        // zorunluyken default olarak tanımladıgımız metodu ımplement etme zorunlulugumuz yoktur. bize kalmıs bır durum.
        System.out.println("Ben bir isi interface yim. ");
    };
}
interface ArabeskSarkiciOzellikleri {
    void sahnedeSigaraIc();
}
interface PopSarkiciOzellikleri extends  Kisi{
    void danset();
    void duetYap();
    static final int yas = 50;
interface OgrenciOzellikleri extends Kisi,UniversiteOgrencisi{
    void dersCalis();
    void okulaGit();
}
interface UniversiteOgrencisi{
    void finallereCalis();
}
class Students implements OgrenciOzellikleri{

    @Override
    public void yemekYe() {
        System.out.println("Ben yemek yerim ");
    }

    @Override
    public void sporYap() {
        System.out.println("Ben spor yaparım. ");
    }

    @Override
    public void tuvaleteGit() {
        System.out.println("Ben tuvalete gıderım. ");
    }

    @Override
    public void dersCalis() {
        System.out.println("Ben ders çalışırım. ");
    }

    @Override
    public void okulaGit() {
        System.out.println("Ben okula giderim. ");
    }

    @Override
    public void finallereCalis() {

    }
}

}
class ArabeskSarkici extends Sarkici{

    @Override
    void sarkiSoyle() {
        System.out.println("Ben arabesk şarkı söylüyorum. ");
    }

    @Override
    public void yemekYe() {
        System.out.println("Ben yemek yerim. ");
    }

    @Override
    public void sporYap() {
        System.out.println("Ben spor yaparım. ");
    }

    @Override
    public void tuvaleteGit() {
        System.out.println("Ben tuvalete giderim. ");
    }
    /*void sahnedeSigaraIc(){
        System.out.println("Ben sahnede sigara içerim. ");
    }*/
}
class PopSarkici extends Sarkici {

    @Override
    void sarkiSoyle() {
        System.out.println("Ben pop şarkı söylüyorum. ");
    }

    @Override
    public void yemekYe() {
        System.out.println("Ben yemek yerim. ");
    }

    @Override
    public void sporYap() {
        System.out.println("Ben spor yaparım. ");
    }

    @Override
    public void tuvaleteGit() {
        System.out.println("Ben tuvalete giderim.");
    }
    /*void dansEt( {
        System.out.println("Ben sahnede dans ederim. ");
    }*/
}
class MuslumBaba implements ArabeskSarkiciOzellikleri, PopSarkiciOzellikleri {

    @Override
    public void sahnedeSigaraIc() {
        System.out.println("Ben sahnede sigara içerim. ");
    }

    @Override
    public void danset() {
        System.out.println("Ben sahnede dans ederim.");
    }

    @Override
    public void duetYap() {
        System.out.println("Ben baska bır sarkıcıyla sahnede veya studyoda duet yaparım. ");
    }

    @Override
    public void yemekYe() {

    }

    @Override
    public void sporYap() {

    }

    @Override
    public void tuvaleteGit() {

    }
}
class Tarkan implements PopSarkiciOzellikleri{

    @Override
    public void danset() {
        System.out.println("Ben dans ederım. ");
    }

    @Override
    public void duetYap() {
        System.out.println("Ben baska bır sarkıcıyla duıet yaparım. ");
    }

    @Override
    public void yemekYe() {

    }

    @Override
    public void sporYap() {

    }

    @Override
    public void tuvaleteGit() {

    }
}
class Hadise implements PopSarkiciOzellikleri{

    @Override
    public void danset() {
        System.out.println("Ben sahnede dans ederım. ");
    }

    @Override
    public void duetYap() {
        System.out.println("Ben baska bnır sarkıcıyla duet yaparım. ");
    }

    @Override
    public void yemekYe() {

    }

    @Override
    public void sporYap() {

    }

    @Override
    public void tuvaleteGit() {

    }
}