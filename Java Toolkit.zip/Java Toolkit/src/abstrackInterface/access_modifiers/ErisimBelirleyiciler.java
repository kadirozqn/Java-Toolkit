package abstrackInterface.access_modifiers;

public class ErisimBelirleyiciler {
    public static void main(String[] args) {
        Y y = new Y();
        y.metot();
    }
}
