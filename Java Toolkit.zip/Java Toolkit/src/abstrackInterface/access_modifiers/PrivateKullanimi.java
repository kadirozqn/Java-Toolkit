package abstrackInterface.access_modifiers;

public class PrivateKullanimi {
        //private sınıf tanımlamalarında kullanılamaz.
        //private degısken ve metotlar sadece o sınıfa aittir.
        //private yapılan kurucu metor (constructor) o sınıftan nesne uretılmesını engeller. ve o sınıftan kalıtım ıle yenı sınıf olusturlamaz.
        //private ile Inner sınıf tanımlanabılır
        private int a;
        private void metot(){

        }
        private PrivateKullanimi(){

        }
        private class InnerClass{

        }
}
/*class YeniSinif extends PrivateKullanimi{

}*/
