package abstrackInterface.access_modifiers;

public class ProtectedKullanimi {
    protected int protectedDegisken;
    protected  void protectedMetod(){

    }
    protected class InnerProtectedSinif{

    }
}
class G extends ProtectedKullanimi{ //sınıflar protected olamaz
    @Override
    protected void protectedMetod() {
        super.protectedMetod();
        System.out.println(protectedDegisken);
    }
}
