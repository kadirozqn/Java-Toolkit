package abstrackInterface.isimsiz_siniflar;

public class IsimsizSinif {
    public static void main(String[] args) {
        Hesaplayici h1 = new Hesaplayici();
        h1.topla(5,6);


        Hesaplayici hesaplayici = new Hesaplayici(){ // YeniHesaplayici sinifindfakı ıslemı bu sekılde ısımsız sınıf adı altında yapabılırız
            @Override
            public void topla(int s1, int s2) {
                System.out.println("İki sayinin toplami: ");
                super.topla(s1, s2);
            }
        };
        hesaplayici.topla(7,8);
        /*YeniHesaplayici yn = new YeniHesaplayici();
        yn.topla(5,8);*/
        Canli c1= new Canli() {
            @Override
            void adiniSoyle() {
                System.out.println("Ben isimsiz sınıftan geliyorum adım anonim.");
            }

            @Override
            void selamVer() {
                System.out.println("Ben isimsiz sınıftakı selamVer metotuyum.");
            }
        };
        Gecici g1 = new Gecici();
        g1.adiniSoyle();
        g1.selamVer();
        c1.adiniSoyle();
        c1.selamVer();

        Yazdiralim y1 = new Yazdiralim() {
            @Override
            public void yazdir() {
                System.out.println("Anonim iç sınıf yazdir metotu.");
            }
        };
        y1.yazdir();
        Yazdiralim y2 = new Yazdiralim() {
            @Override
            public void yazdir() {
                System.out.println("nesne 2 ");
            }
        };
        y2.yazdir();
    }
}
interface Yazdiralim{
    void yazdir();
}
class FakeSinif implements Yazdiralim{

    @Override
    public void yazdir() {

    }
}
class Gecici extends Canli{
    @Override
    void adiniSoyle() {
    }

    @Override
    void selamVer() {
            System.out.println("Selam Geçici");
        }
    }

abstract  class Canli {
    abstract void adiniSoyle();
    void selamVer(){
        System.out.println("Merhaba");
    }

}
class YeniHesaplayici extends Hesaplayici{
    @Override
    public void topla(int s1, int s2) {
        System.out.println("İki sayinin toplami: ");
        super.topla(s1, s2);
    }
}
