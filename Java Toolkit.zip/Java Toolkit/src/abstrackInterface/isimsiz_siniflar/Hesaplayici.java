package abstrackInterface.isimsiz_siniflar;

public class Hesaplayici {
    public void topla (int s1, int s2){
        System.out.println("Toplam: " +(s1+s2));
    }
}
