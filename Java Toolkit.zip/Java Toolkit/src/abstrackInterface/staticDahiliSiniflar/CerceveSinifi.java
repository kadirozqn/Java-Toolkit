package abstrackInterface.staticDahiliSiniflar;

public class CerceveSinifi {

        int nesneDegiskeni;
        static  int staticDegisken;
        public void Metot(){

        }
        static  void staticMetot(){}
        abstract static class IcSinif{
            int icSinifDegiskeni;
            static int icSinifStaticDegiskeni;
            public void IcSinifMetot(){

            }
            static void IcSinifStaticMetot(){}
        }
    }


