package abstrackInterface.staticDahiliSiniflar;

public class StatikDahiliSiniflar {
    public static void main(String[] args) {
        CerceveSinifi c1 = new CerceveSinifi();
        c1.nesneDegiskeni = 5;
        c1.Metot();
        c1.staticMetot();
        c1.staticDegisken = 12;
        /*CerceveSinifi.IcSinif icSinif = new CerceveSinifi.IcSinif();
        icSinif.icSinifDegiskeni = 5;
        icSinif.IcSinifMetot();
        CerceveSinifi.IcSinif.icSinifStaticDegiskeni = 52;
        CerceveSinifi.IcSinif.IcSinifStaticMetot();*/
    }
}
