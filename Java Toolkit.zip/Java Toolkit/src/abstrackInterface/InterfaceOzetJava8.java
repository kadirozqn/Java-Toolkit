package abstrackInterface;

public class InterfaceOzetJava8 {
    public static void main(String[] args) {
        SinifA a = new SinifA();
        a.metotA();
        boolean sonuc = InterFaceA.emailControl("kadirozqn@gmail.com");
        System.out.println(sonuc);
    }
}

interface InterFaceA{
    void metotA();
    default void defaultMetot(){
        System.out.println("Ben bir default metotum.");
    }
    static final int sayi = 10; //Interface sınıflarda degısken tanımı yapacaksak bu sekılde yapmamız gerekıyor.
    static void staticMetot(){
        System.out.println("Ben static metotum. ");
    }
    static boolean emailControl(String mail){
        if ( mail.contains("@")){
            return true;
        }else return false;
    }
}
interface InterFaceB extends InterFaceA{ //araya vırgul koyuıp baska ınterface de koyabılırız.
    void metotB();
}
class SinifA implements InterFaceA{

    @Override
    public void metotA() {
        defaultMetot();
    }
    @Override
    public void defaultMetot() {
        System.out.println("Ben a sınıfı ıcınde tanımlanmıs default metotum.");
    }

}
