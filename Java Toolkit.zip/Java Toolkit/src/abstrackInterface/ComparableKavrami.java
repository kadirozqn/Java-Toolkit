package abstrackInterface;

import java.util.Arrays;

public class ComparableKavrami {
    public static void main(String[] args) {
        Ogrenci ogr1 = new Ogrenci(5,"Kadir");
        Ogrenci ogr2 = new Ogrenci(3,"Ayşe");
        Ogrenci ogr3 = new Ogrenci(7,"Fatma");

        //Ogrenci[] ogrenciler = new Ogrenci[3];
        Ogrenci[] ogrenciler = {ogr1,ogr2, ogr3};
        String[] isimler = {"Ali", "Abdulselam", "Esra","Ecem"};
        System.out.println("Dizi sıralanmadan oncekı ogrencıler nesnesının durumu: ");
        for(Ogrenci sırala : ogrenciler){
            System.out.println(sırala);
        }
        Arrays.sort(ogrenciler);
        System.out.println("Dizi sıralandıktan sonra ogrencıler nesnesının durumu: ");
        for(Ogrenci sırala : ogrenciler){
            System.out.println(sırala);
        }
        Arrays.sort(isimler);
        for (String gecici : isimler )
            System.out.println(gecici);
    }
}
class Ogrenci implements Comparable<Ogrenci>{
    int id;
    String  ad;

    public Ogrenci(int id, String ad) {
        this.id = id;
        this.ad = ad;
    }

    @Override
    public String toString() {
        return "ad: "+ad+" id: "+id;
    }

    @Override
    public int compareTo(Ogrenci o) { // sıralam algorıtmasıdır ve java tarafından tasarlanmıstır bir interface ornegıdır.
        /*if(this.id < o.id){ // integer karsılastırma
            return -1;
        }else if(this.id > o.id){
            return 1;
        }else return 0;
        /*if(this.id < o.id){ // buyukten kucuge sıralama algorıtması
            return 1;
        } else if (this.id > o.id) {
            return -1;
        } else return 0;
*/
        if(this.ad.compareTo(o.ad)<0){ //Strın ıfadelerı karsılastırma
            return -1;
        }else if(this.ad.compareTo(o.ad)>0){
            return 1;
        }else return 0;
    }

}