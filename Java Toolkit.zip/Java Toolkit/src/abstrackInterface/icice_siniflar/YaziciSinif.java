package abstrackInterface.icice_siniflar;

public class YaziciSinif {
    private int privateDegisken;
    int defaultDegisken;
    protected int protectedDegisken;
    public int publicDegisken;

    private void privateMetot() {
        stringDiziYazdir s1 = new stringDiziYazdir();
        System.out.println(s1.defaultDegiskenDahili);
        System.out.println(s1.privateDegiskenDahili);
        System.out.println(s1.protectedDegiskenDahili);
        System.out.println(s1.publicDegiskenDahili);
    }
    static final int sayi =12; // Inner classlarda statıc degıskenler olamaz ama statıc fınal olabılır
    void defaultMetot() {
    }

    protected void protectedMetot() {
    }

    public void publicMetot() {
    }
    abstract class AbstrackClass{

    }
    final class FinalClass {

    }
    //abstract final AbstrackFinalSinif{}  BU SEKILDE TANIMLAMA YAPAMAYIZ  

    public class stringDiziYazdir { // bu kullanımda yukarıdakı sınıf bu sınıftakı tum metotlara ve degıskenlere private olmasın ragmen erısebılır.
        // aynı zamanda bu sınıftas yukarıdakı tum sınıf ve netotlara erısebılır.
        private int privateDegiskenDahili = 2;
        int defaultDegiskenDahili = 23;
        protected int protectedDegiskenDahili = 7;
        public int publicDegiskenDahili = 6;

         void stringDiziYazdir(String[] dizi) {

            System.out.println(privateDegisken);
            System.out.println(publicDegisken);
            System.out.println(protectedDegisken);
            System.out.println(defaultDegisken);

            privateMetot();
            publicMetot();
            protectedMetot();
            defaultMetot();

            for (String gecici : dizi) {
                System.out.println(gecici);
            }
        }

    }
}
class A{
    class B{
        void metotB(){}
        class C{
            void metot(){

            }
        }
    }
}


