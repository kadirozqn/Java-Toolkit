package abstrackInterface.icice_siniflar;

public class NestedClassKullanimi {
    public static void main(String[] args) {
        String[] sehirler= {"Van", "İstanbul", "Ankara"};
        //YaziciSinif.stringDiziYazdir nesne = new YaziciSinif().new stringDiziYazdir();
        //nesne.stringDiziYazdir(sehirler);

        YaziciSinif yaziciSinif = new YaziciSinif();
        YaziciSinif.stringDiziYazdir StringDiziYazdir = yaziciSinif.new stringDiziYazdir();
        StringDiziYazdir.stringDiziYazdir(sehirler);

        A.B.C nesne = new A().new B().new C();
        nesne.metot();

        A.B nesne2 = new A(). new B();
        nesne2.metotB(); //b metoduna
        nesne2.new C().metot(); // c metoduna bu sekılde eısebılırız
    }
}
