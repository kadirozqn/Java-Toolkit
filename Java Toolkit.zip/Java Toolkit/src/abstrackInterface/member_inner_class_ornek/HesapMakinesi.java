package abstrackInterface.member_inner_class_ornek;

public class HesapMakinesi {
    int sayi = 0;
    static  int sayi2 = 5;
    public int carp(int i, int j) {
        Carpma carpma = new Carpma();
        int sonuc = carpma.carpma(i,j);
        return sonuc;
    }
    private void ozelMetot(){}

    public String bolmeYap(int sayi1, int sayi3) {
        // ınner classlar statıc degerler alamazlar. sadece ıstısna olarak statıc fınal olarak tanımlayabılırız.
        // ayrı ayrı abstrack olabılır ve fınal olabılır ama hem abstrack hem fınal olamaz.
        class Bolme { // local sınıf
            public String bolme(int i, int j) {
                if (j == 0) {
                    System.out.println("Bölen sıfır olamaz.");
                    return "";
                } else {
                    int sonuc = i / j;
                    return String.valueOf(sonuc);
                }
            }
        }
        Bolme b = new Bolme();
        String sonuc = b.bolme(sayi1,sayi3); //inner (iç) sınıflar nesne uretılmeden kullanılamaz bu yuzden bu sekılde bır kullanım yaptık
        return sonuc;
    }
    public class Topla{
            public int topla(int i, int j){
                return i+j;
            }
        }
        class Cikar{
            public int cikar(int i, int j ){
                return i-j;
            }
        }
        private class Carpma{
            public int carpma(int i, int j){
                int sayi = 4;
                //static int sayi2 = 5; iç sınıflarda statik degıskenler vbe metotlar olamaz. statik final dekısken olabılır
                //static final staticMetot(){};

                System.out.println(sayi);
                System.out.println(sayi2);
                ozelMetot();
                return i*j;
            }
        }
}
/*static {
    class Bolme {
        public String bolme(int i, int j) {
            if (j == 0) {
                System.out.println("Bölen sıfır olamaz.");
                return "";
            } else {
                int sonuc = i / j;
                return String.valueOf(sonuc);
            }
        }
    }

}
    class Bolme {
        public String bolme(int i, int j) {
            if (j == 0) {
                System.out.println("Bölen sıfır olamaz.");
                return "";
            } else {
                int sonuc = i / j;
                return String.valueOf(sonuc);
            }
        }
    }*/
