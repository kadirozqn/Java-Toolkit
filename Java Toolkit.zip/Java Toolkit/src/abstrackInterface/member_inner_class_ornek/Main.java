package abstrackInterface.member_inner_class_ornek;

public class Main {
    public static void main(String[] args) {
        HesapMakinesi hm = new HesapMakinesi();
        HesapMakinesi.Topla toplayici = hm.new Topla();
        int toplam = toplayici.topla(5,6);
        System.out.println("Toplam: "+ toplam);

        HesapMakinesi.Cikar cikarici = hm.new Cikar();
        int cikarmaSonuc = cikarici.cikar(75,65);
        System.out.println("Çıkarma: "+ cikarmaSonuc);

        int carpim = hm.carp(6,5);
        System.out.println("Çarpma: "+carpim);

        String bolum = hm.bolmeYap(8,0);
        if(!bolum.equals("")){
            System.out.println("Bolum: "+bolum);
        }
    }
}
