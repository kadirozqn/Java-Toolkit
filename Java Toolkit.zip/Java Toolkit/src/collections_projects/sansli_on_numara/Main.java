package collections_projects.sansli_on_numara;

import java.util.*;

public class Main {
    static int URETILECEK_SAYI_MAX_SINIR = 60;
    static int URETILECEK_SAYI_MIKTARI= 1000000;
    public static void main(String[] args) {
       Map<Integer, Integer > olusturulanSayilar = new HashMap<>();
       List<Integer> olusturulanSayiListesi = new ArrayList<>();
       Set<Integer> sansliOnSayi = new TreeSet<>(); // şanslı on sayi

       sayilarlaDoldur(olusturulanSayilar);
       listeyeYazdir(olusturulanSayilar,olusturulanSayiListesi);
       sansliOnSayiyiBul(sansliOnSayi,olusturulanSayiListesi);

       System.out.println("Map size: " +olusturulanSayilar.size());
       System.out.println("Listeninn size: " +olusturulanSayiListesi.size());
       System.out.println("Set size " +sansliOnSayi.size());

        System.out.println("Şnaslı on sayı");
        for (int gecici : sansliOnSayi){
            System.out.println(gecici + " ");
        }

       /*for (Map.Entry<Integer, Integer> gecici : olusturulanSayilar.entrySet()) {
           System.out.println(gecici.getKey() + " : " + gecici.getValue());
       }*/

    }

    private static void sansliOnSayiyiBul(Set<Integer> sansliOnSayi, List<Integer> olusturulanSayiListesi) {
        Collections.shuffle(olusturulanSayiListesi);

        for (int i=0; i<10; i++){
            int rastgeleSayi = ((int) Math.random() *URETILECEK_SAYI_MIKTARI);
            sansliOnSayi.add(olusturulanSayiListesi.get(rastgeleSayi));

        }
    }


    private static void listeyeYazdir(Map<Integer, Integer> map, List<Integer> list) {
        for (Map.Entry<Integer, Integer> gecici : map.entrySet()) {
            int key = gecici.getKey(); //9
            int value = gecici.getValue();//15 bu 9 sayısının 15 kere olusturuldugu anlamına gelır
            for (int i = 0; i < value; i++) {
                list.add(key);
            }
        }
    }

    private static void sayilarlaDoldur(Map<Integer, Integer> map) {
        for (int i = 0; i<URETILECEK_SAYI_MIKTARI; i++){
            int randomSayi = sayiOlustur();
            if (map.containsKey(randomSayi)){
                int value = map.get(randomSayi);
                map.put(randomSayi, ++value);
            }else {
                map.put(randomSayi,1);
            }
        }
    }
    private static int sayiOlustur(){
        return ((int) (Math.random() * URETILECEK_SAYI_MAX_SINIR) +1);
    }
}
