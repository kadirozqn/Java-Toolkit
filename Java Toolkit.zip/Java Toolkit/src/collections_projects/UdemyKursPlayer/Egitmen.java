package collections_projects.UdemyKursPlayer;

public class Egitmen extends Ogrenci{
    public Egitmen(String isim, String tanitimYazisi, String kullaniciAdi) {
        super(isim, tanitimYazisi, kullaniciAdi);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
