package collections_projects.UdemyKursPlayer;

import java.util.ArrayList;

public class Kurs {
    private String kursAdi;
    private ArrayList<Ders> kurstakiDersler;
    private ArrayList<Egitmen> kursEgitmenleri;
    private ArrayList<Ogrenci> kursOgrencileri;
    //ders sayiis en az 5 ve toplam icerik en az 60 dakika olmali
    private boolean yayinda;

    public String getKursAdi() {
        return kursAdi;
    }

    public ArrayList<Ogrenci> getKursOgrencileri() {
        return kursOgrencileri;
    }

    public Kurs(String kursAdi, Egitmen basEgitmen) {
        this.kursAdi = kursAdi;
        this.kursOgrencileri = new ArrayList<>();
        this.kursEgitmenleri = new ArrayList<>();
        this.kurstakiDersler = new ArrayList<>();
        this.kursEgitmenleri.add(0,basEgitmen);
        this.yayinda = false;
    }

    public void kursaEgitmenSil(Egitmen silinecekEgitmen){
        if(silinecekEgitmen.getIsim().equals(kursEgitmenleri.get(0).getIsim())){
            System.out.println(silinecekEgitmen.getIsim() + " kursun baş eğitmeni olduğundan silinemez.");
        }else {
            kursEgitmenleri.remove(silinecekEgitmen);
            System.out.println(silinecekEgitmen.getIsim() + " kurs eğitmenliğinden kaldırıldı.");
        }
    }
    public void kursaEgitmenEkle(Egitmen yeniEgitmen){
        if(!kursEgitmenleri.contains(yeniEgitmen)){
            kursEgitmenleri.add(yeniEgitmen);
            System.out.println(yeniEgitmen.getIsim() + " kursa eğitmen olarak eklendi.");
        }else {
            System.out.println("Eklemek istediğiniz eğitmen zaten bu kursa eklidir!");
        }
        this.kursEgitmenleri.add(yeniEgitmen);
    }
    public void KurstanEgitmenSil(Egitmen silinecekEgitmen){
        this.kursEgitmenleri.remove(silinecekEgitmen);
    }
    public void kurstaDersEkle(Ders ders){
        this.kurstakiDersler.add(ders);
    }
    public int kurstakiDersSayisi(){
        return kurstakiDersler.size();
    }
    private int kurstakiToplamDerslerinDakikaSuresi(){
        double toplamSure=0;
        for (Ders gecici : kurstakiDersler) {
            toplamSure = toplamSure + gecici.getDakika();
        }
        return (int)toplamSure;
    }
    public boolean kursYayindaKontrol(){
        if(kurstakiDersler.size() >=5 && kurstakiToplamDerslerinDakikaSuresi()>=60){
            yayinda = true;
            return true;
        }else return false;
    }

    public ArrayList<Ders> getKurstakiDersler() {
        return kurstakiDersler;
    }
}
