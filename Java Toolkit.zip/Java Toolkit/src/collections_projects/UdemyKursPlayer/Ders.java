package collections_projects.UdemyKursPlayer;

public class Ders {
    private int dersNo;
    private String dersBaslik;
    private double dakika;

    public Ders(String dersBaslik, int dersNo, double dakika) {
        this.dersBaslik = dersBaslik;
        this.dersNo = dersNo;
        this.dakika = dakika;
    }

    public int getDersNo() {
        return dersNo;
    }

    public String getDersBaslik() {
        return dersBaslik;
    }

    public double getDakika() {
        return dakika;
    }

    @Override
    public String toString() {
        return "Ders{" +
                "dersNo=" + dersNo +
                ", dersBaslik='" + dersBaslik + '\'' +
                ", dakika=" + dakika +
                '}';
    }
}
