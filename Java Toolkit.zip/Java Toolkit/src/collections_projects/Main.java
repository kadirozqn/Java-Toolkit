package collections_projects;

import collections_projects.UdemyKursPlayer.Ders;
import collections_projects.UdemyKursPlayer.Egitmen;
import collections_projects.UdemyKursPlayer.Kurs;
import collections_projects.UdemyKursPlayer.Ogrenci;

import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Scanner;

import static metotlarVeDiziler.MetotOrnek.menuGoster;

public class Main {
    public static void main(String[] args) {

        Ogrenci ogr1 = new Ogrenci("Kadir", "Kadir'in tanitim yazisi. ","Kadir Udemy");
        Egitmen eg1 = new Egitmen("Ali", "Ali Java", "Aliozan");
        Egitmen eg2 = new Egitmen("Deneme", "Deneme Java", "Deneme");
        System.out.println(ogr1);
        System.out.println(eg1);

        Ders d1 = new Ders("Java", 1,3.5);
        Ders d2 = new Ders("Java Nedir?", 2,4.2);
        Ders d3 = new Ders("Primitve Tipler", 3,32.5);
        Ders d4 = new Ders("Nesne Tabanlı Programlama (OOP)", 4,7.9);
        Ders d5 = new Ders("Miras Alma işlemleri (extends)",5,16.4);

        Ders d6 = new Ders( "Nesneler", 6,45.2);
        Ders d7 = new Ders( "Try Catch", 7,10);
        Ders d8 = new Ders( "Recyclerview", 8,15.6);
        Ders d9 = new Ders( "Sharedprefencas", 9,22.2);
        Ders d10 = new Ders( "FireBase", 10,36.8);

        Kurs javaKursu = new Kurs("İleri Seviye Java Kursu", eg1);

        javaKursu.kurstaDersEkle(d1);
        javaKursu.kurstaDersEkle(d2);
        javaKursu.kurstaDersEkle(d3);
        javaKursu.kurstaDersEkle(d4);
        javaKursu.kurstaDersEkle(d5);

        javaKursu.kursaEgitmenEkle(eg2);
        javaKursu.kursaEgitmenSil(eg1);
        javaKursu.kursaEgitmenSil(eg2);

        Kurs androidKursu = new Kurs("Android Kursu" , eg1);
        androidKursu.kurstaDersEkle(d6);
        androidKursu.kurstaDersEkle(d7);
        androidKursu.kurstaDersEkle(d8);
        androidKursu.kurstaDersEkle(d9);
        androidKursu.kurstaDersEkle(d10);

        ogr1.kursaKatil(javaKursu);

        ogr1.kursaKatil(androidKursu);
        ogr1.izlenecekDersEkle(d6);
        ogr1.izlenecekDersEkle(d2);
        ogr1.izlenecekDersEkle(d8);
        ogr1.izlenecekDersEkle(d7);

       listeyiOynat(ogr1.getIzlenecekDersListesi());
    }
    public static void listeyiOynat(LinkedList<Ders> izlenecekDersler){
        Scanner tara = new Scanner(System.in);
        boolean cikis = false;
        boolean ileriDogruHareket = true;

        ListIterator<Ders> iterator = izlenecekDersler.listIterator();
        if(izlenecekDersler.size() == 0){
            System.out.println("Henüz bir ders eklenmemiş");
        }else{
            Ders ilkDersler = iterator.next();
            System.out.println("Şuan izlenen ders: "+ilkDersler.getDersBaslik()+ " Süre: "+ilkDersler.getDakika()  );
        }

        menuGoster();
        while (!cikis){
            System.out.println("Seçiminiz : ");
            int kullaniciSecimi = tara.nextInt();
            switch (kullaniciSecimi){
                case 0:
                    System.out.println("Uygulamadan çıkılıyor...");
                    cikis = true;
                    break;
                case 1:
                    if(!ileriDogruHareket){
                        ileriDogruHareket = true;
                        if (iterator.hasNext()){
                            iterator.next();
                        }
                    }
                    if(iterator.hasNext()){
                        Ders ilkders = iterator.next();
                        System.out.println("----------------------------------------------------------------------------------------");
                        System.out.println("Şuan oynatilan ders : Ders NO: " + ilkders.getDersNo() + " başlık: " + ilkders.getDersBaslik()+" süre: "+ilkders.getDakika());
                        System.out.println("----------------------------------------------------------------------------------------"   );
                    }else{
                        System.out.println("Listenin sonuna geldiniz.");
                    }
                    break;
                case 2:
                    if (ileriDogruHareket){
                        ileriDogruHareket = false;
                        if (iterator.hasPrevious()){
                            iterator.previous();
                        }
                    }
                    if(iterator.hasPrevious()){
                        Ders ilkders = iterator.previous();
                        System.out.println("----------------------------------------------------------------------------------------");
                        System.out.println("Şuan oynatilan ders : Ders NO: " + ilkders.getDersNo() + " başlık: " + ilkders.getDersBaslik()+" süre: "+ilkders.getDakika());
                        System.out.println("----------------------------------------------------------------------------------------"   );
                    }else{
                        System.out.println("Listenin başına geldiniz.");
                    }
                    break;
                case 3:
                    izlenecekDersleriListele(izlenecekDersler);
                    break;
                case 9:
                    menuGoster();
                    break;
            }

        }
    }


    public static void izlenecekDersleriListele(LinkedList<Ders> izlenecekDersler){
        ListIterator<Ders> iterator = izlenecekDersler.listIterator();
        if(izlenecekDersler.size() == 0){
            System.out.println("Henüz bir ders eklenmemiş");
            return;
        }else{
            while (iterator.hasNext()){
                Ders ilkders = iterator.next();
                System.out.println("Ders no: " + ilkders.getDersNo() + " başlık: " + ilkders.getDersBaslik()+" süre: "+ilkders.getDakika());
            }
        }
    }
    private static void menuGoster(){
        System.out.println("************* Menu *************");
        System.out.println("0-> Çıkış");
        System.out.println("1-> Bir sonraki derse git");
        System.out.println("2-> Bir önceki derse git");
        System.out.println("3-> Tüm listeyi gör");
        System.out.println("9-> Menü");
    }
}
