package exceptions;

public class MetotIcındeHata {
    public static void main(String[] args) {
       try{
           hataOlustur();
       }
       catch (ArrayIndexOutOfBoundsException hata) {
               System.out.println("Hata -> " + hata);
       }
    }

    private static void hataOlustur() {
        String[] dizi = {"abc", "123", null, "bdc"};
        for (int i = 0; i < dizi.length + 2; i++) {
            try {
                int sayi = dizi[i].length() + Integer.parseInt(dizi[i]);
            } catch (NumberFormatException hata) {
                System.out.println("Hata -> " + hata);
            } catch (NullPointerException hata) {
                System.out.println("Hata -> " + hata);
            }
        }
        System.out.println("Hata olustur metotunun sonu...");
    }
}
