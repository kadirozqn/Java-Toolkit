package exceptions;

import java.util.Scanner;

public class KendiIstisnalarimiziOlusturma {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.print("Yaşnızı giriniz: ");
        int yas = input.nextInt();
        try {
            if(yas < 0){
                throw new NegatifYasHatasi("Yaş negatif olamaz! Lütfen geçerli bir değer giriniz...");
            }
        }catch (Exception e){
            System.out.println("Hata yakalandı: " +e );
        }

    }
}
class NegatifYasHatasi extends Exception{
    String hataMesaji;

    public NegatifYasHatasi(String hataMesaji) {
        this.hataMesaji = hataMesaji;
    }

    @Override
    public String toString() {
        return hataMesaji;
    }
}
