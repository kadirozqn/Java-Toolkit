package exceptions;

public class ExceptionKavrami {
    public static void main(String[] args) {

        try{
            Integer i = new Integer("saadf"); //hatalı kullanım bu sekılde kullanmak pek saglıklı degıl
            System.out.println(i);
        } catch (Exception e) {
             System.out.println("Hata çıktı -> " + e.toString());
        }


        try{
            int a =5/0;
            System.out.println(a);
        }catch (Exception e){
            System.out.println("Hata tespit edildi -> "+e.toString());
        }


        try{
            int [] sayilar = {0,1,2,3};
            System.out.println(sayilar[4]);
        }catch (Exception e){
            System.out.println("Hata tespit edildi -> "+e.toString());
        }


        try{
            Object o = new Object();
            String b = (String) o;
        }catch (Exception e){
            System.out.println("Hata tespit edildi -> "+e.toString());
        }finally { // ne olursa olsun calıstırılacak kod blogu fınally kod blogudur
            System.out.println("Finally calıstırıldı.");
            System.out.println("Program burdan devam etmeli.");
        }

    }

}
