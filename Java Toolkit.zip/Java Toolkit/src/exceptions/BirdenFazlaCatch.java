package exceptions;

public class BirdenFazlaCatch {
    public static void main(String[] args) {
        String[] dizi = {"abc", "123", null, "bdc"};
        for (int i = 0; i < dizi.length + 2; i++) {
            try {
                int sayi = dizi[i].length() + Integer.parseInt(dizi[i]);
            } catch (NumberFormatException hata) {
                System.out.println("Hata -> " + hata);
            } catch (NullPointerException hata) {
                System.out.println("Hata -> " + hata);
            } catch (ArrayIndexOutOfBoundsException hata) {
                System.out.println("Hata -> " + hata);
            }
        }
        System.out.println("Devam!");

        //Bu sekılde uzun uzun hataları tyespıt etmemıze gerek yok bunun kısa yolu asagıdakı gıbıdır.
        for (int i = 0; i < dizi.length + 2; i++) {
            try {
                int sayi = dizi[i].length() + Integer.parseInt(dizi[i]);
            } catch (Exception hata) {
                System.out.println("Hata -> " + hata);
            }
        }

        //yazımı kısaltmak ıstersekte asagıdakı gruplandırma yapısını kullanabılırız

        System.out.println("Devam edıyoruz! 2");
        for (int i = 0; i < dizi.length + 2; i++) {
            try {
                int sayi = dizi[i].length() + Integer.parseInt(dizi[i]);
            } catch (NumberFormatException | NullPointerException | ArrayIndexOutOfBoundsException hata) {
                System.out.println("Hata -> " + hata);
            }
        }
        System.out.println("Buradan devam edıyoruz 3");
        for (int i = 0; i < dizi.length + 2; i++) {
            try {
                int sayi = dizi[i].length() + Integer.parseInt(dizi[i]);
            } catch (Exception hata) {
                System.out.println("Hata -> " + hata);
                /*}catch (Throwable T) { expectıon sınıfının ust sınıfıdır bu da kullanılabılır
                System.out.println("Throwable -> "+T);
                }*/
            }
        }
        System.out.println("Buradan devam edıyoruz 4");
        for (int i = 0; i < dizi.length + 2; i++) {
            try {
                int sayi = dizi[i].length();
                try {
                    sayi = Integer.parseInt(dizi[i]);
                } catch (NumberFormatException hata) {
                    System.out.println("Icerdekı Hata -> " + hata);
                }
            }catch (NullPointerException hata) {
                System.out.println(" Dısardakı Hata ->" + hata);
            }catch (ArrayIndexOutOfBoundsException hata){
                System.out.println("Dısardakı Hata -> " + hata);
            }

            }
        }
    }



