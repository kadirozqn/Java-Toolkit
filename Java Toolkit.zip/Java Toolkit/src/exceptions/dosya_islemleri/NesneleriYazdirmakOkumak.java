package exceptions.dosya_islemleri;

import java.io.*;
import java.util.ArrayList;

public class NesneleriYazdirmakOkumak {
    public static void main(String[] args) {

        dosyayaNesneYazdir();
        dosyadanNesneleriOku();

        //arrayliste dosyuaları yazdırmak
        ArrayList<Student> arrayList = new ArrayList<>();
        Student ogr1 = new Student(7,"Fatma",true);
        Student ogr2 = new Student(8,"Abdulselam",false);
        Student ogr3 = new Student(9,"İrem",true);
        try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("ogrenciNesneleriListesi.dat")))){

            objectOutputStream.writeObject(arrayList);

        }catch (Exception e){
            System.out.println(e);
        }
        //arraylist dosyadan okumak

        try  (ObjectInputStream objectInputStream = new ObjectInputStream(new BufferedInputStream(new FileInputStream("ogrenciNesneleriListesi.dat")))){
            ArrayList<Student> arrayList1 = (ArrayList<Student>) objectInputStream.readObject();
            System.out.println("Okunan arraylist: "+arrayList1);
        }catch (IOException e){
            e.printStackTrace();
        }catch (Exception e) {
            System.out.println(e);
        }

    }

    private static void dosyadanNesneleriOku() {
        try (ObjectInputStream objectInputStream = new ObjectInputStream(new BufferedInputStream(new FileInputStream("ogrenciNesneleri.dat"))) ){
            boolean dosyaSonu = false;
            while(!dosyaSonu){
                try {
                    Student okunanNesne = (Student) objectInputStream.readObject();
                    System.out.println(okunanNesne);
                }catch (EOFException e) {
                    dosyaSonu = true;
                }
            }
        }catch (Exception e){
         System.out.println(e);
        }
    }

    private static void dosyayaNesneYazdir() {

        Student student1 = new Student(40,"Kadir",true);
        Student student2 = new Student(50,"Ali",false);
        Student student3 = new Student(70,"Ayşe",true);


        try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("ogrenciNesneleri.dat")))){

            objectOutputStream.writeObject(student1);
            objectOutputStream.writeObject(student2);
            objectOutputStream.writeObject(student3);
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
class Student implements Serializable {

    int id;
    String isim;
    boolean aktif;
    private final long serialVersion = 1L;

    public Student(int id, String isim, boolean aktif) {
        this.id = id;
        this.isim = isim;
        this.aktif = aktif;
    }

    @Override
    public String toString() {
        return "Ogrenci{" +
                "id=" + id +
                ", isim='" + isim + '\'' +
                ", aktif=" + aktif +
                '}';
    }
}