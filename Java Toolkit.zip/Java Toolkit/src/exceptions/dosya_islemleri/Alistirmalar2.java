package exceptions.dosya_islemleri;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Alistirmalar2 {
    public static void main(String[] args) {
        ArrayList<Calisan> calisanlar = new ArrayList<>();

        try (BufferedReader okuyucu = new BufferedReader(new FileReader("maas.txt"))){

            String  tekSatir = okuyucu.readLine();
            while (tekSatir != null){
                String [] tekSatirDizisi = tekSatir.split(" ");
                String isim = tekSatirDizisi[0];
                int maas  = Integer.parseInt(tekSatirDizisi[1]);
                Calisan geciciCalisan = new Calisan(maas, isim);
                calisanlar.add(geciciCalisan);

                tekSatir = okuyucu.readLine();
            }
            //System.out.println(calisanlar);
            //System.out.println(calisanlar.size());
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Collections.sort(calisanlar, new Comparator<Calisan>() {

            @Override
            public int compare(Calisan o1, Calisan o2) {
                if (o1.maas < o2.maas){
                    return 1;
                }else if (o1.maas > o2.maas){
                    return -1;
                }else return 0;
            }
        });
        try (BufferedWriter yazici = new BufferedWriter(new FileWriter("siraliMaas.txt"))){

            for ( Calisan gecici : calisanlar){
                yazici.write(gecici.isim +" , "+gecici.maas+"\n");
                yazici.newLine();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


        //System.out.println(calisanlar);
    }



}
class Calisan{

    int maas;
    String  isim;

    public Calisan(int maas, String isim) {
        this.maas = maas;
        this.isim = isim;
    }

    @Override
    public String toString() {
        return "Calisan{" +
                "maas=" + maas +
                ", isim='" + isim + '\'' +
                '}';
    }
}