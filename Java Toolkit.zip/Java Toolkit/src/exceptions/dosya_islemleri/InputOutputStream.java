package exceptions.dosya_islemleri;

import java.io.*;
import java.util.ArrayList;

public class InputOutputStream {
    public static void main(String[] args) {


        //DataOutputStream -> uygulama dısarıya verı verıyorsa kullanılır. kısadası dosyaya verı yazarken kullanılır dıyebılırız
        //DataInputStream ->uygulama dısardan verı alıyorsa kullanılır. Kısacası dosya okumada kullanılır dıyebılırız
        dosyayaYaz();
        dosyadanOku();

    }

    private static void dosyadanOku() {
        ArrayList<Ogrenci> ogreciArrayList = new ArrayList<>();
        boolean dosyaSonu = false;
        try (DataInputStream dataIntputStream = new DataInputStream(new BufferedInputStream(new FileInputStream("ogrenciler.dat")));) {
            Ogrenci okunanOgrenci;
            while (!dosyaSonu) {

                try {
                    int id = dataIntputStream.readInt();
                    String isim = dataIntputStream.readUTF();
                    boolean aktif = dataIntputStream.readBoolean();
                    okunanOgrenci = new Ogrenci(id, isim, aktif);
                    ogreciArrayList.add(okunanOgrenci);
                    System.out.println("Ogrenci: " + okunanOgrenci);
                } catch (EOFException e) {
                    System.out.println("Dosya sonuna gelındı.");
                    dosyaSonu = true;
                }


            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(ogreciArrayList.size());


        /*try {
            dataIntputStream =  new DataInputStream(new BufferedInputStream(new FileInputStream("ogrenciler.dat")));
            Ogrenci okunanOgrenci;
            while (!dosyaSonu){

                try {
                    int id = dataIntputStream.readInt();
                    String isim = dataIntputStream.readUTF();
                    boolean aktif = dataIntputStream.readBoolean();
                    okunanOgrenci = new Ogrenci(id, isim, aktif);
                    ogreciArrayList.add(okunanOgrenci);
                    System.out.println("Ogrenci: "+ okunanOgrenci);
                } catch (EOFException e){
                    System.out.println("Dosya sonuna gelındı.");
                    dosyaSonu = true;
            }



        }
        } catch (IOException E) {
            e.printStackTrace();
        }finally {
            if (dataIntputStream != null) {
                try {
                    dataIntputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        System.out.println(ogreciArrayList.size());*/
    }

    private static void dosyayaYaz() {


        Ogrenci ogr1 = new Ogrenci(1, "Kadir", false);
        Ogrenci ogr2 = new Ogrenci(2, "Fatma", true);
        try (DataOutputStream dataOutputStream = new DataOutputStream(new BufferedOutputStream(new FileOutputStream("ogrenciler.dat")));) {

            dataOutputStream.writeInt(ogr1.id);
            dataOutputStream.writeUTF(ogr1.isim);
            dataOutputStream.writeBoolean(ogr1.aktif);

            dataOutputStream.writeInt(ogr2.id);
            dataOutputStream.writeUTF(ogr2.isim);
            dataOutputStream.writeBoolean(ogr2.aktif);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

        /*try{
            dataOutputStream= new DataOutputStream(new BufferedOutputStream(new FileOutputStream("ogrenciler.dat")));

            dataOutputStream.writeInt(ogr1.id);
            dataOutputStream.writeUTF(ogr1.isim);
            dataOutputStream.writeBoolean(ogr1.aktif);

            dataOutputStream.writeInt(ogr2.id);
            dataOutputStream.writeUTF(ogr2.isim);
            dataOutputStream.writeBoolean(ogr2.aktif);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (dataOutputStream != null){
                try {
                    dataOutputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }*/
}

class Ogrenci {

    int id;
    String isim;
    boolean aktif;

    public Ogrenci(int id, String isim, boolean aktif) {
        this.id = id;
        this.isim = isim;
        this.aktif = aktif;
    }

    @Override
    public String toString() {
        return "Ogrenci{" +
                "id=" + id +
                ", isim='" + isim + '\'' +
                ", aktif=" + aktif +
                '}';
    }
}
