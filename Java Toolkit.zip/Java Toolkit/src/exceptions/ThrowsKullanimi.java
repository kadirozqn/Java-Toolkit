package exceptions;

import java.sql.SQLException;

public class ThrowsKullanimi {

    public static void main(String[] args) {
    try {
     metot();
    }catch (Exception e) {
        System.out.println("Hata yakalandi: " + e);
    }
    }

    private static void metot() throws  NumberFormatException, NullPointerException{
        Integer sayi = Integer.parseInt("abc");

    }
    private static void metot2() throws  NumberFormatException{
        metot();

    }
    private static void metot3() throws  NumberFormatException{
        metot2();

    }

}
class A{
    void aMetotu() throws SQLException {
        System.out.println("A sınıfındaki metot cağrıldı.");
    }
}
class B extends A{
    @Override
    void aMetotu() throws ArrayIndexOutOfBoundsException, SQLException {
        System.out.println("B sınıfındakı metot cagrıldı.");
    }
}
class C extends B{
    @Override
    void aMetotu() throws ArrayIndexOutOfBoundsException, SQLException {// kontrollu exceptıonslarda fırlatılan hata ust sınıflarda da bulunması gerekıyor ornek olarak SQLEXCEPTION verılebılır
        super.aMetotu();
    }
}
