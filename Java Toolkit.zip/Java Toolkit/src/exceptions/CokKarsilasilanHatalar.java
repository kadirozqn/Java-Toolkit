package exceptions;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CokKarsilasilanHatalar {
    public static void main(String[] args) {

        //NullPointException
        try {
            System.out.println(Test.isim.length());
        }catch (Exception e){
            System.out.println("Hata ->" + e.getMessage());
            System.out.println("Hata ->" + e.toString());
    }

        //ArrayIndexOutofBoundsException
        try {
            int[] sayilar = {1,2,3};
            System.out.println(sayilar[4]);
        }catch (Exception e){
            System.out.println("Hata ->" + e.getMessage());
            System.out.println("Hata ->" + e.toString());
        }

        //NumberFormatException
        try {
            int sayi = Integer.parseInt("123");
            int sayi2 = Integer.parseInt("ab13");
        }catch (Exception e){
            System.out.println("Hata ->" + e.getMessage());
            System.out.println("Hata ->" + e.toString());
        }

        //ClassNotFoundException
        try {
            Class.forName("kadirsinifi");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println(e.getCause());
            System.out.println(e.getException());
            System.out.println(e.getMessage());
            System.out.println(e.toString());
            //throw new RuntimeException(e);
        }

        //ArithmeticException
        try {
            int sayi4 = 10/0;
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("Hata ->" + e.getMessage());
            System.out.println(e.getCause());
            System.out.println(e.toString());
        }

        //SQLException
        Connection con = null;

        String URL= "jdbc:oracle:thin:@localhost:1521XE";

        String username = "username";

        String password = "password";
        try {
            con = DriverManager.getConnection(URL,username,password);
        }catch (SQLException e){
            e.printStackTrace();
            System.out.println("Hata ->"+e.getCause());
            System.out.println("Hata ->" +e.toString());
        }

        //ClassCastException
        try {
            UstSinif sinif = new UstSinif();
            UstSinif ustSinif = new AltSinif();
            AltSinif altSinif = (AltSinif) new UstSinif();
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("Hata ->" + e.getMessage());
            System.out.println("Hata ->" + e.toString());
        }

        //IOException
        String dosyaYolu = "C:\\Users\\Kadir\\assdsa.txt";
        BufferedReader reader = null;

        try {
            reader = new BufferedReader(new FileReader(dosyaYolu));
        } catch (FileNotFoundException e) {
             e.printStackTrace();
             System.out.println("Hata ->" + e.getMessage());
             System.out.println("Hata ->" + e.toString());
            //throw new RuntimeException(e);
        }

        //InterruptedException
        //SecurityException
        System.out.println("Program calismaya deva ediyor...");

    }
}
class Test{
    static  String isim;
}
class UstSinif{

}
class AltSinif extends UstSinif{

}