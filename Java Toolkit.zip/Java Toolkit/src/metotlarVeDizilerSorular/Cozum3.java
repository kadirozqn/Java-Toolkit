package metotlarVeDizilerSorular;

public class Cozum3 {
    public static void main(String[] args) {
        String karTurleri[] = {"Kupa", "Maça", "Karo","Sinek"};
        String kartNumaralari[] = {"1","2","3","4","5","6","7","8","9","10","J","Q","K"};

        int deste []= new int [52];
        destyiOlustur(deste);
        desteyiKaristir(deste);
        desteyiGoster(deste, karTurleri,kartNumaralari);
    }

    private static void desteyiKaristir(int [] deste) {
        for (int i =0; i<deste.length;i++){
            int rastgeleIndex = (int)(Math.random()*deste.length);
            int gecici = deste[rastgeleIndex];

            deste[i] = deste[rastgeleIndex];
            deste [rastgeleIndex] = gecici;
        }
    }

    private static void desteyiGoster(int [] deste, String [] kartTurleri, String [] kartNumaralari) {

        for(int i = 0; i<4;i++){
            String kartTuru = kartTurleri[deste[i]/13];
            String kartNumarasi = kartNumaralari [deste[i]%13];

            System.out.println(kartTuru+ " "+ kartNumarasi);
        }
    }

    private static void destyiOlustur(int []deste) {
        for(int i = 0; i<deste.length;i++){
            deste[i] =i;
        }
    }
}
