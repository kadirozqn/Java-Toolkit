package metotlarVeDizilerSorular;

public class Cozum2 {
    public static void main(String[] args) {
        int matris[][] = new int [3][2];
        int enKucukSayi = 900;
        int enBuyukSayi = 0;
        for(int satir = 0; satir<matris.length;satir++){
            for(int sutun =0;sutun<matris[satir].length;sutun++){
                int rastgeleSayi = (int)(Math.random()*100);
                matris[satir][sutun] = rastgeleSayi;
                System.out.println(satir+". satırdaki "+sutun+". sütunun elemanı: "+matris[satir][sutun]);
                if(enKucukSayi>rastgeleSayi)
                    enKucukSayi=rastgeleSayi;
                if(enBuyukSayi<rastgeleSayi)
                    enBuyukSayi = rastgeleSayi;
            }
        }
        System.out.println("Bu matrıstekı en buyuk sayi: "+ enBuyukSayi+" En kucuk sayi: "+enKucukSayi);
    }
}
