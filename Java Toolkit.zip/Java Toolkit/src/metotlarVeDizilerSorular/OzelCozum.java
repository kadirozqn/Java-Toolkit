package metotlarVeDizilerSorular;

import java.util.Scanner;

public class OzelCozum {
    public static void main(String[] args) {
        //cevap1
        int [][] matrix =  new int [5][5];
        int genelToplam = 0;

        for (int i = 0; i<5; i++){
            for (int j =0; j<5; j++){
                matrix[i][j] = (int)(Math.random()*10);
                System.out.print(matrix[i][j]+ "  ");
            }
            genelToplam = genelToplam + matrix[i][i];
            System.out.println();
        }
        System.out.println("Çarpraz elemanların toplamı: "+genelToplam);

        //cevap2
        Scanner tara = new Scanner(System.in);
        System.out.print("Sayiyi giriniz: ");
        int girilenSayi = tara.nextInt();
        String binarySayi = "";
        if (girilenSayi == 0){
            binarySayi = "0";
        }
        while (girilenSayi>0){

            int mod = girilenSayi %2;
            binarySayi = mod + binarySayi;
            girilenSayi = girilenSayi/ 2 ;
        }
        System.out.println("Girilen sayinin binary karsılıgı: "+binarySayi);

        //cevap3
        Scanner tara2 = new Scanner(System.in);
        System.out.print("Satır sayısını giriniz: ");
        int satirSayisi = tara2.nextInt();

        for(int i = 0; i<satirSayisi;i++){
            for(int j = 0;j<satirSayisi;j++){
                if(i==j || j==(satirSayisi-i-1)){
                    System.out.print("x");
                }else{
                    System.out.print(" ");
                }
            }
            System.out.println(" ");
        }

    }
}
