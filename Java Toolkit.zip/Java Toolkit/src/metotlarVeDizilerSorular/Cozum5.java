package metotlarVeDizilerSorular;

import java.util.Scanner;

public class Cozum5 {
    public static void main(String[] args) {
        Scanner tara = new Scanner(System.in);
        System.out.println("Lütfen öğrenci sayısını giriniz: ");
        int ogrenciSayisi = tara.nextInt();

        System.out.println("Lütfen toplam soru sayısını giriniz: ");
        int soruSayisi = tara.nextInt();

        char [][] tumCevaplar = new char [ogrenciSayisi][soruSayisi];
        char [] cevapAnahtari = new char[soruSayisi];

        cevapAnahtariniOlustur(cevapAnahtari);
        ogrenciCevaplariniYerlestir(tumCevaplar);
        System.out.println("****CEVAPLAR****");
        ogrenciCevaplariniGoruntule(tumCevaplar);
        System.out.println("****CEVAP ANAHTARI****");
        cevapAnahtariniGoruntule(cevapAnahtari);
        ogrencileriDegerlendir(cevapAnahtari,tumCevaplar);

    }
    private static void cevapAnahtariniGoruntule(char[] cevapAnahtari) {
        for(char deger : cevapAnahtari){
            System.out.print(deger+",");
        }
        System.out.println();
    }
    private static void ogrenciCevaplariniGoruntule(char[][] tumCevaplar) {
        for(int satir =0; satir<tumCevaplar.length;satir++){
            for(int sutun = 0; sutun<tumCevaplar[satir].length;sutun++){
                System.out.print(tumCevaplar[satir][sutun]+ ",");
            }
            System.out.println();
        }
    }
    private static void ogrencileriDegerlendir(char[] cevapAnahtari, char[][] tumCevaplar) {
        for (int satir = 0; satir < tumCevaplar.length; satir++) {
            int dogruCevapSayisi = 0;
            for (int sutun = 0; sutun < tumCevaplar[satir].length; sutun++) {
                if (tumCevaplar[satir][sutun] == cevapAnahtari[sutun]) {
                    dogruCevapSayisi++;
                }
            }
            System.out.println(satir + " indexindeki öğrencinin doğru cevap sayisi : " + dogruCevapSayisi);
        }
    }

    private static void cevapAnahtariniOlustur(char[] cevapAnahtari) {
        for(int i =0; i<cevapAnahtari.length;i++){
            cevapAnahtari[i] =cevapOlustur();
        }
    }
    private static void ogrenciCevaplariniYerlestir(char[][]tumCevaplar) {
        for(int satir =0; satir<tumCevaplar.length;satir++){
            for(int sutun = 0; sutun<tumCevaplar[satir].length;sutun++){
                tumCevaplar[satir][sutun]= cevapOlustur();
            }
        }
    }
    public static char cevapOlustur(){
        int rastgeleSayi = 65 + (int)(Math.random() * 5); // 'A' (65) ile 'E' (69) arasında rastgele bir sayı üretir.
        char uretilenCevap = (char) rastgeleSayi;

        // 'A' ile 'E' arasındaki harf aralığında bir cevap üretilene kadar tekrar üret.
        while (uretilenCevap < 'A' || uretilenCevap > 'E') {
            rastgeleSayi = 65 + (int)(Math.random() * 5);
            uretilenCevap = (char) rastgeleSayi;
        }

        return uretilenCevap;
    }

}
