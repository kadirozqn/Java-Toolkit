package metotlarVeDizilerSorular;

import java.util.Scanner;

public class Cozum4 {
    public static void main(String[] args) {
        Scanner tara = new Scanner(System.in);
        System.out.print("Lütfen birinci sayiyi giriniz: ");
        int birinciSayi = tara.nextInt();
        System.out.print("Lütfen ikinci sayiyi giriniz: ");
        int ikinciSayi = tara.nextInt();


        //int ekok = klasikEkokBul(birinciSayi, ikinciSayi);
        //System.out.println(birinciSayi + " ile " + ikinciSayi + " nin ekoku: " + ekok);

        //ebobBul(birinciSayi, ikinciSayi);
        System.out.println("Ekok: "+ekokBul(birinciSayi,ikinciSayi));

    }

    private static int ekokBul(int birinciSayi, int ikinciSayi) {
        //ebob * ekok = s1*s2
        int ekok = (birinciSayi * ikinciSayi) / ebobBul(birinciSayi,ikinciSayi);
        return ekok;
    }
    public static int ebobBul ( int birinciSayi, int ikinciSayi){
            int ebob = 1;
            int kontrol = 2;

            while (kontrol <= birinciSayi && kontrol <= ikinciSayi) {
                if (birinciSayi % kontrol == 0 && ikinciSayi % kontrol == 0) {
                    ebob = kontrol;
                }
                kontrol++;
            }
            if (ebob == 1) {
                System.out.println(birinciSayi + " ile " + ikinciSayi + " aralarında asaldır. ");
            } else {
                System.out.println(birinciSayi + " ile " + ikinciSayi + " nin en buyuk ortak bolenı: " + ebob);
            }
            return ebob;
        }

        private static int klasikEkokBul ( int birinciSayi, int ikinciSayi){
            int buyuk = Math.max(birinciSayi, ikinciSayi);
            int ekok = 0;
            for (int i = buyuk; i < birinciSayi * ikinciSayi; i++) {
                if (i % birinciSayi == 0 && i % ikinciSayi == 0) {
                    ekok = i;
                    break;
                }
            }
            return ekok;
        }
    }

