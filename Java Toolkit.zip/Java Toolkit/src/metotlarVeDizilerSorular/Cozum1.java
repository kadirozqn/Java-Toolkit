package metotlarVeDizilerSorular;

public class Cozum1 {
    public static void main(String[] args) {
        int sayilar [] = new int[100];
        int tumSayilarinToplami = 0;

        for(int i = 0; i<sayilar.length; i++){
            int rastgeleSayi = (int) (Math.random()*100);
            sayilar[i] = rastgeleSayi;
            tumSayilarinToplami+=rastgeleSayi;
            //tumSayilarinToplamı = tumSayilarinToplamı + rastgeleSayi;
        }

        double ortalama = (double)tumSayilarinToplami/sayilar.length;
        System.out.println("Ortalama: "+ortalama);
        int ortalamaAltindaKalanElemanSayisi = 0;
        for(int j=0; j<sayilar.length;j++){
            if(sayilar[j]<ortalama){
                ortalamaAltindaKalanElemanSayisi++;
            }
        }
        System.out.println("Ortalama: "+ortalama+". Ortalama altında kalan eleman sayisi: "+ortalamaAltindaKalanElemanSayisi);
    }
}
