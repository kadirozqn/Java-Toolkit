package collections;

public interface Comparator<T> {
}
