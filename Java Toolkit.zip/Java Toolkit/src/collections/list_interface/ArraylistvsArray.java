package collections.list_interface;

import java.util.ArrayList;
import java.util.Arrays;

public class ArraylistvsArray {
    public static void main(String[] args) {
        ArrayList<String > isimlerListesi = new ArrayList<>();
        String[] isimlerDizisi = new String[9000000];

        long baslamaZamani = System.currentTimeMillis();
        //dizi elemanları atanır
        for(int i = 0; i <9000000; i++){
           isimlerDizisi[i] = "Deneme" +i;
        }
        long bitmeZamani = System.currentTimeMillis();
        System.out.println("Dizi çalışma süresi: " +(bitmeZamani-baslamaZamani));

        baslamaZamani = System.currentTimeMillis();
        for(int i = 0; i <9000000; i++){
            isimlerListesi.add("Deneme" +i);
        }
        bitmeZamani = System.currentTimeMillis();
        System.out.println("Array List çalışma süresi: " + (bitmeZamani-baslamaZamani));

        baslamaZamani = System.currentTimeMillis();
        isimlerDizisi[40000] = "yeni değer";
        bitmeZamani = System.currentTimeMillis();
        System.out.println("Dizinin eleman değiştirme süresi: " +(bitmeZamani-baslamaZamani));

        baslamaZamani = System.currentTimeMillis();
        isimlerListesi.add(40000,"yeni değer");
        bitmeZamani = System.currentTimeMillis();
        System.out.println("Array listin eleman degıstırme suresi: " +(bitmeZamani-baslamaZamani));
    }
}
