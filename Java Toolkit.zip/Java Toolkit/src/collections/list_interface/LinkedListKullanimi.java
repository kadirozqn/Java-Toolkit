package collections.list_interface;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class LinkedListKullanimi {
    public static void main(String[] args) {
        /*LinkedList<Integer> linkedList = new LinkedList<>();
        linkedList.add(1);
        linkedList.add(2);
        linkedList.add(4);
        linkedList.add(2,3);
        System.out.println(linkedList);
        System.out.println(linkedList.get(1));

        ListIterator<Integer> iterator = linkedList.listIterator();
        while (iterator.hasNext()) {
            System.out.print(iterator.next()+ ",");
        }
        System.out.println();*/
        LinkedList<Integer> sayilar = new LinkedList<>();
        ArrayList<Integer> sayilar2 = new ArrayList<>();

        long baslamaSuresi = System.currentTimeMillis();
        linkedListiHazirla(sayilar);
        long bitisSuresi = System.currentTimeMillis();
        System.out.println("LinkedList sıralama: " +sayilar);
        System.out.println("LinkedList çalışma süresi: " +(bitisSuresi-baslamaSuresi));

        baslamaSuresi = System.currentTimeMillis();
        arrayListiHazirla(sayilar2);
        bitisSuresi = System.currentTimeMillis();
        System.out.println("ArrayList sıralama" +sayilar2);
        System.out.println("ArrayList  çalışma süresi: " +(bitisSuresi-baslamaSuresi));



    }

    private static void arrayListiHazirla(ArrayList<Integer> sayilar2) {
        for (int i = 0; i < 10000; i++) {
            int yeniEklenecekEleman = ((int)(Math.random()*50000));
            siraliEkle(sayilar2,yeniEklenecekEleman);
        }
    }

    public static void linkedListiHazirla(LinkedList<Integer> sayilar){
        for (int i = 0; i < 10000; i++) {
            int yeniEklenecekEleman = ((int)(Math.random()*50000));
            siraliEkle(sayilar,yeniEklenecekEleman);
        }
    }
    public static boolean siraliEkle(List<Integer> liste,int yeniEklenecekEleman){
        ListIterator<Integer> iterator = liste.listIterator();
        while(iterator.hasNext()){
            int karsilastirmaSonucu = iterator.next().compareTo(yeniEklenecekEleman);
            if(karsilastirmaSonucu == 0){
                iterator.add(yeniEklenecekEleman);
                return true;
            }else if(karsilastirmaSonucu > 0 ){
                iterator.previous();
                iterator.add(yeniEklenecekEleman);
                return true;
            }else {

            }
        }
        iterator.add(yeniEklenecekEleman);
        return true;
    }
}

