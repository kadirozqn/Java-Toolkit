package collections.list_interface;

import java.util.*;

public class ArraylistKullanimi {
    public static void main(String[] args) {
        //Bellekte 10 adet eleman tutan arraylisti olusturur.
        ArrayList<Integer> sayilar = new ArrayList<>();

        sayilar.add(1);
        sayilar.add(2);
        sayilar.add(3);
        System.out.println(sayilar);

        //verdiğimiz deger kadar bellekte kapasite ayırır.
        ArrayList<String> isimler = new ArrayList<>(20);
        isimler.add("Kadir");
        isimler.add("Fatma");
        isimler.add("Abdulselam");
        System.out.println(isimler);

        //arraylisti verilen sayi kadar eleman tutacak sekılde arttırır.
        isimler.ensureCapacity(100);

        //arraylisti sadece icindeki eleman tutacak kadar kucultur.
        isimler.trimToSize();

        ArrayList<String> isimlerYedek =  new ArrayList<>(isimler);
        System.out.println(isimlerYedek);
        //eleman sayisini gosterır
        System.out.println("Listede kac eleman var? " +isimlerYedek.size());
        //liste bos ise true dolu ıse fale degerı dondurur
        System.out.println("Liste bos mu? "+isimlerYedek.isEmpty());
        //butun lısteyı temızler
        isimlerYedek.clear();

        //listede eleman aramaya yarar. olan lemena true olmöayana false degerı dondurur
        System.out.println("Listede Kadir var mı? " + isimler.contains("Kadir"));
        System.out.println("Listede Ayşe var mı? " + isimler.contains("Ayşe"));

        //arraylisti diziye donusturur
        String[] isimlerDizisi = isimler.toArray(new String[0]);
        System.out.println(isimlerDizisi[1]);

        //belırlı ındekstekı elemanı okumak ıcın kullanılır
        System.out.println(isimler.get(0));

        //belırlı ındekstekı elemanı guncellemek ıcın kullanılır
        isimler.set(0,"yeni kadir");
        System.out.println(isimler.get(0));

        //belırlı bır ındekse eleman yerlestırmek
        isimler.add(2,"Ali");
        System.out.println(isimler);

        //belırlı bır ındekstekı elemanı sılmek ıcın kullanırız
        isimler.remove("Ali");
        isimler.remove(1);
        isimler.add("Emre");
        isimler.add("Cihan");
        isimler.add("Emine");
        isimler.add("Diyar");

        System.out.println(isimler);
        //belırlı ındeksler arasındakı elemanları yenı bır lısteye atar.
        List<String> yeniIsimlerListesi = isimler.subList(1,3);
        System.out.println(yeniIsimlerListesi);

        ArrayList<String> erkekIsimleri = new ArrayList<>();
        erkekIsimleri.add("Mehmet");
        erkekIsimleri.add("Mustafa");
        ArrayList<String> kizIsimleri = new ArrayList<>();
        kizIsimleri.add("Melisa");
        kizIsimleri.add("Ecem");
        kizIsimleri.add("Ayşe");
        //iki listeyi birleştirmek belirli bir indeksten sonra bırlestırmek
        erkekIsimleri.addAll(kizIsimleri);
        System.out.println(erkekIsimleri);

        erkekIsimleri.addAll(0, kizIsimleri);
        System.out.println(erkekIsimleri);

        //Arrayi (diziyi) listeye donusturmek
        //yontem1
        String[] sehirler = {"Ankara", "İstanbul", "Van"};
        List<String> sehirlerListesi;
        sehirlerListesi = Arrays.asList(sehirler);
        System.out.println(sehirlerListesi);

        //yontem2
        ArrayList<String> sehirler2 = new ArrayList<>(Arrays.asList(sehirler));
        System.out.println(sehirler2);

        //yontem3
        List<String> sehirler3 = new ArrayList<>(); //üst sınıfın nesnesını (List) alt sınıfa bagladık (ArrayList)
        Collections.addAll(sehirler3,sehirler);
        System.out.println(sehirler3);
    }
}
