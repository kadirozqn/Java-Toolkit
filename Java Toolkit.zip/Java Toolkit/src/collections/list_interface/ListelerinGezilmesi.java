package collections.list_interface;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class ListelerinGezilmesi {
    public static void main(String[] args) {
        ArrayList<Integer> sayilar1 = new ArrayList<>();
        sayilar1.add(1);
        sayilar1.add(2);
        sayilar1.add(3);
        sayilar1.add(4);

        ArrayList<Integer> sayilar2 = new ArrayList<>();
        sayilar2.add(3);
        sayilar2.add(4);
        sayilar2.add(5);
        sayilar2.add(6);

        System.out.println(sayilar1);
        System.out.println("For döngüsü ie gezmek;");
        for(int i = 0; i < sayilar1.size(); i++){
            System.out.print(sayilar1.get(i) +",");
        }
        System.out.println();
        System.out.println("Gelişmiş for ile gezinmek");
        for (int gecici : sayilar1){
            System.out.print(gecici+",");
        }/*
        for(int i = 0; i < sayilar1.size(); i++){
            System.out.println(sayilar1.contains(sayilar1.get(i)));
                sayilar1.remove(i);
        }
        System.out.println("Çıkarılma işleminden sonra sayilar1 " + sayilar1);
*/
        System.out.println("Iterator ıle lıstenın gezılmesı: ");
        Iterator<Integer> iterator = sayilar1.iterator();
        while (iterator.hasNext()) {
            System.out.print(iterator.next()+" ");
        }
        System.out.println();
        System.out.println("Iterator ıle sayıların dızıden cıkarılması: ");
        Iterator<Integer> iterator1 = sayilar1.iterator();
        while(iterator1.hasNext()) {
            if (sayilar2.contains(iterator1.next())) {
                iterator1.remove();
            }
        }
        System.out.println(sayilar1);
        System.out.println("List Iterator ıle lıstelerde gezınmek");
        ListIterator<Integer> listIterator = sayilar2.listIterator();
        while(listIterator.hasNext()){
            System.out.println(listIterator.next());
        }
        System.out.println("List Iterator ıle sondan basa gezınmek;");
        ListIterator<Integer> listIteratorSondanBasa = sayilar2.listIterator(sayilar2.size()); //lıstenın son ındısını gosterıyoruz
        while(listIteratorSondanBasa.hasPrevious()){
            System.out.println("Index: "+listIteratorSondanBasa.previousIndex()+" eleman : "+listIteratorSondanBasa.previous());
        }



    }

}
