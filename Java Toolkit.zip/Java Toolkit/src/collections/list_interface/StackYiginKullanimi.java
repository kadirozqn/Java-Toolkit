package collections.list_interface;

import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

public class StackYiginKullanimi {
    //vector yerıne arraylıst stack yerıne lınkedlıst kullanabılırız. daha yararlı olacaktır ama sen genede bunları bıl.
    public static void main(String[] args) {
        Stack<String> yigin = new Stack<>();
        yigin.add("Emre");
        yigin.add("Kadir");
        yigin.add("Ayşe");
        System.out.println(yigin);

        System.out.println(yigin.pop()); //yıgının sonundan eleman cıkarır
        System.out.println(yigin);
        System.out.println(yigin.peek()); //sadece en sondakı elemanı gosterır
        System.out.println(yigin);
        System.out.println(yigin.push("Can")); //listenın sonuna eleman ekler
        System.out.println(yigin);
        System.out.println(yigin.search("Can")); //yıgında eger aranan eleman varsa ındıs degerını verır yoksa -1 degerı dondurur
        System.out.println(yigin.isEmpty());

        LinkedList<String> yigin2 = new LinkedList<>();
        yigin2.push("Kadir");
        yigin2.push("Esra");
        yigin2.add("Burak"); //add metodu ıle eklersek yıgının en altına yerlestırır eklenen elemanı.
        yigin2.push("Abdulselam");
        yigin2.push("Barış");

        System.out.println(yigin2.pop()); // sondan eleman cıkardık
        System.out.println(yigin2);
    }
}
