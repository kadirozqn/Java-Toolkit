package collections.map_interface;

import java.util.Comparator;
import java.util.TreeMap;

public class TreeMapKullanimi {
    public static void main(String[] args) {
        TreeMap<String, Integer> treeMap = new TreeMap<>();
        treeMap.put("A", 1);
        treeMap.put("B", 2);
        treeMap.put("C", 3);
        treeMap.put("D", 4);

        System.out.println(treeMap);

        TreeMap<Kare, String> kareTreeMap = new TreeMap<>(new Comparator<Kare>() {
            @Override
            public int compare(Kare o1, Kare o2) {
                System.out.println("Comperatorun compareto metodu calıstı.");
                    if(o1.kenar < o2.kenar){
                        return -1;
                    }else if(o1.kenar > o2.kenar){
                        return 1;
                    }else return 0;
            }
        });
        Kare k1 = new Kare(4,"Mavi");
        Kare k2 = new Kare(5,"Kırmızı");
        Kare k3 = new Kare(6,"Sarı");
        kareTreeMap.put(k1,"Mavi kare");
        kareTreeMap.put(k2,"Kırmızı kare");
        kareTreeMap.put(k3,"Sarı kare");


        System.out.println(kareTreeMap.lowerKey(k1));
        System.out.println(kareTreeMap.higherKey(k1));
        
        System.out.println(kareTreeMap);
    }
}
class Kare {
    int kenar;
    String renk;

    public Kare(int kenar, String renk) {
        this.kenar = kenar;
        this.renk = renk;
    }

    @Override
    public String toString() {
        return "Kare{" +
                "kenar=" + kenar +
                ", renk='" + renk + '\'' +
                '}';
    }

        public int compareTo(Kare o1) {
            System.out.println("Comparablenın compare to metodu calıstı.");
            if(this.kenar < o1.kenar){
                return -1;
            }else if(this.kenar > o1.kenar){
                return 1;
            }else return 0;
    }
}