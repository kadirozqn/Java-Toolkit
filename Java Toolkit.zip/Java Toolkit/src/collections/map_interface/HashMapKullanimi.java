package collections.map_interface;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;

public class HashMapKullanimi {
    public static void main(String[] args) {
          HashMap<String, Integer> map = new HashMap<>(16,0.75f);
          map.put("Kadir",31);
          map.put("gs",23);
          map.put("Ayşe",16);
          map.put("Ali",12);
          map.put("Null",0);

        System.out.println(map.get("Ali"));
        Iterator iterator = map.keySet().iterator();
        while (iterator.hasNext()) {
          /*String key = (String) iterator.next();
            System.out.println(key);*/
            System.out.println(iterator.next());
        }



/*      String st1 = "Kadir";
        String  st2 = "Ayşe";
        String  st3 = "Kadir";
        System.out.println(st1.hashCode());
        System.out.println(st2.hashCode());
        System.out.println(st3.hashCode());

        Ogrenci ogr1 = new Ogrenci(1,"Kadir Özan");
        System.out.println(ogr1.hashCode());
        ogr1.id = 2;
        ogr1.ad = "Kadir Özan";
        System.out.println("ogr1'in gosterdıgı deger: " +ogr1.hashCode());

        Ogrenci ogr2 = new Ogrenci(1,"Kadir Özan");
        System.out.println("ogr2'nin gosterdıgı deger: " +ogr2.hashCode());
        System.out.println("ogr1 ve ogr2 'nin gostermıs oldugu deger bırbırıne esıt mı: " +ogr1.equals(ogr2));
        System.out.println("ogr1 hash code: " +ogr1.hashCode());
        System.out.println("ogr2 hash code: " +ogr2.hashCode());

      HashMap<Integer, String> hm = new HashMap<Integer, String>();
         hm.put(1, "Adana");
         hm.put(34, "İstanbul");
         hm.put(65,"Van");
         hm.put(6,"Ankara");
         hm.put(35,"İzmir");
         hm.put(null, "null değeri");

         HashMap<Integer, String> hmYedek = new HashMap<Integer,String>();
        System.out.println("hm yedek size: " + hmYedek.size());
        hmYedek.putAll(hm);
        System.out.println("hm size: " + hmYedek.size());
        hmYedek.clear();
        System.out.println("clear sonrası hm yedek size: " + hmYedek.size());

        System.out.println(hm.get(null));
        System.out.println(hm);
        String deger = hm.get(6);
        System.out.println(deger);
        System.out.println(hm.size());
        System.out.println(hm.isEmpty());
        System.out.println(hm.containsKey(16));
        System.out.println(hm.containsValue("Ankara"));
        System.out.println(hm.remove(35));
        System.out.println(hm.size());
        System.out.println("Anahtarlar: ");
        for(Integer key : hm.keySet()) { // anahtar
            System.out.println("Key : " +key);
        }
        System.out.println("Değeler:");
        for (String value : hm.values()) {
            System.out.println("Value : " + value +" ");
        }
        for(Map.Entry<Integer, String> entry : hm.entrySet()) {
            System.out.println("Key : " + entry.getKey() + " Value : " + entry.getValue());
        }*/

    }
}
class Ogrenci {
    int id;
    String  ad;

    public Ogrenci(int id, String ad) {
        this.id = id;
        this.ad = ad;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Ogrenci ogrenci)) return false;
        return id == ogrenci.id && Objects.equals(ad, ogrenci.ad);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, ad);
    }
}