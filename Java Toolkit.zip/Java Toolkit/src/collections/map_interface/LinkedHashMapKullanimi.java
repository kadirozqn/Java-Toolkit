package collections.map_interface;

import java.util.LinkedHashMap;
import java.util.Map;

public class LinkedHashMapKullanimi {
    public static void main(String[] args) {
        //normal hasmapte sıralamayı ekledıgımız sırada yapamayız amaa lınkedhasmapte ekledıgımız sırada gorebılırız.
        LinkedHashMap<String,Integer> linkedHashMap = new LinkedHashMap<>();
        linkedHashMap.put("Kadir",31);
        linkedHashMap.put(null,0);
        linkedHashMap.put("Ayşe",1);
        linkedHashMap.put("Fatma",2);
        System.out.println(linkedHashMap);

        for (String gecici : linkedHashMap.keySet()) {
            System.out.println(gecici);
        }
        for (int gecici : linkedHashMap.values()) {
            System.out.println(gecici);
        }

        for(Map.Entry<String,Integer> entry : linkedHashMap.entrySet()) {
            System.out.println(entry);
        }

    }

}
