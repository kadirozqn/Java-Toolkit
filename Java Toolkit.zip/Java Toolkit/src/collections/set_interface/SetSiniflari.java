package collections.set_interface;

import java.util.*;

public class SetSiniflari {
    public static void main(String[] args) {
        HashSet<String> harfler = new HashSet<>();
        //EKLEME VEYA FARKLI BIR SIRALAMAYI GOZ ARDI EDIYORSAK KULLANABILIRIZ
        harfler.add("a");
        harfler.add("b");
        harfler.add("c");
        harfler.add("d");
        harfler.add("d");
        harfler.add("d");
        harfler.add("d");
        harfler.add("2");
        harfler.add("e");
        harfler.add("d");
        System.out.println(harfler);



        LinkedHashSet<String> linkedHashSet = new LinkedHashSet<>();
        //EKLEME SIRASINA GORE VE TEKRAR EDEN YAPILARI GOREMEZDEN GELEN BIR YAPI ISTIYORSAK KULLANABILIRIZ
        linkedHashSet.add("a");
        linkedHashSet.add("b");
        linkedHashSet.add("c");
        linkedHashSet.add("d");
        linkedHashSet.add("d");
        linkedHashSet.add("d");                                                          
        linkedHashSet.add("d");
        linkedHashSet.add("2");
        linkedHashSet.add("e");
        linkedHashSet.add("d");
        System.out.println(linkedHashSet);
        //set yapısını dızıye cevırebılırız
        Object[] geciciDizi =  linkedHashSet.toArray();
        System.out.println(geciciDizi[0].toString());

        TreeSet<String> treeSet = new TreeSet<>();
        //sıralamak ıstıyorsak bunu kullanabılırız. a-z ve rakamlar en basa gelır
        //treesette null degerını eklememıze ızın vermez ama dıgerlerınde kullanabılırz lın kedsette sadece bır adet nuull degerı saklamamıza ızın verır
        treeSet.add("a");
        treeSet.add("b");
        treeSet.add("c");
        treeSet.add("d");
        treeSet.add("d");
        treeSet.add("d");
        treeSet.add("d");
        treeSet.add("2");
        treeSet.add("e");
        treeSet.add("d");


        Iterator<String> iterator = treeSet.iterator();
        while(iterator.hasNext()){
            System.out.print(iterator.next()+"-");
        }
        System.out.println();
        System.out.println(treeSet);
    }
}
