package collections.set_interface;

import java.util.Iterator;
import java.util.TreeMap;
import java.util.TreeSet;

public class SortedNavigableInterfaceMetotlari {
    public static void main(String[] args) {
        TreeSet<String> set = new TreeSet<>();
        set.add("1");
        set.add("2");
        set.add("3");
        set.add("4");
        TreeMap<String,Integer> map = new TreeMap();
        map.put("1",1);
        map.put("2",2);
        map.put("3",3);
        map.put("4",4);

        //Sortedset ve sortedmap metotları
        System.out.println(map.comparator());
        System.out.println(map.comparator());

        TreeSet<String> yedekSet = (TreeSet<String>)set.subSet ("2","4"); // yenı bır set olusturmak
        System.out.println(yedekSet);
        System.out.println(map.subMap("2","4"));

        System.out.println(set.headSet("4"));// gırdıgımız ındekse kadar olan elemanları yazar olmayan bır ındıs degerıde verırsek tum lısteyı verecektır
        System.out.println(map.headMap("4"));

        System.out.println(set.tailSet("2"));
        System.out.println(map.tailMap("3"));

        System.out.println(map.firstKey());
        System.out.println(set.first());

        System.out.println(map.lastEntry());
        System.out.println(set.last());

        //NavigableSet  ve Navigablemap metotları

        System.out.println("Lower set: " + set.lower("3")) ;
        System.out.println("Lower map: " +map.lowerKey("3"));

        //verılen key degerıne esıt veya ondan bır kucuk olanı verır
        System.out.println("Floor set: " + set.floor("3"));
        System.out.println("Floor map: " + map.floorKey("3"));

        //verılen key degerıne esıt veya ondan bır buyuk olanı verır
        System.out.println("ceiling set: " + set.ceiling("3"));
        System.out.println("ceiling map: " + map.ceilingKey("3"));

        System.out.println("higher set: " + set.higher("2 "));
        System.out.println("higher map: " + map.higherKey("2"));

        //ılk elemanı verır ve sonra yapıdan sıler
        System.out.println("poll first: " +set.pollFirst());
        //son eleamnı verır ve sonra yapıdan sıler
        System.out.println("poll last: " +set.pollLast());

        Iterator<String> iterator = set.descendingIterator();
        while (iterator.hasNext()) {
             System.out.println(iterator.next());
        }
     }
}
