package collections.set_interface;

import javax.print.DocFlavor;
import java.util.*;

public class QueuevePriorityQueue {
    public static void main(String[] args) {

        PriorityQueue<Ogrenci> pq = new PriorityQueue<>();
        pq.offer(new Ogrenci(1,82));
        pq.offer(new Ogrenci(2,56));
        pq.offer(new Ogrenci(3,25));
        pq.offer(new Ogrenci(4,75));

        PriorityQueue<Ogrenci> pq2 = new PriorityQueue<>(new Comparator<Ogrenci>() {

            @Override
            public int compare(Ogrenci o1, Ogrenci o2) {
                if (o1.id < o2.id) return -1;
                else if (o1.id > o2.id) return 1;
                else return 0;
            }
        });

        while (!pq.isEmpty()) {
            System.out.println(pq.poll());
        }


        /*PriorityQueue<String> isimler = new PriorityQueue<>();
        isimler.offer("Ayşe");
        isimler.offer("Fatma");
        isimler.offer("Kadir");
        isimler.offer("Abdulselam");
        isimler.offer("Ali");

        //priority kuyrukta amac en sona eleman ekler en bastan eleman cıakrırız amacımız budur.
        // bunun harıcınde kuyruklar pek kullanıslı degıldır. rahatca kuyruktakı elemanlarda gezınemeyız.
        System.out.println("Poll metotu ıle:");
        while(!isimler.isEmpty()) {
            System.out.println(isimler.poll());
        }
        System.out.println("Remove metotu ıle:");
        while (!isimler.isEmpty()) {
            System.out.println(isimler.remove());
        }

        Iterator<String> iterator = isimler.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
        //System.out.println(isimler); calısmıyor

------------------------------------------------------------------------------------------------------------------------------------------------------------

        /* Queue<Integer>sayilar =new LinkedList<>();

        //eleman ekleyeceksek en sondan eleman okuyacaksak en bastan okuyacagız.
        //first in first out seklınde calısır
        sayilar.offer(1);
        sayilar.offer(2);
        sayilar.offer(3);
        sayilar.offer(3);
        sayilar.offer(42);
        sayilar.add(2);

        System.out.println(sayilar);
        System.out.println(sayilar.peek());
        System.out.println(sayilar.poll()); //kuyrugun basındakı elemanı alır ve kuyruktan cıkarır
        //poll metodunu kuyrukta eleman kalmayana kadar calıstırsak sonrakı degerler null olarak atanır.
        // eger poll metotunu kullanıp tum elemanları cıkardıktan sonra sayilar.remover() dersek hata alırız.
        System.out.println(sayilar);*/
    }
}
class Ogrenci implements Comparable <Ogrenci> {
    int id;
    int notDegeri;

    public Ogrenci(int id, int notDegeri) {
        this.id = id;
        this.notDegeri = notDegeri;
    }

    @Override
    public int compareTo(Ogrenci o) {
        if(this.notDegeri < o.notDegeri){
            return 1;
        }else if(this.notDegeri > o.notDegeri){
            return -1;
        }else return 0;
    }

    @Override
    public String toString() {
        return "Ogrenci{" +
                "id=" + id +
                ", notDegeri=" + notDegeri +
                '}';
    }
}