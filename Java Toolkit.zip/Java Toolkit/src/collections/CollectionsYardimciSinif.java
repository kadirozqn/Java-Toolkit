package collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;

public class CollectionsYardimciSinif {
    public static void main(String[] args) {
        Student s1 = new Student(1, "KADİR");
        Student s2 = new Student(2, "AYŞE");
        Student s3 = new Student(3, "FATMA");
        Student s4 = new Student(4, "ALİ");
        Student s5 = new Student(5,"ABULSELAM");

        ArrayList<Student> ogrenciler = new ArrayList<>();
        ogrenciler.add(s1);
        ogrenciler.add(s2);
        ogrenciler.add(s3);
        ogrenciler.add(s4);
        ogrenciler.add(s5);

        Student enBuyukOgrenci = Collections.max(ogrenciler, new Comparator<>() {
            @Override
            public int compare (Student o1, Student o2) {
                if (o1.name.compareTo(o2.name) < 0) {
                    return -1;
                }else if (o1.name.compareTo(o2.name) > 0) {
                    return 1;
                }else return 0;
            }
        });
        System.out.println("Max ogrenci: " + enBuyukOgrenci);

        Student enKucukOgrenci = Collections.min(ogrenciler);
        System.out.println("En kucuk ogrenci: " + enKucukOgrenci);

        ArrayList<Student> yedekListe = new ArrayList<>(ogrenciler);
        Collections.copy(yedekListe,ogrenciler);
        System.out.println(yedekListe);

        System.out.println("Sıralamadan Önce: " + ogrenciler);
        Collections.sort(ogrenciler, new Comparator<Student>() {
            @Override
            public int compare (Student o1, Student o2) {
                if (o1.id<o2.id) {
                    return 1;
                }else if (o1.id>o2.id) {
                    return -1;
                }else return 0;
            }


        });
        System.out.println("Sıralamadan sonra: " + ogrenciler);
        Collections.reverse(ogrenciler);
        System.out.println("Ters sırada Ogrencıler: "+ ogrenciler);
        Collections.shuffle(ogrenciler);
        System.out.println("Karıştırılıktan sonra: " + ogrenciler);

        //bınary search ıcın oncelıkle bır sıralama yapmamız sart
        int sonuc  = Collections.binarySearch(ogrenciler, s1);
        System.out.println("sonuc: "+ sonuc);


    }
}
class Student implements Comparable<Student> {
    int id;
    String name;

    public Student(int id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }

    @Override
    public int compareTo(Student o) {
       if(this.name.compareTo(o.name) < 0) {
           return -1;
       }else if(this.name.compareTo(o.name) > 0) {
           return 1;
       }else return 0;
    }
}