package azKodCokIs;

public class BindingTurleri {
    public static void main(String[] args) {
        /*UstSinif.adiniSoyleStatic();
        AltSinif.adiniSoyleStatic();

        UstSinif u1 = new UstSinif();
        u1.adiniSoyleStatic();
        AltSinif a1 = new AltSinif();
        a1.adiniSoyleStatic();

        UstSinif ustSinif = new AltSinif();
        ustSinif.adiniSoyleStatic();*/

        UstSinif u1 = new UstSinif();
        u1.adiniSoyle();

        AltSinif a1 = new AltSinif();
        a1.adiniSoyle();

        UstSinif us1 = new AltSinif();
        us1.adiniSoyle();

        /*
        Casting Instance Of işlemi;
         GeometrikSekil gs2 = new Kare(5);// implict, dolaylı yoldan cast ıslemı
         GeometrikSekil gs3 = new Diktortgen(5,10);
         Diktortgen d2 = new Kare(5);

         Diktortgen d3 = new (Diktortgen) gs3; // exclipt direkt olarak cast ıslemı, downcasting denir.
        */
    }
}
class UstSinif {
    public static void adiniSoyleStatic() {
        System.out.println("Üst sınıfın static  adını söyle metotu çağrıldı.");
    }
    public void adiniSoyle() {
        System.out.println("Üst sınıfın adını söyle metotu çağrıldı.");
    }
}
class AltSinif extends UstSinif {
    public static void adiniSoyleStatic() {
        System.out.println("Alt sınıfın static  adını söyle metotu çağrıldı.");
    }

    @Override
    public void adiniSoyle() {
        System.out.println("Alt sinifin adını söyle metodu çalıstı.");
    }
}