package azKodCokIs;

public class polymorphismVeDynamicBinding {
    public static void main(String[] args) {
        // polymorphism ust sınıf degıskenının alt sınıf nesnelerını referans edebılmesıdır
        Hayvan h1 = new Hayvan();
        Kopek k1 = new Kopek("Golden");
        Kedi ke1 = new Kedi("Van Kedisi");

        adiniSoyle(h1);
        adiniSoyle(k1);
        adiniSoyle(ke1);

    }
    public  static void adiniSoyle(Hayvan hayvan){ // polymorphısm
        hayvan.adiniSoyle();
    }
}

class Hayvan{
    private int ayakSayisi;

    public int getAyakSayisi() {
        return ayakSayisi;
    }

    public void setAyakSayisi(int ayakSayisi) {
        this.ayakSayisi = ayakSayisi;
    }
    public void adiniSoyle(){
        System.out.println("Ben hayvan sınıfı üyesiyim.");
    }
}

class Kopek extends Hayvan{
    private String tur;

    public Kopek(String tur){
        setAyakSayisi(4);
        setTur(tur);
    }
    public String getTur() {
        return tur;
    }

    public void setTur(String tur) {
        this.tur = tur;
    }

    @Override
    public void adiniSoyle() {
        System.out.println("Ben bır kopek sınıfı nesnesiyim.");
    }
}
class Kedi extends Hayvan{
    private String cins;

    public Kedi(String cins){
        setAyakSayisi(4);
        setCins(cins);
    }
    public String getCins() {
        return cins;
    }

    public void setCins(String cins) {
        this.cins = cins;
    }

    @Override
    public void adiniSoyle() {
        System.out.println("Ben bır kedı sınıfı nesnesıyım. ");
    }
}