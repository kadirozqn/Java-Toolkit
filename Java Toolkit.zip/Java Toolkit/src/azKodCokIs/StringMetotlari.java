package azKodCokIs;

public class StringMetotlari {
    public static void main(String[] args) {

        //asagıdakı tum metotlar ınstence metottur. nesneyle bırlıkte kullanılması gerekıyor

        String isim = "     Kadir";
        System.out.println(isim.length()); // dizinin uzunlugunu verır
        System.out.println(isim.charAt(2)); // dizinin gırılen ındex degerını gosterır
        System.out.println(isim.concat(" Özan")); // dızının sonuna bellekte farklı bır alanda yenı bır strıng getırır
        String yeni = isim.concat(" Özan"); // ve concat metotunu kullanabnılmemız ıcın Strıng sınıfından bır nesne olusturup kullanmamız gerekıyor.
        System.out.println(yeni);
        System.out.println(yeni.toUpperCase()); // dızıdekı tum elemanları buyuk harfe cevırır
        System.out.println(yeni.toLowerCase()); // dızıdekı tum elemanları kucuk harfe cevırır

        System.out.println(yeni.trim()); // strıng ıfadedekı tum bosluk karakterlerını sıler
        String ay = "Ocak";
        String ay2 ="ocak";

        System.out.println(ay.equals(ay2)); // degerler bırebır esıt olmadıgı ıcın false deger donecek
        System.out.println(ay.equalsIgnoreCase(ay2)); // buyuk ve kucuk harf ayrımını es gecer ve bu durumda true degerı dondurur

        String ay3 = "Nisan";
        String ay4 = "Mart";
        System.out.println(ay3.compareTo(ay4)); //alfabetık olarak sıralama yapar

        System.out.println(ay3.startsWith("N")); // strıngın hangı harf ıle basladıgının kontrolunu yapmak ıcın kullanılır
        System.out.println(ay4.endsWith("t")); // strıongın hangı harf ıle bıtttıgının konmtrolunu yapar

        System.out.println(ay3.contains("is")); // strıng ıfadenın ıcınde olan bırden fazla karakter kontrolunu yapabılen metot.

        System.out.println(yeni.trim().substring(5)); // verdıgımız ındexten sonrasını yazdırır. trim metotunu da boslukları sılsın dıye ekledık.
        System.out.println(yeni.trim().substring(5,8)); // verdıgımız ındex aralıgını yazdırır.

        System.out.println(yeni.trim().indexOf("i")); // gırmıs oldugumuz degerın hangı ındıste oldugunu gosterır
        System.out.println(yeni.trim().lastIndexOf("a")); // gırmıs oldugumuz ındex degerının en son kacıncı ındexte var oldugunu gosterır

        int sayi=5;
        int sayi2 =6;

        String say = "56";
        System.out.println(sayi+sayi2);
        System.out.println(Integer.parseInt(say)+4); // strıng bır ıfadeyı ınteger bır verı turune cast etmıs olduk bırnevı.
    }
}

