package azKodCokIs;

public class KonuyuToparlayalim {
    public static void main(String[] args) {
        Canli3 c1 = new Canli3();
        c1.adiniSoyle();

        //Kartal k1 = new Kartal();
        Canli3 k1 = new Kartal();
        k1.adiniSoyle();
        ((Kartal) k1).uc(); // Casting islemi

        //Panda p1 = new Panda();
        Canli3 p1 = new Panda();
        p1.adiniSoyle();
        ((Panda) p1).oyna(); // Casting islemi

        //Panda p2 = (Panda)new Canli(); // ust sınıf alt sınıfa donusturulemez. Hatalı bır kullanım.
        Panda p3 = (Panda) p1; // bu da dogru bır kullanım ve castıng  ıslemı olur.
        p3.adiniSoyle();
        p3.oyna();
    }
        public static Canli3 rastgeleSec() {

            int sec = (int)(Math.random()*3);
            Canli3 canli;
            if(sec==0){
                canli = new Canli3();
            }else if(sec == 1){
                canli = new Kartal();
            }else{
                canli = new Panda();
            }
            return canli;
        }
    }

    class Canli3 {
        public void adiniSoyle(){
            System.out.println("Ben bir hayvan sınıfı uyesıyım.");
        }
    }
    class Kartal extends Canli3 {
        @Override
        public void adiniSoyle() {
            System.out.println("Ben bir kartal sınıfı uyesıyım. ");
        }
        public void uc(){
            System.out.println("Ben ucabılırım.");
        }
    }
    class Panda extends Canli3{
        @Override
        public void adiniSoyle() {
            System.out.println("Ben bır panda sınıfı uyesıyım.");
        }
        public void oyna(){
            System.out.println("Ben oyun oyunamayı cok severım.");
        }
    }