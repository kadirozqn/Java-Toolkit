package azKodCokIs;

import java.util.ArrayList;

public class ArrayListKullanimi {
    public static void main(String[] args) {
        //Telefon[] telefonlar = new Telefon[20];kullanışsız bır yapı oldugu ıcın bunun yerıne arraylıstlerı tercıh edebılırız.
        ArrayList<Telefon>telefonlar = new ArrayList<>();
        Telefon t1 = new Telefon("Mİ",3000);
        Telefon t2 = new Telefon("Samsung",5000);
        Telefon t3 = new Telefon("Iphone",7000);

        telefonlar.add(t1);
        telefonlar.add(t2);
        telefonlar.add(t3);
        //telefonlar.add(0,2);//ındekslı sekılde eleman ekleme
        //telefonlar.remove(t3);//lısteden eleman sılmeye yarar.
        System.out.println(telefonlar.size()); // lıstemızde kac eleman oldugunu gosterır.

        telefonlar.add(t1);
        telefonlar.add(0,t3);
        telefonlar.set(3,t2); //belırtılen ındexte gonmderılen degerı yer degıstırır
        telefonlar.remove(0); //lısteden eleman sıler
        listeyiYazdir(telefonlar);
        System.out.println(telefonlar.contains(t3));
        System.out.println(telefonlar.contains(t1));
        System.out.println("Degısıklıklerden sonra;");


        /*telefonlar[0] = t1;
        telefonlar[1] = t2;
        telefonlar[2] = t3;

        System.out.println(telefonlar[0]);
        System.out.println(telefonlar[1]);
        System.out.println(telefonlar[2]);

       telefonlar = new Telefon[25];

        System.out.println(telefonlar[0]);
        System.out.println(telefonlar[1]);
        System.out.println(telefonlar[2]);*/ // kullanışsız bır yapı oldugu ıcın bunun yerıne arraylıstlerı tercıh edebılırız.

        listeyiYazdir(telefonlar);
    }

    private static void listeyiYazdir(ArrayList<Telefon> liste) {
        /*for(int i=0;i<liste.size();i++){
            System.out.println(liste.get(i));
        }*/

        for(Telefon oankideger : liste){
            System.out.println(oankideger);
        }
    }
}
class Telefon{
    String model;
    int fiyat;

    public Telefon(String model, int fiyat) {
        this.model = model;
        this.fiyat = fiyat;
    }

    @Override
    public String toString() {
        return "Telefon{" +
                "model='" + model + '\'' +
                ", fiyat=" + fiyat +
                '}';
    }
}
