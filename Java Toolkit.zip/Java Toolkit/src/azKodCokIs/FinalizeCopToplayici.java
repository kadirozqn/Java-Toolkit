package azKodCokIs;

public class FinalizeCopToplayici {
    public static void main(String[] args) {

        //Artık kullanılan bır yapı degıl ama mulakatlar vs. ıcın bılmekte fayda var.

        A a1  = new A(10);
        A a2 = new A(15);

        a1 = a2;

        for (int i =0; i<100; i++){
            a2 = new A(500);

            if(i==10){
                System.gc();
            }
        }
    }
}
class A {
    int i;

    public A(int parametre){
        this.i = parametre;
    }

    @Override
    protected void finalize() throws Throwable {
        System.out.println("Finalize tetiklendi");
    }
}