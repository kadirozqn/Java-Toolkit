package azKodCokIs;

public class FinalKavrami {
    public static void main(String[] args) {
        int sayi = 10;
        sayi = 15;

        final int sayi2; //sabit tanımlama gıbı dusunebılırız.
        sayi2 = 55;
    }
}
class MyParents {
    final public static void goster(){
        System.out.println("Parentteki goster metodu.");
    }
}
class MyChild extends MyParents {
    public void myChildGoster(){
        System.out.println("My childtaki gostyer metdou.");
    }
    public void childMetodu(){
        myChildGoster(); // overrıde edemeyız ama bır metod ıcınde kullanabılırız.
    }
}