package azKodCokIs;

public class KalitimOrnek {
    public static void main(String[] args) {
        Dikdortgen d1 = new Dikdortgen(10,20);
        d1.ozellikYazdir();
        //System.out.println("Diktortgenin: " +d1); // kullanıssız
        System.out.println(d1);

        GeometrikSekil gs1 = new GeometrikSekil(5,10);
        System.out.println(gs1);

        Kare k1 = new Kare(10);
        k1.alanHesapla();
        k1.cevreHesapla();
        k1.ozellikYazdir();
    }
}
class GeometrikSekil{
    private int en;
    private int boy;



    public GeometrikSekil(int en, int boy) {
        this.en = en;
        this.boy = boy;
        System.out.println("Geometrık Sekıl constructor'ı oluşturuldu. ");
    }
  public GeometrikSekil(int en) {
            this.en = en;
      System.out.println("Tek parametreli Geometrık sekıl constructor'ı oluşturuldu. ");
    }

    public int getEn() {
        return en;
    }

    public void setEn(int en) {
        this.en = en;
    }

    public int getBoy() {
        return boy;
    }

    public void setBoy(int boy) {
        this.boy = boy;
    }
    public void alanHesapla(){
        System.out.println("Alan: "+(getEn()*getBoy()));
    }
    public void cevreHesapla(){
        System.out.println("Çevre: "+(en+boy)*2);
    }
    @Override
    public String toString(){
        return "En: " +en+ " Boy: "+ boy;
    }
}

class Dikdortgen extends GeometrikSekil{

    public Dikdortgen(int en, int boy) {
        super(en, boy);
        System.out.println("Diktortgen constructor'ı oluşturuldu. ");
    }

    public Dikdortgen(int en){
        super(en);
        System.out.println("Tek parametrelı Dıktortgen constructor'ı oluşturuldu. ");
    }
    public void ozellikYazdir(){
        System.out.println("Geometrik şeklin eni: "+getEn()+" boyu: "+getBoy());
        alanHesapla();
        cevreHesapla();
    }

    @Override
    public String toString() {
        return "Diktortgenın En: "+getEn()+" Boy: "+getBoy();
    }
}

class Kare extends Dikdortgen{
    public Kare(int en) {
        super(en);
        setBoy(en);
        System.out.println("Kare constructor'u oluşturuldu. ");
    }
}
