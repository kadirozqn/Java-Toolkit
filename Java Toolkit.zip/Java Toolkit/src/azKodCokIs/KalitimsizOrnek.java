package azKodCokIs;

public class KalitimsizOrnek {
    public static void main(String[] args) {
        Personel p1 = new Personel("Kadir", 2151210,-8);
        System.out.println(p1.getYas());
        System.out.println(p1);

        Ogrenci o1 = new Ogrenci("Fatma", -8,15615612, 5005);
        System.out.println(o1);
    }

}
class Personel {
    private String isim;
    private long tcKimlik;
    private int yas;

    public Personel() {
        isim = "Henüz atanmadı.";
        tcKimlik = 0;
        yas = 18;
    }

    public Personel(String isim, long tcKimlik, int yas) {
        this.isim = isim;
        this.tcKimlik = tcKimlik;
        setYas(yas);
    }


    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public long getTcKimlik() {
        return tcKimlik;
    }

    public void setTcKimlik(long tcKimlik) {
        this.tcKimlik = tcKimlik;
    }

    public int getYas() {
        return yas;
    }

    public void setYas(int yas) {
        if (yas > 0 && yas > 18) {
            this.yas = yas;
        } else {
            this.yas = 18;
        }
    }

    @Override
    public String toString() {
        return "Ad: "+isim+", tc kimlik no: "+tcKimlik+", yas: " +yas;
    }
}
class Ogrenci {

    private String isim;
    private int yas;
    private int tcKimlik;
    private  int okulNo;

    public Ogrenci(){
        this.isim = "Henüz isim degeri atanmadı.";
        this.yas = 7;
        this.tcKimlik = 0;
        this.okulNo = 5000;
    }
    public Ogrenci(String isim, int yas, int tcKimlik, int okulNo) {
        this.isim = isim;
        setYas(yas);
        this.tcKimlik = tcKimlik;
        this.okulNo = okulNo;
    }

    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public int getYas() {
        return yas;
    }

    public void setYas(int yas) {
        if(yas>0 && yas>7){
            this.yas = yas;
        }else {
            System.out.println("Yanlış yas degerı gırdınız. Varsayılan olarak 7 atandı.");
            this.yas = 7 ;
        }

    }

    public int getTcKimlik() {
        return tcKimlik;
    }

    public void setTcKimlik(int tcKimlik) {
        this.tcKimlik = tcKimlik;
    }

    public int getOkulNo() {
        return okulNo;
    }

    public void setOkulNo(int okulNo) {
        this.okulNo = okulNo;
    }

    @Override
    public String toString() {
        return "Ad: "+isim+", tc kimlik no: "+tcKimlik+", yas: " +yas+", okul numarası: "+okulNo;
    }
}