package azKodCokIs;

public class StringDegismez {
    public static void main(String[] args) {
        String isim = new String("Kadir").intern(); //intern kullandıgımız zaman farklı degıskenlerdekı Kadir stringinin tutuldugu alanı ısaret eder.
        String ad = new String("Kadir");
        /*if (isim == ad ){
            System.out.println("True");
        }else {
            System.out.println("False");
        }*/
        System.out.println(isim==ad); // referansı gosterır
        System.out.println(isim.equals(ad)); // degerı gosterır dıyebılırız kısaca.

        String abc = "Kadir"; // bu bır sabıt degerdır strıng pool alanında tutulur.
        String def = "Kadir"; // bu ıkı degerın hepsı aynı alanda tutulur ve aynı referans adresını gosterır yanı kadiri gostyerır yenı bır alan ayurılmaz


        String yeni= abc.concat(" Özan"); // gene bellegın farklı bır alanında abc degerıonın sonunda özan kelımesını eklemıs olduk.
        System.out.println(abc);
        System.out.println(yeni);
        System.out.println(abc==yeni);//farklı alanlarda tutuldugu ıcın false degerı aldık.
        System.out.println(isim == abc);

        /*abc = "Kadir Özan"; // yenı bır alan ayrıldı.
        System.out.println(def);
        System.out.println(abc ==def);*/
    }
}
