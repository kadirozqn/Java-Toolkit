package azKodCokIs;

import java.util.Objects;

public class EqualsKullanimi {
    public static void main(String[] args) {
        Kisi2 k1 = new Kisi2(25612596,"Kadir", 6518);
        System.out.println(k1);

        Kisi2 k2 = new Kisi2(25612596,"Kadir2", 6518);
        System.out.println(k2);

        System.out.println("k1 ve k2 nesnesi birbirine eşit mi?: "+k1.equals(k2));
        //equals metodunu derleyıcı yardımıyla degılde kendımız olusturdugumuzda referans adreslerı farklı oldugu ıcın false sonucu aldık.
        //derleyıcının equals algorıtmasıyla calıstırdıgımız zaman true degerını alacagız.

        System.out.println("k1 hash code: "+k1.hashCode() + " k2 hash code: "+k2.hashCode());
        //equal true oldugu zaman hash codelar bırbırı ıle esıt olur false oldugunda bırbırınden farklı olur.

        //k1 = k2; //k2 nın gostermıs oldugu referans adresını k1 nesnesının gostermıs oldugu referans adresıne atadıgımız ıcın artık true degerını alacagız.
        System.out.println("k1 ve k2 nesnesının atama sonrası esıtlık durumu: "+k1.equals(k2));

        Amele a1 = new Amele(65161541,"Mehmet",5);
        System.out.println("a1 ve k1 bırbırıne esıt mı?" +k1.equals(a1));

        //equals metodunda istisna sınıflar
        String isim = new String("Kadir");
        String isim2 = new String("Kadir");
        System.out.println("isim ve isim 1 bırbırıne esıt mı?: " +isim.equals(isim2)); // referanslar farklı olmasın ragmen degerler bırbırıne esıt oldjugu ıcın true degerı donecek.

        Integer sayi = new Integer(5);
        Integer sayi2 = new Integer(5);
        System.out.println("sayi ve sayi 1 bırbırıne esıt mı?: " +sayi.equals(sayi2)); // referanslar farklı olmnasına ragmen degerler bırbırıyle esıt oldugu ıcın true degerı donecek.

    }
}
class Kisi2 extends Object{ // Bu sekılde yazmamıza gerek yoktu sadece javanın varsayılan sınıf degerı olan objekt sınıfını gostermek ıcın belırttım.
    int id;
    String isim;
    int no;

    public Kisi2(int id, String isim, int no) {
        this.id = id;
        this.isim = isim;
        this.no = no;
    }

    @Override
    public String toString() {
        return "id: " +id+" isim: "+isim+" no:"+no;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Kisi2 kisi2)) return false;
        return id == kisi2.id && no == kisi2.no && Objects.equals(isim, kisi2.isim);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, isim, no);
    }
/* @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }*/
}
class Amele{
    int id;
    String isim;
    int ameleNo;

    public Amele(int id, String isim, int ameleNo) {
        this.id = id;
        this.isim = isim;
        this.ameleNo = ameleNo;
    }
}
