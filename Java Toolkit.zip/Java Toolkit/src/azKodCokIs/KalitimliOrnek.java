package azKodCokIs;

public class KalitimliOrnek {
    public static void main(String[] args) {
        Calisan c1 = new Calisan("Kadir", 20, 2562612,"Öğretmen");
        System.out.println(c1);

        Talebe t1 = new Talebe("Abdulselam",41564154,-8,"Öğrenci",2000);
        System.out.println(t1);

        MezunOgrenci m1 = new MezunOgrenci("Ayse", 1515411,19,"Mezun",5215,"Bilgisayar Mühendisi");
        System.out.println(m1);
    }
}
class Kisi {
    private String isim;
    private long tcKimlik;
    private int yas;

    public Kisi() {
        isim = "Henüz atanmadı.";
        tcKimlik = 0;
        yas = 18;
    }

    public Kisi (String isim, long tcKimlik, int yas) {
        this.isim = isim;
        this.tcKimlik = tcKimlik;
        setYas(yas);
    }


    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public long getTcKimlik() {
        return tcKimlik;
    }

    public void setTcKimlik(long tcKimlik) {
        this.tcKimlik = tcKimlik;
    }

    public int getYas() {
        return yas;
    }

    public void setYas(int yas) {
        if (yas > 0 && yas > 18) {
            this.yas = yas;
        } else {
            this.yas = 18;
        }
    }

    @Override
    public String toString() {
        return "Ad: "+isim+", tc kimlik no: "+tcKimlik+", yas: " +yas;
    }
}

class Calisan extends Kisi{
    private String pozisyon;

    public Calisan(String isim, long tcKimlik, int yas, String pozisyon) {
//        setYas(yas);
//        setIsim(isim);
//        setTcKimlik(tcKimlik);
        super(isim, tcKimlik, yas);
        this.pozisyon = pozisyon;
    }

    public String getPozisyon() {
        return pozisyon;
    }

    public void setPozisyon(String pozisyon) {
        this.pozisyon = pozisyon;
    }
    @Override
    public String toString() {
        return "Ad: "+getIsim()+", tc kimlik no: "+getTcKimlik()+", yas: " +getYas()+" pozisyon: "+pozisyon; //pozısyon bu sınıfa aıt oldugu ıcın get kullanmadık
    }
}
class Talebe extends Calisan{
    private int ogrenciNo;

    public Talebe(String isim, long tcKimlik, int yas, String pozisyon, int ogrenciNo) {

//      setIsim(isim);
//      setTcKimlik(tcKimlik);
 //     setYas(yas);
        super(isim, tcKimlik, yas, pozisyon);
        this.ogrenciNo = ogrenciNo;
    }

    public int Talebe() {
        return ogrenciNo;
    }

    public void setOgrenciNo(int ogrenciNo) {
        this.ogrenciNo = ogrenciNo;
    }

    public int getOgrenciNo() {
        return ogrenciNo;
    }

    @Override
    public String toString() {
        return "Öğrenci Ad: "+getIsim()+", Öğrenci tc kimlik no: "+getTcKimlik()+", Öğrenci yas: " +getYas()+" Öğrenci pozisyon: "+getPozisyon()+"Öğrenci numarası: "+ogrenciNo; //pozısyon bu sınıfa aıt oldugu ıcın get kullanmadık
    }
}

class MezunOgrenci extends Talebe{
    private String calismaAlani;

    public MezunOgrenci(String isim, long tcKimlik, int yas, String pozisyon, int ogrenciNo, String calismaAlani) {
        super(isim, tcKimlik, yas, pozisyon, ogrenciNo);
        this.calismaAlani = calismaAlani;
    }

    public String getCalismaAlani() {
        return calismaAlani;
    }

    public void setCalismaAlani(String calismaAlani) {
        this.calismaAlani = calismaAlani;
    }
    @Override
    public String toString() {
        return "Öğrenci Ad: "+getIsim()+", Öğrenci tc kimlik no: "+getTcKimlik()+", Öğrenci yas: " +getYas()+", Öğrenci pozisyon: "+getPozisyon()+", Öğrenci numarası: "+getOgrenciNo()+ ", Çalıstıgı alan: " +getCalismaAlani(); //pozısyon bu sınıfa aıt oldugu ıcın get kullanmadık
    }
}