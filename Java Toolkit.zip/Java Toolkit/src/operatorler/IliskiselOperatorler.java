package operatorler;

public class IliskiselOperatorler {
    public static void main(String[]args){
        int sayi1 = 10;
        int sayi2 = 1;
        System.out.println("sayi1 eşit mi sayi2       : "+(sayi1==sayi2)); //true
        System.out.println("sayi1 buyuk mu sayi2      : "+(sayi1>sayi2)); //true
        System.out.println("sayi1 kucuk mu sayi2      : "+(sayi1<sayi2));//false
        System.out.println("sayi1 buyuk eşit mi sayi2 : "+(sayi1>=sayi2));
        System.out.println("sayi1 kucuk eşit mi sayi2 : "+(sayi1<=sayi2));
        System.out.println("sayi2 kucuk esit mi sayi1 : "+(sayi2<=sayi1));

        if(sayi1<sayi2){
            System.out.println("sayi1 sayi2'den kucuktur.");
        }
        else {
            System.out.println("sayi1 sayi2'den buyuktur.");
        }

        if(sayi2<sayi1){
            int sonuc = 0;
            sonuc = sayi1+sayi2;
            System.out.println("Sonuc degeri: " +sonuc);
            System.out.println("sayi1 sayi2'den kucuktur.");
        }
        else {
            System.out.println("sayi1 sayi2'den buyuktur.");
        }
        boolean deger1 = true;
        boolean deger2 = false;

        System.out.println("-----------------------------------------------------------------------------------------");
        System.out.println("deger1 ve deger 2 and (ve) durumu  : " + (deger1 && deger2));
        System.out.println("deger1 ve deger 2 or (veya) durumu: " + (deger1 || deger2));

        int elif = 40;
        int kadir = 25;
        System.out.println("-----------------------------------------------------------------------------------------");
        if(elif>30 && kadir>20){
            System.out.println("Birinci komut çalıştı.(elif>30 && kadir>20) ifadesinde true döndü.");
        }
        else if (elif>45 || kadir>26) {
            System.out.println("İkinci komut çalıştı.(benimYas>45 || onunYas>21) ifadesinde false döndü.");
        }
    }
}
