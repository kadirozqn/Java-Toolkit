package operatorler;

public class ArıtmetıkAtama {
    public static void main (String[]args){
        int sayi1 = 8;
        int sayi2 = 11;

        int sonuc = 0;
        int sonuc2 =0;
        sonuc2 = sayi2-sayi1;
        System.out.println("sonuc2: "+ sonuc2);

        sonuc -= sayi2;
        System.out.println("Sonuc:" +sonuc);
        sonuc += sayi1;
        System.out.println("Sonuc:" +sonuc);
        sonuc -= sayi2;
        System.out.println("Sonuc:" +sonuc);
        sonuc *= sayi1;
        System.out.println("Sonuc:" +sonuc);
        sonuc /= (double)sayi2;
        System.out.println("Sonuc:" +sonuc);

        System.out.println("-----------------------------------------------------------------------------------------");
        //ÖDEV
        double ondalikliSayi = 6.5;
        double odevSonucu = 1;

        odevSonucu++;
        ondalikliSayi *=odevSonucu;

        System.out.println("Sonuç: " +ondalikliSayi);

        System.out.println("-----------------------------------------------------------------------------------------");

        //ÖDEV 2
        int s1 = 10;
        int s2 = 6;

        s1++; // 11
        --s2; //5

        s1 *= --s2; //4

        System.out.println("s1'in son değeri :" +s1);
        System.out.println("s2'nin son değeri:" +s2);

    }
}
