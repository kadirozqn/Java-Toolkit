package operatorler;

public class ArttırmaAzaltma {
    public static void main (String[]args){
        int sayi1 = 10;
        int sayi2 = ++sayi1;
        int sayi3 = sayi1--;
        System.out.println("sonuc: " + (sayi1) + " " + (--sayi2) + " " +  (sayi3++));
        System.out.println("sonuc: " + ((sayi1) + (--sayi2) + (sayi3++)));

        //sayi1++ ==> sayi1 = sayi1 +1;
    }
}
