package operatorler;

public class AritmetikOperatorler {

    public static void main(String[]args){
        //Aritmetik operatorler
        int sayi1 =56;
        int sayi2 = 24;
        System.out.println("\t-Aritmetik Operatorler-");
        System.out.println("sayi1:" +sayi1 + " sayi2:" +sayi2 + " |Toplamları: " +(sayi1+sayi2));
        System.out.println("sayi1:" +sayi1 + " sayi2:" +sayi2 + " |Carpımları: " +(sayi1*sayi2));
        System.out.println("sayi1:" +sayi1 + " sayi2:" +sayi2 + " |Farkları  : " +(sayi1-sayi2));
        System.out.println("sayi1:" +sayi1 + " sayi2:" +sayi2 + " |Bolumlerı : " +((double)sayi1/(double)sayi2));
        System.out.println("sayi1:" +sayi1 + " sayi2:" +sayi2 + " |Modları   : " +(sayi1%sayi2));
    }
}
