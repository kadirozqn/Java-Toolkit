package com.kadirozan;

public interface YazdiranInterface {

    void yazdir();
}
