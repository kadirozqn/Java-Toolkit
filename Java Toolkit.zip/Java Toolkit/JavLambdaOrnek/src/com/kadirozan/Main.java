package com.kadirozan;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.function.Consumer;


public class Main {
    public static void main(String[] args) {

        Calisan c1 = new Calisan("Kadir",21);
        Calisan c2 = new Calisan("Ahmet",56);
        Calisan c3 = new Calisan("Fatma",25);
        Calisan c4 = new Calisan("Ayse",23);

        ArrayList<Calisan> arrayList = new ArrayList<>();
        arrayList.add(c1);
        arrayList.add(c2);
        arrayList.add(c3);
        arrayList.add(c4);

        /*Collections.sort(arrayList, new Comparator<Calisan>() {
            @Override
            public int compare(Calisan o1, Calisan o2) {
                return o1.getIsim().compareTo(o2.getIsim());
            }
        });*/


        Collections.sort(arrayList,(cal1, cal2)->cal1.getIsim().compareTo(cal2.getIsim()));


        /*arrayList.forEach(new Consumer<Calisan>() {
            @Override
            public void accept(Calisan calisan) {
                System.out.println(calisan.getIsim() + " : " +calisan.getYas());
            }
        });*/

        arrayList.forEach((Calisan cal) -> System.out.println(cal.getIsim() + ": " + cal.getYas()));
        /*for (Calisan calisan : arrayList){
            System.out.println(calisan.getIsim());
        }*/

        /*for(Calisan calisan : arrayList){
            bilgilerYazdir(new YazdiranInterface() {
                @Override
                public void yazdir() {
                    System.out.println(calisan.getIsim() + ": " + calisan.getYas());
                }
            });
        }

        for (Calisan calisan : arrayList){
            bilgilerYazdir(()-> System.out.println(calisan.getIsim()+ ": " + calisan.getYas()));
        }*/

        /*new Thread(new ThreadSinifi()).start();
        new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("Anonim run çalıştı.");
            }
        }).start();

        new Thread(() -> {
            System.out.println("Lamda run çalıştı.");
            System.out.println("Lamda ikinci satir çalıştı.");}).start();
    }
    public static  void bilgilerYazdir (YazdiranInterface yazdiranInterface){
        yazdiranInterface.yazdir();*/
    }
}
/*class ThreadSinifi implements Runnable{

    @Override
    public void run() {
        System.out.println("ThreadSinifi çalıştı.");
    }
}*/

class Calisan{
    String isim;
    int yas;

    public Calisan(String isim, int yas) {
        this.isim = isim;
        this.yas = yas;
    }

    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public int getYas() {
        return yas;
    }

    public void setYas(int yas) {
        this.yas = yas;
    }
}