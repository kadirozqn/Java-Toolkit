package com.kadirozan.lamdaAlistirma;

import java.util.function.Function;

public class Alistirma {
    public static void main(String[] args) {
        // Soru1 ->Kelimeler içeren bir string ifadesini boşluklara göre parçalayıp ekrana yazdıran bir threadi lamda ifadesi ile calıstıran kod"
        // Soru2 ->Function interface'inin apply metodunu gerceklestırın. (Funciton ınterface'ini arastırın).
        // bu metod ıcınde gırılen ifadenin cıft sayılı  pozısyonlarında bulunan elemanları gerıye donecek sekılde yazılmalı.
        // Soru3 -> Function interface'inin apply metodunda yapılacak ıslemı lamnbda ifade ile gerceklestırın
        // Soru4 -> Main sınıfı method olusturun, bu metod functıon ınterface'ını ve String ifadeyi parametre olarak alıp sonucu strıng olarak gerıye dondursun
//SORU 1
        String kelime = "Mehmetin götünü siktim ve çok keyif aldım.";

        /*new Thread(new Runnable() {
            @Override
            public void run() {
                String [] kelimeler = kelime.split(" ");
                for (String s : kelimeler){
                    System.out.println(s);
                }
            }
        }).start();*/
        new Thread(() -> {
            String[] kelimeler = kelime.split(" ");
            for (String s : kelimeler) {
                System.out.println(s);
            }
        }).start();

//SORU 2

        Function<String, String> function1 = new Function<String, String>() {
            @Override
            public String apply(String s) {
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < s.length(); i++) {
                    if (i % 2 == 0) {
                        builder.append(s.charAt(i));
                    }
                }
                return builder.toString();
            }
        };

//SORU 3
        Function<String, String> function2 = (String s) -> {
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < s.length(); i++) {
                if (i % 2 == 0) {
                    builder.append(s.charAt(i));
                }
            }
            return builder.toString();
        };
        System.out.println(function1.apply("Mehmetin götünü siktim"));
        System.out.println(function2.apply("ve çok keyif aldım. "));

        System.out.println(ciftPozisyondakiKarakterleriYazdir(function2,"Metod ile gerçekleştirdik "));
    }

//SORU 4
        public static String ciftPozisyondakiKarakterleriYazdir(Function< String,String > fun, String kaynak){
        return fun.apply(kaynak);

        }

}
