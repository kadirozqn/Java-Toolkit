package org.example.favorifilmapp;

import com.jfoenix.controls.JFXListView;
import com.jfoenix.controls.JFXTextArea;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.util.Callback;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLOutput;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.ResourceBundle;

public class HelloController implements Initializable {
    private ContextMenu listeSilMenusu;

    @FXML
    private BorderPane anaPencere;

    @FXML
    private JFXListView<Film> filmlerListesi;

    @FXML
    private Label labeCikisTarihi;

    @FXML
    private JFXTextArea txtAreaFilmDetay;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        listeSilMenusu = new ContextMenu();
        MenuItem filmSil = new MenuItem("Filmi Listeden Kaldırr.");
        filmSil.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent actionEvent) {
                Film silinecekFilm = filmlerListesi.getSelectionModel().getSelectedItem();
                secilenFilmiSil(silinecekFilm);
            }
        });
        listeSilMenusu.getItems().add(filmSil);




        filmlerListesi.setItems(FilmData.getInstance().getFilmListesi());
        txtAreaFilmDetay.setEditable(false);
        filmlerListesi.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Film>() {
           @Override
            public void changed(ObservableValue<? extends Film> observableValue, Film film, Film t1) {
               Film secilenFilm = filmlerListesi.getSelectionModel().getSelectedItem();
               txtAreaFilmDetay.setText(String.valueOf(secilenFilm));

               DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
               labeCikisTarihi.setText(secilenFilm.getCikisTarihi().format(formatter));
           }
        });
        filmlerListesi.getSelectionModel().selectFirst();

        filmlerListesi.setCellFactory(new Callback<ListView<Film>, ListCell<Film>>() {
            @Override
            public ListCell<Film> call(ListView<Film> filmListView) {

                ListCell <Film> yeniFilmListesi = new ListCell<>(){
                    @Override
                    protected void updateItem(Film film, boolean empty) {
                        super.updateItem(film, empty);
                        if (empty || film == null) {
                            setText(null);
                        }else {
                            setText(film.getBaslik());
                            if (film.getBaslik().substring(0,1).equals("G")){
                                setTextFill(Color.GREEN);
                            }else {
                                setTextFill(Color.RED);
                            }
                        }
                    }

                    private void setTextFill(Color green) {
                    }
                };

                yeniFilmListesi.setContextMenu(listeSilMenusu);
                return yeniFilmListesi;
            }
        });
    }

    private void secilenFilmiSil(Film silinecekFilm) {
    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
    alert.setTitle("Emin misiniz?");
    alert.setHeaderText("Silinecek Film :" +silinecekFilm.getBaslik());

    Optional<ButtonType> sonuc = alert.showAndWait();

    if (sonuc.get() == ButtonType.OK){
        FilmData .getInstance().dosyadanFilmSil(silinecekFilm);
    }
    }

    public void filmEkleDiyalog(ActionEvent event) throws IOException {

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.initOwner(anaPencere.getScene().getWindow());

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.getClass().getResource("yeniFilmDialog.fxml");

        dialog.setTitle("Yeni Film Ekle");
        dialog.getDialogPane().setContent(fxmlLoader.load());

        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.APPLY);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.CANCEL);

        Optional <ButtonType> sonuc = dialog.showAndWait();

        if(sonuc.get() == ButtonType.APPLY) {
            YeniFilmController dialogController = fxmlLoader.getController();
            Film eklenecekFilm = dialogController.yeniNotuEkle();

            filmlerListesi.getSelectionModel().select(eklenecekFilm);

        }
    }
    public void uygulamayiKapat(ActionEvent event){
        Platform.exit();
        
    }

}