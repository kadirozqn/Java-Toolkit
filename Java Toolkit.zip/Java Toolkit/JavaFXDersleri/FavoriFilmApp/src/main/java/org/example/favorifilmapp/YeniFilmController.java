package org.example.favorifilmapp;

import com.sun.source.doctree.SeeTree;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class YeniFilmController {
    @FXML
    private DatePicker txtCikisTarihi;

    @FXML
    private TextField txtFilmAdi;

    @FXML
    private TextArea txtFilmDetay;

    public Film yeniNotuEkle() {
        String filmAdi = txtFilmAdi.getText().trim();
        String filmDetay =txtFilmDetay.getText().trim();
        String filmCikisTarihi = String.valueOf(txtCikisTarihi.getValue());

        Film eklenecekFilm = new Film(filmAdi,filmDetay,filmCikisTarihi);
        FilmData.getInstance().dosyayaFilmEkle(eklenecekFilm);

        return eklenecekFilm;


    }
}
