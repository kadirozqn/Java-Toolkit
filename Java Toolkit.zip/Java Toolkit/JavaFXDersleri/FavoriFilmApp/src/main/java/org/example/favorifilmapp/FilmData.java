package org.example.favorifilmapp;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;

public class FilmData {

    private static FilmData instance = new FilmData();
    private DateTimeFormatter formatter;
    private ObservableList<Film> filmListesi;

    private FilmData(){
        formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    }

    public static FilmData getInstance() {
        return instance;

    }

    public void dosyayaFilmEkle(Film eklenecekFilm){
        filmListesi.add(eklenecekFilm);
    }

    public void dosyadanFilmSil(Film silinecekFilm){
        filmListesi.remove(silinecekFilm);
    }
    //Uygulama acıldıgında dosyadan tum filmler getirilip observable listeye atanır.
    public void dosyadanFilmleriGetir(){

        //Dosyadan içeriği şu şekilde alacak
        //Baslik \t Detayı \ t cikis tarihi

        filmListesi = FXCollections.observableArrayList(); //new arraylist gibi calısır

        try(BufferedReader okuyucu = new BufferedReader(new FileReader("filmer.txt"))) {

            String tekFilmSatir;
            while ((tekFilmSatir = okuyucu.readLine()) != null ){

                String [] filmParcalari = tekFilmSatir.split("\t");
                String filmBaslik= filmParcalari[0];
                String filmDetay= filmParcalari[1];
                String filmBitisTarihi= filmParcalari[2];

                LocalDate bitis = LocalDate.parse(filmBitisTarihi,formatter);

                Film okunanFilm = new Film(filmBaslik,filmDetay,filmBitisTarihi);
                filmListesi.add(okunanFilm);

            }
            System.out.println("Dosyadan getirilne filmler: "+ filmListesi);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }



    }
    //Uygulama kapatılırklen observable lıstedeki filmler dosyaya yazılır.

        public void dosyayaFilmleriYaz(){
        try (BufferedWriter yazici = new BufferedWriter(new FileWriter("filmler.txt"))){

            Iterator<Film> iterator = filmListesi.iterator();
            while (iterator.hasNext()){
                Film oankiFilm = iterator.next();
                yazici.write(String.format("%s\t%s\t%s", oankiFilm.getBaslik(), oankiFilm.getDetay(),oankiFilm.getCikisTarihi().format(formatter)));
                yazici.newLine();
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    };

    public ObservableList<Film> getFilmListesi() {
        return filmListesi;
    }
}
