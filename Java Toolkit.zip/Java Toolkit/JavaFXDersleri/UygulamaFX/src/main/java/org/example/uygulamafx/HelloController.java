package org.example.uygulamafx;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXListView;
import com.jfoenix.controls.JFXTextArea;
import javafx.beans.Observable;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.KeyEvent;

import javax.swing.event.ChangeListener;
import java.util.ArrayList;


public class HelloController {
    @FXML
    private JFXListView<String> liste;

    @FXML
    private JFXTextArea textArea;

    @FXML
    private JFXButton btnHoscakal;

    @FXML
    private JFXButton btnMerhaba;

    @FXML
    private TextField txtAd;

    @FXML
    private JFXCheckBox checkbox;



    public void initialize(){
        btnMerhaba.setDisable(true);
        btnHoscakal.setDisable(true);

        liste.getItems().addAll("Domates","Mısır","Sucuk","Zeytin","Mısır");
        liste.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }
    @FXML
    private Label welcomeText;

    @FXML
    public void calistir(ActionEvent actionEvent) {

        //System.out.println(actionEvent.getSource());
        String isim = txtAd.getText().trim();
        if (actionEvent.getSource().equals(btnHoscakal))  {
            System.out.println("Merhaba " +isim);
        } else
            System.out.println("Hoşcakal "+isim );
        if (checkbox.isSelected()) {
            txtAd.clear();
            btnHoscakal.setDisable(true);
            checkbox.setDisable(true);
        }
    }

   @FXML
    public void textGirildi(KeyEvent keyEvent) {
       String isim  = txtAd.getText();
       boolean butonlariDisableEt = isim.isEmpty() || isim.trim().isEmpty();
       btnMerhaba.setDisable(butonlariDisableEt);
       btnHoscakal.setDisable(butonlariDisableEt);
   }
   void checkboxKontrol(ActionEvent event) {
       System.out.println("Checkbox "+checkbox.isSelected());
   }
    @FXML
    void listeElemanlariniTasi(ActionEvent event) {
        String textAreaMetni = "";
        ObservableList secilenler = liste.getSelectionModel().getSelectedItems();
        System.out.println(secilenler);

        for (Object gecici : secilenler){
            textAreaMetni += gecici + "\n";
        }
        textArea.setText(textAreaMetni);
    }
}
3